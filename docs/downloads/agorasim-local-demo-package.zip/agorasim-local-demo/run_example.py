"""End-to-end smoke test — runs WITHOUT any API key (random + classic agents).

    python run_example.py
"""
import asyncio

from agorasim import Simulator
from agorasim.examples import CENTRAL_BANK_EXAMPLE


async def main():
    sim = Simulator(CENTRAL_BANK_EXAMPLE)
    res = await sim.run(on_progress=lambda r: print(
        f"  progress {r.progress:.0%}  cost ${r.cost_usd:.4f}"))
    print(f"\nstatus: {res.status}")
    if res.error:
        print("error:", res.error)
        return
    for r in res.rounds:
        print(f"回合{r.round}: 立場 {r.stance_mean}±{r.stance_std} "
              f"極化 {r.polarization} 採納率 {r.adoption_rate:.0%} "
              f"(Bass {r.bass_reference:.0%})")
        print("  行動分布:", r.action_dist)
    print("\nprovider 分布:", res.provider_share)
    print("\n" + "=" * 60)
    print(res.summary_markdown)


if __name__ == "__main__":
    asyncio.run(main())
