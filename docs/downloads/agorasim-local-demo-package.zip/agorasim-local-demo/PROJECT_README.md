# AgoraSim

基於 LLM/VLM 的生成式 Agent-Based Modeling 平台。輸入一個自然語言事件（政策宣布、新品上市、一支廣告影片、你打算發布的貼文原文）與模擬目標，N 個具有完整人格的 AI agent 在社會網絡中感知、討論、行動，產出意見分布、調查結果、湧現情境與執行摘要。完整設計理念見 [DESIGN.md](DESIGN.md)。

核心彈性機制（v1.1）：

- **情境模板**（`scenarios.py`）：貼文/文案前測、金融市場事件、選舉/公共政策、產品上市/廣告、品牌危機/公關聲明、自訂情境。模板是資料不是程式碼，選一個即預填問題、行動空間、調查題與 ABM 參數，全部可改；新增領域只需加一筆 dict。
- **原文內容**（`event.verbatim_content`）：使用者自撰的貼文、文案、聲明會「一字不改」呈現給每個 agent，明確標示為「你在網路上看到的原文」。
- **自訂調查問題**（`goal.survey_questions`）：量表（任意範圍）、單選、開放式三種題型，每個 agent 每回合作答，自動聚合成平均值、分布與代表回答。
- **多語言**：agent 提示、persona 生成、報告與 Web UI 皆支援英文、繁體中文、日文（`config.language` / UI 右上角切換），三語系人口分布與姓名/職業素材內建於 `i18n.py`。
- **AI 情境生成**（`composer.py` / `POST /api/compose`）：使用者用一句話描述想模擬什麼（「捷運罷工通勤族會怎麼反應」），LLM 自動設計完整情境——問題、行動空間（正→負排序）、調查題、ABM 參數——經範圍驗證與夾制後填入表單，全部仍可手動修改。內建模板變成起點而非上限。
- **UI 直接貼 API key**（`POST /api/keys`）：金鑰面板貼上 Anthropic / OpenAI / Google 金鑰即可跑 LLM agent 與自動生成；金鑰僅存於伺服器記憶體，不寫入磁碟、不回傳、不進模擬結果。環境變數仍為後備。
- **模型清單與 API 驗證**（`GET /api/providers/models` / `POST /api/providers/verify`）：UI 模型選單由後端 registry 提供，先有離線 seed catalog，貼上 key 後可刷新 provider 實際可用模型；verify endpoint 可檢查模型列表或做一次最小 live call。
- **模擬過程稽核**（`GET /api/simulations/{id}/records`）：每個 agent 每回合的 provider/model、公開發言、行動、立場、聽到的鄰居發言都可查，UI 會顯示最近互動紀錄。

## 快速開始

```bash
pip install -e .

# 1) 無金鑰煙霧測試（random + classic agents，30 秒內完成）
python run_example.py

# 2) 啟動平台（Web UI + REST API）
export ANTHROPIC_API_KEY=sk-ant-...
export OPENAI_API_KEY=sk-...
export GEMINI_API_KEY=...
uvicorn agorasim.api:app --port 8000
# 打開 http://localhost:8000

# 3) 跑離線測試
pytest
```

## 桌面安裝版

AgoraSim 也可以包成 macOS `.app/.dmg` 與 Windows `.exe` installer。
安裝後使用者點開 App，先選本機 port，系統會啟動
`127.0.0.1:<port>` 的本機 FastAPI 服務並自動開瀏覽器；API key
仍由使用者在本機 UI 貼上，不會被打包或寫入磁碟。

開發模式可直接測試桌面啟動器：

```bash
python -m agorasim.desktop
```

打包指令與簽章注意事項見 [packaging/README.md](packaging/README.md)。

## 以 SDK 使用

```python
import asyncio
from agorasim import (Simulator, SimulationConfig, EventInput, SimulationGoal,
                      ModelMix, ModelSlot, PopulationSpec, ABMParams)

config = SimulationConfig(
    event=EventInput(title="央行宣布升息兩碼",
                     description="……", context="市場原預期僅升息一碼"),
    goal=SimulationGoal(
        question="存款戶與潛在購屋族會如何反應？",
        target_population="台灣 25-55 歲民眾",
        action_space=["增加定存", "觀望", "延後購屋", "轉移資產"],
        adopt_action_indices=[0], horizon_rounds=3),
    population=PopulationSpec(n_agents=100, contrarian_ratio=0.1, seed=42),
    model_mix=ModelMix(slots=[                       # 50/30/20 混合
        ModelSlot(provider="claude", weight=0.5, model="claude-sonnet-5"),
        ModelSlot(provider="openai", weight=0.3, model="gpt-4o"),
        ModelSlot(provider="gemini", weight=0.2, model="gemini-2.5-flash"),
        # 也可以混入非 LLM agent：
        # ModelSlot(provider="random", weight=0.2),
        # ModelSlot(provider="classic", weight=0.2),  # 傳統 ABM 規則驅動
    ]),
    abm=ABMParams(social_influence=0.35, adoption_threshold=0.25,
                  innovation_p=0.05, imitation_q=0.45),
)

result = asyncio.run(Simulator(config).run())
print(result.summary_markdown)
```

## 簡化實驗 API / SDK

研究者不需要手刻完整 `SimulationConfig`。可以用 `run_experiment`
輸入研究命題、受眾、預算與樣本數，系統會自動補齊情境、模型規劃、
persona population、調查題與完整可追溯設定。

```python
from agorasim.experiments import run_experiment

run = run_experiment(
    brief="東京上班族看到一張新飲料廣告後的購買意願",
    target_population="東京的上班族",
    question="他們會不會購買或分享這支飲料？",
    budget_usd=0.5,
    n_agents=80,
    rounds=3,
    language="zh-TW",
    model_policy="latest_within_budget",
    media=["./flyer.png"],
)

print(run.result.summary_markdown)
run.to_json("results/drink_ad_tokyo.json")
```

沒有 API key 時，可跑離線 baseline：

```python
run = run_experiment(
    brief="便利商店新品咖啡上市",
    target_population="台北上班族",
    model_policy="offline_baseline",
    auto_compose=False,
    n_agents=40,
    rounds=2,
)
```

REST API 也有簡化入口：

```bash
curl -X POST http://127.0.0.1:8000/api/experiments/simple \
  -H 'Content-Type: application/json' \
  -d '{
    "brief":"東京上班族看到一張新飲料廣告後的購買意願",
    "target_population":"東京的上班族",
    "budget_usd":0.5,
    "n_agents":80,
    "rounds":3,
    "language":"zh-TW",
    "model_policy":"latest_within_budget"
  }'
```

取得結果：

```bash
curl http://127.0.0.1:8000/api/experiments/{id}
curl http://127.0.0.1:8000/api/experiments/{id}/records
curl http://127.0.0.1:8000/api/experiments/{id}/report
```

CLI 可用 JSON/YAML 實驗檔：

```bash
agorasim-experiment examples/simple_experiment.json --out results/run.json
```

每次 run 都會保留：

- `spec`：研究者給的簡化輸入
- `config`：最後實際執行的完整 `SimulationConfig`
- `plan`：模型選擇、composer 結果、估算成本與 warnings
- `result`：模擬結果、round metrics、records、summary

## VLM（廣告圖片/影片前測）

```python
from agorasim import MediaAsset
config.event.media.append(MediaAsset(
    media_type="image", base64_data=b64, mime_type="image/jpeg"))
# 影片：先抽幀（如 ffmpeg -i ad.mp4 -vf fps=0.5 f%02d.jpg），放入 frames
config.event.media.append(MediaAsset(
    media_type="video", frames=[b64_f1, b64_f2, ...], transcript="旁白文字"))
```

具視覺能力的 agent 直接看原始媒體；純文字與 random/classic agent 收到感知服務產生的一次性中性描述（成本 O(媒體數) 而非 O(N)）。

## 專案結構

```
agorasim/
  schemas.py      # 全部資料模型（宣告式設定，可版本控制）
  i18n.py         # en/zh-TW/ja 三語系：提示模板、人口預設、報告字串
  scenarios.py    # 情境模板庫（資料驅動，可自行擴充領域）
  personas.py     # 分層抽樣 persona + 多樣性機制（語系感知）
  network.py      # 小世界/無標度/完全/隨機網絡
  providers/      # claude / openai / gemini / random / classic + 註冊擴充點
  model_registry.py # 模型 seed catalog + provider live model-list overlay
  engine.py       # 回合協調器：併發、重試、降級、成本上限、多樣性監測
  abm.py          # 宏觀環境 + Bass 擴散耦合（傳統 ABM 橋接）
  analysis.py     # 回合指標、調查聚合、軌跡分群情境挖掘、Analyst 摘要
  api.py          # FastAPI（含 /api/templates）；ui/index.html 為三語 Web 介面
  examples.py     # 央行升息(zh)、新品廣告(zh)、裁員貼文前測(en) 三個範例
run_example.py    # 無金鑰端到端測試
```

## 調查問題用法

```python
from agorasim import SimulationGoal
from agorasim.schemas import SurveyQuestion

goal = SimulationGoal(
    question="...", action_space=[...],
    survey_questions=[
        SurveyQuestion(id="buy_intent", text="購買意願", type="scale",
                       scale_min=1, scale_max=5),
        SurveyQuestion(id="direction", text="你預期市場方向", type="choice",
                       choices=["看漲", "持平", "看跌"]),
        SurveyQuestion(id="first_word", text="第一個念頭", type="open"),
    ])
# 結果在 result.rounds[-1].survey，含 mean / dist / samples
```

## 擴充

```python
from agorasim import register_provider
from agorasim.providers.base import BaseProvider

class MyLocalLlama(BaseProvider):
    name = "llama"
    async def decide(self, persona, ctx): ...

register_provider("llama", MyLocalLlama)
```

## 注意

模擬結果由合成 agent 產生，反映所用模型的行為假設與偏差，不等同真實民調或市場調查，不構成投資建議。價格表為近似值，請依各家最新定價更新 `providers/llm.py` 的 `_PRICES`。
