$ErrorActionPreference = "Stop"

Set-Location $PSScriptRoot

$Port = $env:AGORASIM_PORT
if (-not $Port) {
    $Port = "8000"
}

$VenvDir = $env:AGORASIM_VENV_DIR
if (-not $VenvDir) {
    $VenvDir = ".venv"
}

$Python = Get-Command py -ErrorAction SilentlyContinue
if ($Python) {
    $PythonArgs = @("-3")
    $PythonExe = "py"
} else {
    $Python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $Python) {
        Write-Host "Python 3.10+ was not found."
        Write-Host "Install Python from https://www.python.org/downloads/ and run this again."
        Read-Host "Press Enter to close"
        exit 1
    }
    $PythonArgs = @()
    $PythonExe = "python"
}

$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    & $PythonExe @PythonArgs -m venv $VenvDir
}

& $VenvPython -m pip install --upgrade pip
& $VenvPython -m pip install -e ".[desktop]"
& $VenvPython -m agorasim.desktop --port $Port

