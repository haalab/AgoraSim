@echo off
setlocal
cd /d "%~dp0"

if "%AGORASIM_PORT%"=="" set AGORASIM_PORT=8000
if "%AGORASIM_VENV_DIR%"=="" set AGORASIM_VENV_DIR=.venv

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  set PYTHON_CMD=py -3
) else (
  where python >nul 2>nul
  if %ERRORLEVEL% NEQ 0 (
    echo Python 3.10+ was not found.
    echo Install Python from https://www.python.org/downloads/ and run this again.
    pause
    exit /b 1
  )
  set PYTHON_CMD=python
)

if not exist "%AGORASIM_VENV_DIR%\Scripts\python.exe" (
  %PYTHON_CMD% -m venv "%AGORASIM_VENV_DIR%"
)

"%AGORASIM_VENV_DIR%\Scripts\python.exe" -m pip install --upgrade pip
"%AGORASIM_VENV_DIR%\Scripts\python.exe" -m pip install -e ".[desktop]"
"%AGORASIM_VENV_DIR%\Scripts\python.exe" -m agorasim.desktop --port "%AGORASIM_PORT%"

pause

