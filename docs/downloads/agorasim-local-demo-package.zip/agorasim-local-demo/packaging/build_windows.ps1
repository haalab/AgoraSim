$ErrorActionPreference = "Stop"

$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $Root

$Python = $env:PYTHON_BIN
if (-not $Python) {
    $Python = "py"
}

$VenvDir = $env:VENV_DIR
if (-not $VenvDir) {
    $VenvDir = ".venv-packaging"
}

if ($Python -eq "py") {
    & py -3 -m venv $VenvDir
} else {
    & $Python -m venv $VenvDir
}

$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
& $VenvPython -m pip install --upgrade pip
& $VenvPython -m pip install -e ".[desktop]"
& $VenvPython -m PyInstaller --clean --noconfirm packaging\pyinstaller\agorasim-windows.spec

$Iscc = Get-Command "iscc.exe" -ErrorAction SilentlyContinue
if ($Iscc) {
    & $Iscc.Source packaging\windows\AgoraSim.iss
    Write-Host "Created dist\installer\AgoraSimSetup.exe"
} else {
    Write-Host "Created dist\AgoraSim\AgoraSim.exe"
    Write-Host "Inno Setup was not found; skipping installer creation."
    Write-Host "Install Inno Setup and rerun this script to produce AgoraSimSetup.exe."
}
