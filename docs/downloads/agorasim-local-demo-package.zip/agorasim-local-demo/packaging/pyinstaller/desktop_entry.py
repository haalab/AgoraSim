from agorasim.desktop import main


if __name__ == "__main__":
    raise SystemExit(main())
