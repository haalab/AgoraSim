#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PYTHON_BIN="${PYTHON_BIN:-python3}"
VENV_DIR="${VENV_DIR:-.venv-packaging}"

"$PYTHON_BIN" -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"

python -m pip install --upgrade pip
python -m pip install -e ".[desktop]"
python -m PyInstaller --clean --noconfirm packaging/pyinstaller/agorasim-macos.spec

if command -v hdiutil >/dev/null 2>&1; then
  mkdir -p dist/installer
  rm -f dist/installer/AgoraSim-macOS.dmg
  hdiutil create \
    -volname "AgoraSim" \
    -srcfolder "dist/AgoraSim.app" \
    -ov \
    -format UDZO \
    "dist/installer/AgoraSim-macOS.dmg"
  echo "Created dist/installer/AgoraSim-macOS.dmg"
else
  echo "Created dist/AgoraSim.app"
  echo "hdiutil not found; skipping DMG creation."
fi
