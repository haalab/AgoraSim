# AgoraSim Desktop Packaging

AgoraSim desktop builds use the same architecture on macOS and Windows:

1. The user launches the installed app.
2. A small startup window lets them choose the local port.
3. The app starts FastAPI on `127.0.0.1:<port>`.
4. The app opens the system browser at the local URL.
5. Closing the control window stops the local server.

API keys remain local to the running process and are not written to disk.

## Local Launcher

During development:

```bash
python -m agorasim.desktop
```

Useful options:

```bash
python -m agorasim.desktop --port 8000
python -m agorasim.desktop --port 8080 --strict-port
python -m agorasim.desktop --no-dialog --no-status-window
python -m agorasim.desktop --no-browser
```

The user-facing config is stored at:

- macOS: `~/Library/Application Support/AgoraSim/config.json`
- Windows: `%APPDATA%\AgoraSim\config.json`
- Linux/dev fallback: `~/.agorasim/config.json`

If the selected port is busy and `strict_port` is disabled, AgoraSim uses the
next available port and shows the actual local URL in the status window.

## macOS Build

Run on macOS:

```bash
bash packaging/build_macos.sh
```

Outputs:

- `dist/AgoraSim.app`
- `dist/installer/AgoraSim-macOS.dmg` when `hdiutil` is available

Commercial distribution still needs Apple signing and notarization, for
example:

```bash
codesign --deep --force --options runtime --sign "Developer ID Application: YOUR TEAM" dist/AgoraSim.app
xcrun notarytool submit dist/installer/AgoraSim-macOS.dmg --keychain-profile YOUR_PROFILE --wait
xcrun stapler staple dist/installer/AgoraSim-macOS.dmg
```

## Windows Build

Run on Windows PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1
```

Outputs:

- `dist\AgoraSim\AgoraSim.exe`
- `dist\installer\AgoraSimSetup.exe` when Inno Setup is installed

Install Inno Setup from <https://jrsoftware.org/isinfo.php> and make sure
`iscc.exe` is on `PATH` to create the installer.

Commercial distribution should sign both the executable and installer:

```powershell
signtool sign /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 /a dist\AgoraSim\AgoraSim.exe
signtool sign /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 /a dist\installer\AgoraSimSetup.exe
```

## Notes

- Build on the target OS. A macOS machine builds the `.app`; a Windows machine
  builds the `.exe`.
- The app binds only to `127.0.0.1`, not the public network interface.
- The PyInstaller specs intentionally use one-folder builds for reliability.
- No model API keys are bundled. Users paste their own keys after opening the
  local app.
