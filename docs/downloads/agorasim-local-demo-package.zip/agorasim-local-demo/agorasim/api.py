"""FastAPI service. Run: uvicorn agorasim.api:app --reload"""
from __future__ import annotations

import asyncio
import time
from pathlib import Path

from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, PlainTextResponse
from pydantic import BaseModel, Field

from .composer import ComposeError, compose_scenario
from .engine import Simulator, estimate_cost
from .experiments import ExperimentSpec, build_experiment_config
from .examples import (CENTRAL_BANK_EXAMPLE, PRODUCT_LAUNCH_EXAMPLE,
                       SOCIAL_POST_EXAMPLE)
from .model_registry import (fetch_provider_models, merge_models,
                             plan_mix_for_budget, plan_models_for_fixed_mix,
                             seed_models)
from .personas import derive_population_spec, persona_prompt_block, sample_personas
from .providers import (DecisionContext, get_runtime_base_url, get_runtime_key,
                        key_status, make_provider, set_runtime_base_url,
                        set_runtime_key)
from .scenarios import get_templates
from .schemas import (ABMBaselineSpec, ABMParams, CostEstimate, ModelMix,
                      ModelSlot, Persona, PopulationSpec, ProviderName,
                      SimulationConfig, SimulationResult, SimulationStatus)

app = FastAPI(title="AgoraSim", version="1.0.0",
              description="Generative agent-based modeling platform")

# in-memory store; swap for Redis/Postgres in production multi-tenant setup
_STORE: dict[str, SimulationResult] = {}
_TASKS: dict[str, asyncio.Task] = {}
_EXPERIMENTS: dict[str, dict] = {}


@app.get("/health")
async def health():
    return {"ok": True, "service": "agorasim"}


async def _run_simulation_task(sim: Simulator) -> None:
    try:
        await sim.run()
    except asyncio.CancelledError:
        sim.result.status = SimulationStatus.cancelled
        sim.result.error = "使用者已中斷模擬"
        raise


def _start_simulation(config: SimulationConfig) -> Simulator:
    sim = Simulator(config)
    _STORE[sim.result.id] = sim.result
    _TASKS[sim.result.id] = asyncio.create_task(_run_simulation_task(sim))
    return sim


def _classic_baseline_config(config: SimulationConfig,
                             spec: ABMBaselineSpec | None = None
                             ) -> SimulationConfig:
    baseline = config.model_copy(deep=True)
    if spec is not None:
        baseline.abm = spec.abm.model_copy(deep=True)
        baseline.abm.classic_model = spec.model
    baseline.model_mix = ModelMix(slots=[
        ModelSlot(provider=ProviderName.classic, weight=1,
                  model="classic-family-v2")
    ])
    baseline.analyst_provider = ProviderName.classic
    baseline.analyst_model = None
    # A zero hard budget would route even free classic agents to the random
    # fallback, so keep a tiny positive ceiling for all-classic comparison runs.
    baseline.max_cost_usd = max(float(config.max_cost_usd or 0), 0.01)
    return baseline


def _random_baseline_config(config: SimulationConfig) -> SimulationConfig:
    baseline = config.model_copy(deep=True)
    baseline.model_mix = ModelMix(slots=[
        ModelSlot(provider=ProviderName.random, weight=1,
                  model="random-walk")
    ])
    baseline.analyst_provider = ProviderName.random
    baseline.analyst_model = None
    baseline.max_cost_usd = max(float(config.max_cost_usd or 0), 0.01)
    return baseline


def _start_research_bundle(config: SimulationConfig) -> dict:
    if config.population.seed is None:
        config.population.seed = int(time.time() * 1000) % 2_147_483_647
    main = _start_simulation(config)
    runs = [{
        "role": "current",
        "id": main.result.id,
        "label": "Current run",
        "model": "current",
        "status": main.result.status,
        "estimate": estimate_cost(config).model_dump(),
    }]
    if config.comparison.run_random_baseline:
        random_cfg = _random_baseline_config(config)
        random_sim = _start_simulation(random_cfg)
        runs.append({
            "role": "random_baseline",
            "id": random_sim.result.id,
            "label": "Random baseline",
            "model": "random",
            "status": random_sim.result.status,
            "estimate": estimate_cost(random_cfg).model_dump(),
        })
    for spec in config.comparison.abm_baselines:
        if not spec.enabled:
            continue
        baseline_cfg = _classic_baseline_config(config, spec)
        baseline = _start_simulation(baseline_cfg)
        runs.append({
            "role": "abm_baseline",
            "id": baseline.result.id,
            "label": spec.label,
            "model": spec.model,
            "baseline_spec": spec.model_dump(mode="json"),
            "status": baseline.result.status,
            "estimate": estimate_cost(baseline_cfg).model_dump(),
        })
    return {
        "id": main.result.id,
        "status": main.result.status,
        "estimate": estimate_cost(config).model_dump(),
        "runs": runs,
        "comparison_run_ids": [r["id"] for r in runs[1:]],
    }


@app.post("/api/simulations", response_model=dict)
async def create_simulation(config: SimulationConfig):
    sim = _start_simulation(config)
    return {"id": sim.result.id, "status": sim.result.status,
            "estimate": estimate_cost(config).model_dump()}


class SimulationWithBaselineRequest(BaseModel):
    config: SimulationConfig
    include_classic_baseline: bool = True


@app.post("/api/simulations/research", response_model=dict)
async def create_research_simulation(req: SimulationWithBaselineRequest):
    config = req.config.model_copy(deep=True)
    if req.include_classic_baseline and not config.comparison.abm_baselines:
        config.comparison.abm_baselines = [
            ABMBaselineSpec(
                id="threshold", label="Threshold / Bass",
                model="threshold", enabled=True,
                abm=config.abm.model_copy(deep=True))
        ]
    if not req.include_classic_baseline:
        config.comparison.abm_baselines = []
        config.comparison.run_random_baseline = False
    return _start_research_bundle(config)


@app.post("/api/simulations/with-classic-baseline", response_model=dict)
async def create_simulation_with_classic_baseline(
        req: SimulationWithBaselineRequest):
    out = await create_research_simulation(req)
    baseline = next((r for r in out["runs"]
                     if r["role"] == "abm_baseline"), None)
    out["classic_baseline_id"] = baseline["id"] if baseline else None
    out["classic_baseline_status"] = baseline["status"] if baseline else None
    out["classic_baseline_estimate"] = baseline["estimate"] if baseline else None
    return out


@app.post("/api/experiments/simple", response_model=dict)
async def create_simple_experiment(spec: ExperimentSpec):
    config, plan = await build_experiment_config(spec)
    sim = _start_simulation(config)
    _EXPERIMENTS[sim.result.id] = {
        "spec": spec.model_dump(mode="json"),
        "plan": plan.model_dump(mode="json"),
        "resolved_config": config.model_dump(mode="json"),
    }
    return {
        "id": sim.result.id,
        "status": sim.result.status,
        "estimate": estimate_cost(config).model_dump(),
        "plan": plan.model_dump(mode="json"),
        "resolved_config": config.model_dump(mode="json"),
    }


@app.post("/api/experiments/batch", response_model=dict)
async def create_experiment_batch(specs: list[ExperimentSpec]):
    created = []
    for spec in specs:
        created.append(await create_simple_experiment(spec))
    return {"count": len(created), "experiments": created}


@app.get("/api/experiments/{exp_id}", response_model=dict)
async def get_experiment(exp_id: str, include_records: bool = False):
    res = _STORE.get(exp_id)
    if res is None:
        raise HTTPException(404, "experiment not found")
    meta = _EXPERIMENTS.get(exp_id, {})
    payload = res if include_records else res.model_copy(update={"records": []})
    return {"id": exp_id, **meta, "result": payload.model_dump(mode="json")}


@app.get("/api/experiments/{exp_id}/report", response_class=PlainTextResponse)
async def get_experiment_report(exp_id: str):
    return await get_report(exp_id)


@app.get("/api/experiments/{exp_id}/records")
async def get_experiment_records(exp_id: str, round_no: Optional[int] = None,
                                 agent_id: Optional[str] = None,
                                 limit: int = 120):
    return await get_records(exp_id, round_no=round_no,
                             agent_id=agent_id, limit=limit)


@app.post("/api/simulations/{sim_id}/cancel", response_model=dict)
async def cancel_simulation(sim_id: str):
    res = _STORE.get(sim_id)
    if res is None:
        raise HTTPException(404, "simulation not found")
    task = _TASKS.get(sim_id)
    if task and not task.done():
        task.cancel()
    res.status = SimulationStatus.cancelled
    res.error = "使用者已中斷模擬"
    return {"id": sim_id, "status": res.status}


@app.get("/api/simulations/{sim_id}", response_model=SimulationResult)
async def get_simulation(sim_id: str, include_records: bool = False):
    res = _STORE.get(sim_id)
    if res is None:
        raise HTTPException(404, "simulation not found")
    if include_records:
        return res
    return res.model_copy(update={"records": []})


@app.get("/api/simulations", response_model=list[dict])
async def list_simulations():
    return [{"id": r.id, "status": r.status, "progress": r.progress,
             "title": r.config.event.title if r.config else "",
             "created_at": r.created_at} for r in _STORE.values()]


@app.get("/api/simulations/{sim_id}/report", response_class=PlainTextResponse)
async def get_report(sim_id: str):
    res = _STORE.get(sim_id)
    if res is None:
        raise HTTPException(404, "simulation not found")
    return res.summary_markdown or "(報告尚未產生)"


@app.get("/api/simulations/{sim_id}/records")
async def get_records(sim_id: str, round_no: Optional[int] = None,
                      agent_id: Optional[str] = None, limit: int = 120):
    res = _STORE.get(sim_id)
    if res is None:
        raise HTTPException(404, "simulation not found")
    records = res.records
    if round_no is not None:
        records = [r for r in records if r.round == round_no]
    if agent_id is not None:
        records = [r for r in records if r.agent_id == agent_id]
    records = records[-max(1, min(limit, 1000)):]
    return {"id": sim_id, "count": len(records),
            "records": [r.model_dump() for r in records]}


@app.post("/api/estimate", response_model=CostEstimate)
async def estimate(config: SimulationConfig):
    return estimate_cost(config)


@app.get("/api/defaults")
async def defaults():
    return {"central_bank": CENTRAL_BANK_EXAMPLE.model_dump(),
            "product_launch": PRODUCT_LAUNCH_EXAMPLE.model_dump(),
            "social_post": SOCIAL_POST_EXAMPLE.model_dump()}


@app.get("/api/templates")
async def templates(locale: str = "en"):
    """Localized scenario templates (zh-TW / en / ja) for the UI."""
    return get_templates(locale)


# ------------------------------------------------------------ providers/models

@app.get("/api/providers/status")
async def provider_status():
    """Provider readiness without leaking secrets."""
    status = key_status()
    return {
        "keys": status,
        "providers": {
            "claude": {"configured": status.get("claude", False)},
            "openai": {"configured": status.get("openai", False)},
            "gemini": {"configured": status.get("gemini", False)},
            "custom": {"configured": status.get("custom", False),
                       "base_url": status.get("custom_base_url", False)},
            "random": {"configured": True},
            "classic": {"configured": True},
        },
    }


@app.get("/api/providers/models")
async def provider_models(provider: Optional[str] = None, refresh: bool = False,
                          custom_base_url: Optional[str] = None):
    """Seed catalog plus live provider model-list overlay when requested."""
    wanted = [provider] if provider else ["openai", "claude", "gemini",
                                          "custom", "random", "classic"]
    seed = []
    live = []
    warnings: list[str] = []
    for name in wanted:
        seed.extend(seed_models(name))
        if not refresh or name in ("random", "classic"):
            continue
        key = get_runtime_key(name)
        if name in ("openai", "claude", "gemini") and not key:
            warnings.append(f"{name}: no API key configured")
            continue
        try:
            live.extend(await fetch_provider_models(
                name, key,
                base_url=custom_base_url or get_runtime_base_url("custom")))
        except Exception as e:  # noqa: BLE001
            warnings.append(f"{name}: {type(e).__name__}: {e}")
    return {"models": merge_models(seed, live),
            "warnings": warnings, "status": key_status()}


class ProviderVerifyRequest(BaseModel):
    provider: str
    model: Optional[str] = None
    base_url: Optional[str] = None
    live_call: bool = False


class ProviderWeight(BaseModel):
    provider: str
    model: Optional[str] = None
    weight_pct: float


class MixPlanRequest(BaseModel):
    budget_usd: float
    n_agents: int = 40
    rounds: int = 3
    refresh: bool = False
    custom_base_url: Optional[str] = None
    provider_weights: list[ProviderWeight] = Field(default_factory=list)


def _verify_context() -> tuple[Persona, DecisionContext]:
    persona = Persona(
        agent_id="verify_0001", name="Verify User", age_bracket="35-44",
        gender="-", income="middle", region="test", education="college",
        occupation="tester", traits={"risk_tolerance": 0.5,
                                     "conformity": 0.4},
        initial_stance=0.0, backstory="A neutral synthetic test persona.")
    ctx = DecisionContext(
        event_text="A neutral test event for API verification.",
        media=[], use_raw_media=False,
        goal_question="How would you react to this neutral test event?",
        action_space=["Support", "Wait", "Reject"],
        round_no=1, total_rounds=1, macro_text="The news just broke.",
        neighbor_statements=[], memory_text="", diversity_pressure=False,
        language="en", prev_stance=0.0, adoption_rate=0.0,
        abm=ABMParams())
    return persona, ctx


@app.post("/api/providers/verify")
async def verify_provider(req: ProviderVerifyRequest):
    """Verify provider/model reachability.

    For LLMs, live_call=false checks model-list access only. Set live_call=true
    to run one minimal decision call against the selected model.
    """
    name = req.provider.lower()
    if name not in {"claude", "openai", "gemini", "custom", "random", "classic"}:
        raise HTTPException(400, "unknown provider")

    if name in ("random", "classic"):
        slot = ModelSlot(provider=ProviderName(name), weight=1,
                         model=req.model)
        provider = make_provider(slot)
        persona, ctx = _verify_context()
        decision, tin, tout = await provider.decide(persona, ctx)
        return {"ok": True, "provider": name, "model": provider.model,
                "stage": "decision", "tokens": {"input": tin, "output": tout},
                "sample": decision.model_dump()}

    key = get_runtime_key(name)
    if name != "custom" and not key:
        return {"ok": False, "provider": name, "stage": "auth",
                "error": "missing API key"}
    custom_base = req.base_url or get_runtime_base_url("custom")
    if name == "custom" and not custom_base:
        return {"ok": False, "provider": name, "stage": "auth",
                "error": "missing custom base_url"}

    try:
        models = await fetch_provider_models(name, key, base_url=custom_base)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "provider": name, "stage": "models",
                "error": f"{type(e).__name__}: {e}"}

    selected = req.model or (models[0]["id"] if models else None)
    model_available = (not selected) or any(m["id"] == selected for m in models)
    if not req.live_call:
        return {"ok": True, "provider": name, "stage": "models",
                "model": selected, "model_available": model_available,
                "model_count": len(models)}

    slot = ModelSlot(provider=ProviderName(name), weight=1,
                     model=selected, base_url=custom_base)
    provider_obj = make_provider(slot)
    persona, ctx = _verify_context()
    try:
        decision, tin, tout = await provider_obj.decide(persona, ctx)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "provider": name, "model": selected,
                "stage": "decision", "error": f"{type(e).__name__}: {e}"}
    return {"ok": True, "provider": name, "model": selected,
            "stage": "decision", "model_available": model_available,
            "tokens": {"input": tin, "output": tout},
            "sample": decision.model_dump()}


@app.post("/api/providers/plan-mix")
async def plan_model_mix(req: MixPlanRequest):
    wanted = ["openai", "claude", "gemini", "custom", "random", "classic"]
    seed = []
    live = []
    warnings: list[str] = []
    for name in wanted:
        seed.extend(seed_models(name))
        if not req.refresh or name in ("random", "classic"):
            continue
        key = get_runtime_key(name)
        if name in ("openai", "claude", "gemini") and not key:
            warnings.append(f"{name}: no API key configured")
            continue
        try:
            live.extend(await fetch_provider_models(
                name, key,
                base_url=req.custom_base_url or get_runtime_base_url("custom")))
        except Exception as e:  # noqa: BLE001
            warnings.append(f"{name}: {type(e).__name__}: {e}")
    models = merge_models(seed, live)
    if req.provider_weights:
        plan = plan_models_for_fixed_mix(
            models, req.budget_usd, req.n_agents, req.rounds,
            [p.model_dump() for p in req.provider_weights])
    else:
        plan = plan_mix_for_budget(models, req.budget_usd, req.n_agents,
                                   req.rounds)
    plan["warnings"] = [*warnings, *plan.get("warnings", [])]
    return plan


# ------------------------------------------------------------ AI composer

class ComposeRequest(BaseModel):
    brief: str
    locale: str = "en"
    provider: Optional[str] = None      # claude | openai | gemini


@app.post("/api/compose")
async def compose(req: ComposeRequest):
    """One-line brief -> full scenario (question, actions, surveys, ABM)."""
    try:
        return await compose_scenario(req.brief, req.locale, req.provider)
    except ComposeError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"composer failed: {e}")


# ------------------------------------------------------------ API keys (BYOK)
# Keys are held in process memory only: never persisted to disk, never
# echoed back, never stored inside simulation results.

class KeysRequest(BaseModel):
    claude: Optional[str] = None
    openai: Optional[str] = None
    gemini: Optional[str] = None
    custom: Optional[str] = None
    custom_base_url: Optional[str] = None


@app.post("/api/keys")
async def set_keys(req: KeysRequest):
    for name in ("claude", "openai", "gemini", "custom"):
        val = getattr(req, name)
        if val is not None:              # empty string clears the key
            set_runtime_key(name, val)
    if req.custom_base_url is not None:
        set_runtime_base_url("custom", req.custom_base_url)
    return key_status()


@app.get("/api/keys/status")
async def get_key_status():
    return key_status()


class PersonaPreviewRequest(BaseModel):
    population: PopulationSpec = Field(default_factory=PopulationSpec)
    target_population: str = ""
    locale: str = "zh-TW"
    limit: int = 8


@app.post("/api/personas/preview")
async def preview_personas(req: PersonaPreviewRequest):
    spec = derive_population_spec(
        req.population, req.target_population, req.locale)
    personas = sample_personas(spec, spec.seed, req.locale)
    limit = max(1, min(req.limit, 20))
    return {
        "population": spec.model_dump(),
        "personas": [
            {**p.model_dump(), "prompt_block": persona_prompt_block(p, req.locale)}
            for p in personas[:limit]
        ],
    }


@app.get("/", response_class=HTMLResponse)
async def ui():
    html = Path(__file__).parent / "ui" / "index.html"
    return html.read_text(encoding="utf-8")
