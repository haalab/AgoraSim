"""Hybrid coupling with traditional ABM: macro environment + Bass reference."""
from __future__ import annotations

from .i18n import P
from .schemas import ABMParams, AgentDecision, SimulationGoal


class Environment:
    """Shared macro state: agents' aggregate behavior feeds macro variables,
    which are injected back into every agent's prompt next round."""

    def __init__(self, params: ABMParams, goal: SimulationGoal,
                 locale: str = "en"):
        self.params = params
        self.goal = goal
        self.locale = locale
        self.adopt_actions = {goal.action_space[i]
                              for i in goal.adopt_action_indices
                              if 0 <= i < len(goal.action_space)}
        self.macro: dict[str, float] = dict(params.macro_variables)
        self.sentiment_index: float = 0.0
        self.adoption_rate: float = 0.0
        self.bass_cum: float = 0.0        # theoretical Bass adoption (M=1)

    def bass_step(self) -> float:
        p, q, a = self.params.innovation_p, self.params.imitation_q, self.bass_cum
        self.bass_cum = min(1.0, a + (p + q * a) * (1 - a))
        return self.bass_cum

    def update(self, decisions: list[AgentDecision]) -> None:
        if not decisions:
            return
        stances = [d.stance for d in decisions]
        mean = sum(stances) / len(stances)
        s = self.params.sentiment_smoothing
        self.sentiment_index = s * self.sentiment_index + (1 - s) * mean
        self.adoption_rate = sum(d.action in self.adopt_actions
                                 for d in decisions) / len(decisions)

    def macro_text(self, round_no: int) -> str:
        pk = P(self.locale)
        parts = []
        if round_no > 1:
            mood = (pk["mood_pos"] if self.sentiment_index > 0.15 else
                    pk["mood_neg"] if self.sentiment_index < -0.15 else
                    pk["mood_mid"])
            parts.append(pk["macro_later"].format(
                pct=round(self.adoption_rate * 100), mood=mood))
        else:
            parts.append(pk["macro_first"])
        for k, v in self.macro.items():
            parts.append(f" {k}: {v}.")
        return "".join(parts)
