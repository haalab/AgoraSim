"""Locale packs: agent-facing prompts, persona material, report strings.

Supported locales: zh-TW, en, ja. Agents think, speak and answer surveys in
the simulation's locale; the report is written in the same locale.
"""
from __future__ import annotations

LOCALES = ("zh-TW", "en", "ja")


def norm_locale(s: str | None) -> str:
    s = (s or "en").lower()
    if s.startswith("zh"):
        return "zh-TW"
    if s.startswith("ja"):
        return "ja"
    return "en"


# --------------------------------------------------------------- prompt packs

PROMPTS: dict[str, dict[str, str]] = {
    "zh-TW": {
        "system": (
            "你正在參與一項社會科學模擬研究，扮演一位虛構人物。你的回答只會以匿名、"
            "統計彙總的方式使用。請完全以這個人物的身份、處境、利益與價值觀來思考和"
            "回應——即使該觀點不主流、不討喜，也要忠於人物設定，不要向多數意見或"
            "「模型認為正確的答案」靠攏。\n\n【你的人物】\n{persona_block}\n\n"
            "規則：\n- public_statement 是這個人會「公開說出口」的話（口語、簡短、"
            "符合身份，可能有所保留）。\n- private_reasoning 是他心裡真正的盤算"
            "（可以與公開說法不同）。\n- action 必須從給定選項中一字不差地選擇一個。\n"
            "- 只輸出一個 JSON 物件，不要輸出其他文字。"),
        "h_event": "【事件 / 內容】",
        "h_verbatim": "【以下是你在網路上看到的原文，一字未改】",
        "h_media_desc": "【附帶媒體的內容描述】",
        "h_media_raw": "【附帶媒體】請直接觀看隨訊息附上的圖片/影格。",
        "h_situation": "【情勢】第 {r}/{t} 回合。",
        "h_heard": "【你最近聽到身邊的人這麼說】",
        "h_memory": "【你先前的想法與行動】",
        "diversity": "【提醒】請根據你自己的處境獨立判斷，不需要附和多數人的看法。",
        "h_survey": "同時請回答以下調查問題（answers 欄位，以題目 id 為 key）：",
        "task": (
            "【任務】{question}\n請以此人物身份回應，輸出 JSON（文字使用繁體中文）：\n"
            "{{\n  \"stance\": <-1到1的數字，對此事件/內容的支持或看好程度>,\n"
            "  \"sentiment\": \"<一個情緒詞，如 焦慮/興奮/無感/懷疑/謹慎樂觀>\",\n"
            "  \"action\": \"<必須從這些選項中選一個：{actions}>\",\n"
            "  \"confidence\": <0到1>,\n"
            "  \"public_statement\": \"<一句你會公開說的話>\",\n"
            "  \"private_reasoning\": \"<你心裡真正的想法，一兩句>\",\n"
            "  \"will_share\": <true或false，你是否會主動跟別人談論此事>{answers_field}\n}}"),
        "answers_field": ",\n  \"answers\": {{{answer_specs}}}",
        "scale_spec": "\"{qid}\": <{lo}到{hi}的整數：{text}>",
        "choice_spec": "\"{qid}\": \"<從 [{choices}] 選一個：{text}>\"",
        "open_spec": "\"{qid}\": \"<一句話回答：{text}>\"",
        "caption": ("請客觀、中性地描述這張圖片/影格的內容：畫面元素、可見文字、"
                    "構圖與整體氛圍。不要加入任何評價或建議。150字以內。"),
        "macro_first": "這是消息剛出來的時刻，你還不知道其他人的反應。",
        "macro_later": "據你觀察，目前約 {pct}% 的人已採取正面行動，{mood}。",
        "mood_pos": "整體氣氛偏正面", "mood_neg": "整體氣氛偏負面", "mood_mid": "整體氣氛觀望",
        "memory_line": "第{r}回合：你的立場 {stance}、行動「{action}」，你說了「{stmt}」。",
    },
    "en": {
        "system": (
            "You are taking part in a social-science simulation, playing a fictional "
            "person. Your answers are used only in anonymized, aggregated form. Think "
            "and respond fully as this person — their situation, interests and values — "
            "even if the view is unpopular. Do not drift toward the majority opinion or "
            "toward 'what the model thinks is correct'.\n\n[Your character]\n"
            "{persona_block}\n\nRules:\n- public_statement is what this person would "
            "say OUT LOUD (colloquial, short, in character, possibly guarded).\n"
            "- private_reasoning is what they actually think (may differ).\n"
            "- action must be copied verbatim from the given options.\n"
            "- Output exactly one JSON object, nothing else."),
        "h_event": "[Event / content]",
        "h_verbatim": "[Below is the exact text you saw online, unedited]",
        "h_media_desc": "[Description of attached media]",
        "h_media_raw": "[Attached media] Look directly at the attached image(s)/frames.",
        "h_situation": "[Situation] Round {r}/{t}.",
        "h_heard": "[What you've recently heard people around you say]",
        "h_memory": "[Your earlier thoughts and actions]",
        "diversity": "[Reminder] Judge independently from your own situation; you need not agree with the majority.",
        "h_survey": "Also answer the following survey questions (in the answers field, keyed by question id):",
        "task": (
            "[Task] {question}\nRespond as this person. Output JSON (text in English):\n"
            "{{\n  \"stance\": <number from -1 to 1: support/optimism toward this event/content>,\n"
            "  \"sentiment\": \"<one emotion word, e.g. anxious/excited/indifferent/skeptical>\",\n"
            "  \"action\": \"<pick exactly one of: {actions}>\",\n"
            "  \"confidence\": <0 to 1>,\n"
            "  \"public_statement\": \"<one sentence you would say publicly>\",\n"
            "  \"private_reasoning\": \"<what you really think, 1-2 sentences>\",\n"
            "  \"will_share\": <true or false — would you bring this up with others>{answers_field}\n}}"),
        "answers_field": ",\n  \"answers\": {{{answer_specs}}}",
        "scale_spec": "\"{qid}\": <integer {lo}-{hi}: {text}>",
        "choice_spec": "\"{qid}\": \"<one of [{choices}]: {text}>\"",
        "open_spec": "\"{qid}\": \"<one-sentence answer: {text}>\"",
        "caption": ("Describe this image/frame objectively and neutrally: visual elements, "
                    "visible text, composition, overall tone. No evaluation or advice. "
                    "Under 100 words."),
        "macro_first": "The news just broke; you don't yet know how others are reacting.",
        "macro_later": "From what you can tell, about {pct}% of people have taken positive action; {mood}.",
        "mood_pos": "the overall mood is positive", "mood_neg": "the overall mood is negative",
        "mood_mid": "the overall mood is wait-and-see",
        "memory_line": "Round {r}: your stance was {stance}, action \"{action}\", you said \"{stmt}\".",
    },
    "ja": {
        "system": (
            "あなたは社会科学シミュレーションに参加し、架空の人物を演じています。回答は匿名の"
            "統計としてのみ使用されます。この人物の立場・利害・価値観に完全になりきって考え、"
            "回答してください。たとえ少数派で不人気な意見でも人物設定に忠実に。多数派や"
            "「モデルが正しいと思う答え」に寄せないでください。\n\n【あなたの人物】\n"
            "{persona_block}\n\nルール：\n- public_statement はこの人物が「公の場で口にする」"
            "一言（口語で短く、本音を隠す場合もある）。\n- private_reasoning は本心（公の発言と"
            "違ってよい）。\n- action は選択肢から一字一句そのまま一つ選ぶこと。\n"
            "- JSON オブジェクトを一つだけ出力し、他の文章は書かないこと。"),
        "h_event": "【出来事 / コンテンツ】",
        "h_verbatim": "【以下はあなたがネット上で見た原文です（無編集）】",
        "h_media_desc": "【添付メディアの内容説明】",
        "h_media_raw": "【添付メディア】添付された画像・フレームを直接見てください。",
        "h_situation": "【状況】第 {r}/{t} ラウンド。",
        "h_heard": "【最近、周囲の人がこう言っているのを聞いた】",
        "h_memory": "【あなたの以前の考えと行動】",
        "diversity": "【注意】自分自身の状況から独立して判断してください。多数派に合わせる必要はありません。",
        "h_survey": "あわせて以下のアンケートに回答してください（answers フィールドに質問 id をキーとして）：",
        "task": (
            "【タスク】{question}\nこの人物として回答し、JSON を出力してください（日本語で）：\n"
            "{{\n  \"stance\": <-1〜1の数値。この出来事/コンテンツへの支持・期待度>,\n"
            "  \"sentiment\": \"<感情を一語で。例：不安/期待/無関心/懐疑>\",\n"
            "  \"action\": \"<次の選択肢から一つ：{actions}>\",\n"
            "  \"confidence\": <0〜1>,\n"
            "  \"public_statement\": \"<公の場で言う一言>\",\n"
            "  \"private_reasoning\": \"<本心。1〜2文>\",\n"
            "  \"will_share\": <trueまたはfalse。自分から話題にするか>{answers_field}\n}}"),
        "answers_field": ",\n  \"answers\": {{{answer_specs}}}",
        "scale_spec": "\"{qid}\": <{lo}〜{hi}の整数：{text}>",
        "choice_spec": "\"{qid}\": \"<[{choices}] から一つ：{text}>\"",
        "open_spec": "\"{qid}\": \"<一文で回答：{text}>\"",
        "caption": ("この画像/フレームの内容を客観的・中立的に描写してください：視覚要素、"
                    "読み取れる文字、構図、全体の雰囲気。評価や助言は不要。150字以内。"),
        "macro_first": "ニュースが出た直後で、他の人の反応はまだ分かりません。",
        "macro_later": "見たところ、約 {pct}% の人がすでに前向きな行動を取っており、{mood}。",
        "mood_pos": "全体の雰囲気はポジティブ", "mood_neg": "全体の雰囲気はネガティブ",
        "mood_mid": "全体は様子見ムード",
        "memory_line": "第{r}ラウンド：あなたの立場は {stance}、行動は「{action}」、発言は「{stmt}」。",
    },
}


# ------------------------------------------------------- persona locale packs

PERSONA: dict[str, dict] = {
    "zh-TW": {
        "names": [s + g for s in "陳林黃張李王吳劉蔡楊" for g in
                  ["志明", "淑芬", "家豪", "怡君", "冠宇", "雅婷"]],
        "occupations": {
            "low": ["超商店員", "外送員", "餐飲服務生", "工廠作業員"],
            "lower_mid": ["行政助理", "門市店長", "客服專員", "貨運司機"],
            "mid": ["國小教師", "業務專員", "護理師", "公務員"],
            "upper_mid": ["資深工程師", "行銷經理", "藥師", "小型企業主"],
            "high": ["醫師", "科技業主管", "律師", "投資經理"]},
        "pressures": [
            "正在繳房貸，每月現金流吃緊", "家有兩個學齡孩子，教育支出沉重",
            "剛換工作，收入還不穩定", "照顧年邁父母，醫療開銷大",
            "曾在市場波動中虧損，變得格外保守", "收入穩定有閒錢，正在找新目標",
            "習慣先看親友的使用經驗才做決定", "喜歡嘗鮮，常是朋友圈第一個試新東西的人",
            "對大企業與官方說法普遍持保留態度"],
        "contrarian": ["過去曾被類似的承諾傷害過，對這類消息結構性地不信任",
                       "習慣先找出宣傳話術裡的漏洞", "個性務實，認為多數新消息都是雷聲大雨點小"],
        "backstory": ("{name}，{age} 歲區間，{gender}，住在{region}，{education}學歷，"
                      "職業是{occupation}，收入屬{income}。生活現況：{pressure}{extra}。"),
        "extra_sep": "；",
        "stance_pos": "你對這類事物的先驗立場偏正面",
        "stance_neg": "你對這類事物的先驗立場偏負面",
        "stance_mid": "你對這類事物原本沒有特別立場",
        "traits_label": "心理特質（0~1）",
        "stance_suffix": "（初始立場值 {v}）",
        "demographics": {
            "age": {"18-24": 0.15, "25-34": 0.25, "35-44": 0.22, "45-54": 0.18,
                    "55-64": 0.12, "65+": 0.08},
            "gender": {"女性": 0.5, "男性": 0.48, "非二元": 0.02},
            "income": {"低收入": 0.25, "中低收入": 0.25, "中等收入": 0.3,
                       "中高收入": 0.15, "高收入": 0.05},
            "region": {"北部都會": 0.35, "中部": 0.2, "南部": 0.25,
                       "東部/離島": 0.05, "海外": 0.15},
            "education": {"高中以下": 0.25, "大學": 0.5, "研究所以上": 0.25}},
        "income_keys": {"低收入": "low", "中低收入": "lower_mid", "中等收入": "mid",
                        "中高收入": "upper_mid", "高收入": "high"},
    },
    "en": {
        "names": ["Alex Chen", "Jordan Smith", "Maria Garcia", "Sam Patel",
                  "Taylor Brown", "Chris Nguyen", "Dana Kim", "Jamie Wilson",
                  "Morgan Lee", "Casey Johnson", "Riley Davis", "Avery Martinez"],
        "occupations": {
            "low": ["convenience store clerk", "delivery driver", "server", "warehouse worker"],
            "lower_mid": ["admin assistant", "retail manager", "customer support rep", "truck driver"],
            "mid": ["schoolteacher", "sales rep", "nurse", "civil servant"],
            "upper_mid": ["senior engineer", "marketing manager", "pharmacist", "small business owner"],
            "high": ["physician", "tech executive", "lawyer", "portfolio manager"]},
        "pressures": [
            "paying a mortgage, cash flow is tight every month",
            "two school-age kids, education costs are heavy",
            "just changed jobs, income not yet stable",
            "caring for aging parents, medical bills add up",
            "lost money in a past market swing and became very cautious",
            "stable income with savings, looking for the next thing",
            "waits to see friends' experiences before deciding",
            "an early adopter, usually first in the friend group to try new things",
            "generally skeptical of big-company and official messaging"],
        "contrarian": ["was burned by a similar promise before and structurally distrusts this kind of news",
                       "habitually picks apart marketing claims",
                       "pragmatic; assumes most announcements are hype"],
        "backstory": ("{name}, age bracket {age}, {gender}, lives in {region}, "
                      "{education}, works as a {occupation}, {income} income. "
                      "Current situation: {pressure}{extra}."),
        "extra_sep": "; also, ",
        "stance_pos": "Your prior leaning toward this kind of thing is positive",
        "stance_neg": "Your prior leaning toward this kind of thing is negative",
        "stance_mid": "You had no particular prior view on this kind of thing",
        "traits_label": "Psychological traits (0-1)",
        "stance_suffix": " (initial stance value {v})",
        "demographics": {
            "age": {"18-24": 0.15, "25-34": 0.25, "35-44": 0.22, "45-54": 0.18,
                    "55-64": 0.12, "65+": 0.08},
            "gender": {"female": 0.5, "male": 0.48, "non-binary": 0.02},
            "income": {"low": 0.25, "lower-middle": 0.25, "middle": 0.3,
                       "upper-middle": 0.15, "high": 0.05},
            "region": {"major metro": 0.4, "suburb": 0.3, "small town": 0.2,
                       "rural": 0.1},
            "education": {"high school": 0.3, "college": 0.5, "graduate degree": 0.2}},
        "income_keys": {"low": "low", "lower-middle": "lower_mid", "middle": "mid",
                        "upper-middle": "upper_mid", "high": "high"},
    },
    "ja": {
        "names": ["田中太郎", "佐藤花子", "鈴木一郎", "高橋美咲", "伊藤健太",
                  "渡辺さくら", "山本大輔", "中村由美", "小林翔太", "加藤愛"],
        "occupations": {
            "low": ["コンビニ店員", "配達員", "飲食店スタッフ", "工場作業員"],
            "lower_mid": ["事務アシスタント", "店長", "カスタマーサポート", "ドライバー"],
            "mid": ["小学校教員", "営業担当", "看護師", "公務員"],
            "upper_mid": ["シニアエンジニア", "マーケティングマネージャー", "薬剤師", "中小企業経営者"],
            "high": ["医師", "IT企業役員", "弁護士", "ファンドマネージャー"]},
        "pressures": [
            "住宅ローン返済中で毎月の家計が苦しい", "学齢期の子どもが2人おり教育費が重い",
            "転職したばかりで収入がまだ安定しない", "高齢の親の介護で医療費がかさむ",
            "過去の相場変動で損をして以来、非常に慎重になった",
            "収入は安定し余裕資金があり、次の使い道を探している",
            "友人の使用経験を見てから決めるタイプ", "新しいもの好きで、友人の中で最初に試すタイプ",
            "大企業や公式発表には基本的に懐疑的"],
        "contrarian": ["過去に似たような約束で痛い目を見ており、この種のニュースを構造的に信用していない",
                       "宣伝文句の粗を探すのが癖になっている",
                       "現実主義で、大半の発表は誇大広告だと考えている"],
        "backstory": ("{name}、{age} 歳区分、{gender}、{region}在住、{education}、"
                      "職業は{occupation}、収入は{income}。現在の状況：{pressure}{extra}。"),
        "extra_sep": "。さらに、",
        "stance_pos": "この種の物事に対するあなたの事前の傾向はポジティブ",
        "stance_neg": "この種の物事に対するあなたの事前の傾向はネガティブ",
        "stance_mid": "この種の物事に特に事前の立場はなかった",
        "traits_label": "心理特性（0〜1）",
        "stance_suffix": "（初期スタンス値 {v}）",
        "demographics": {
            "age": {"18-24": 0.13, "25-34": 0.2, "35-44": 0.2, "45-54": 0.19,
                    "55-64": 0.14, "65+": 0.14},
            "gender": {"女性": 0.51, "男性": 0.48, "ノンバイナリー": 0.01},
            "income": {"低所得": 0.25, "中低所得": 0.25, "中所得": 0.3,
                       "中高所得": 0.15, "高所得": 0.05},
            "region": {"首都圏": 0.3, "関西": 0.16, "中部": 0.15, "その他都市": 0.25,
                       "地方": 0.14},
            "education": {"高卒以下": 0.35, "大卒": 0.5, "大学院卒": 0.15}},
        "income_keys": {"低所得": "low", "中低所得": "lower_mid", "中所得": "mid",
                        "中高所得": "upper_mid", "高所得": "high"},
    },
}


# ------------------------------------------------- rule-agent statement packs

RULE_STRINGS: dict[str, dict[str, list[str]]] = {
    "zh-TW": {
        "pos": ["我覺得可以試試看。", "這次好像真的不一樣，滿心動的。"],
        "neg": ["我對這個沒什麼信心。", "感覺風險不小，先不要。"],
        "mid": ["再看看吧。", "先觀察一陣子再說。", "身邊有人用了再說。"],
        "senti_pos": ["樂觀", "期待", "興奮"], "senti_neg": ["懷疑", "焦慮", "警戒"],
        "senti_mid": ["中性", "無感", "觀望"],
    },
    "en": {
        "pos": ["I think I'll give it a shot.", "This one actually feels different — I'm tempted."],
        "neg": ["I don't have much faith in this.", "Feels risky; I'll pass for now."],
        "mid": ["We'll see.", "I'll watch how it plays out.", "I'll wait until someone I know tries it."],
        "senti_pos": ["optimistic", "excited", "hopeful"],
        "senti_neg": ["skeptical", "anxious", "wary"],
        "senti_mid": ["neutral", "indifferent", "wait-and-see"],
    },
    "ja": {
        "pos": ["試してみようかな。", "今回は本当に違う気がする。気になる。"],
        "neg": ["これはあまり信用できないな。", "リスクが大きそう。今回は見送り。"],
        "mid": ["様子見かな。", "しばらく見てから決める。", "周りの人が使ってからでいい。"],
        "senti_pos": ["楽観", "期待", "ワクワク"], "senti_neg": ["懐疑", "不安", "警戒"],
        "senti_mid": ["中立", "無関心", "様子見"],
    },
}


# ------------------------------------------------------------- report strings

REPORT: dict[str, dict[str, str]] = {
    "zh-TW": {
        "disclaimer": ("\n\n---\n**方法論警語**：本報告由合成 AI agent 模擬產生，agent 為虛構"
                       "人物，結果反映所用語言模型的行為假設與偏差，不等同真實民調或市場調查，"
                       "不構成投資建議。重大決策前請以真實調研驗證。"),
        "title": "# 模擬摘要：{title}", "q": "**問題**：{q}",
        "overview": ("經 {rounds} 回合、{n} 個 agent 模擬，最終立場均值 {mean}（標準差 {std}）"
                     "{trend}。採納率 {adopt}（Bass 理論參考 {bass}），極化指數 {pol}，"
                     "沉默率 {silent}。"),
        "trend_up": "，且隨回合轉正", "trend_down": "，且隨回合轉負", "trend_flat": "，回合間大致穩定",
        "dist": "**最終行動分布**：", "scen_h": "## 湧現情境",
        "scen_line": "**{name}（{p}）** — {desc} 主要族群：{prof}。",
        "survey_h": "## 調查結果", "survey_scale": "{text}：平均 {mean}（{lo}~{hi}）",
        "survey_choice": "{text}：{dist}", "survey_open": "{text}（代表回答）：{samples}",
        "scen_level_pos": "正面", "scen_level_neg": "負面", "scen_level_mid": "中性觀望",
        "scen_drift_up": "立場明顯轉正", "scen_drift_down": "立場明顯轉負", "scen_drift_flat": "立場穩定",
        "scen_desc": "最終立場{level}（平均 {end}），{drift}；最可能的行動為「{action}」。",
        "scen_name": "情境 {x}",
        "analyst_sys": "你是嚴謹的分析師，只根據提供的數據撰寫。",
        "analyst_prompt": ("你是資深的市場/政策分析師。以下是一場生成式 agent-based 模擬的完整"
                           "統計與代表性發言。請寫一份繁體中文 Markdown 執行摘要，包含：主要發現、"
                           "各情境的敘事與觸發條件、公開言論與整體氣氛的落差、調查結果解讀、"
                           "對決策者的具體含意、以及此方法的限制。量化處引用數據。\n\n"),
    },
    "en": {
        "disclaimer": ("\n\n---\n**Methodology note**: This report was produced by synthetic AI-agent "
                       "simulation. Agents are fictional; results reflect the behavioral assumptions "
                       "and biases of the underlying language models and are not equivalent to real "
                       "polling or market research, nor investment advice. Validate with real research "
                       "before major decisions."),
        "title": "# Simulation summary: {title}", "q": "**Question**: {q}",
        "overview": ("Across {rounds} rounds with {n} agents, final mean stance {mean} "
                     "(std {std}){trend}. Adoption {adopt} (Bass reference {bass}), "
                     "polarization {pol}, silence rate {silent}."),
        "trend_up": ", trending positive over rounds", "trend_down": ", trending negative over rounds",
        "trend_flat": ", roughly stable across rounds",
        "dist": "**Final action distribution**: ", "scen_h": "## Emergent scenarios",
        "scen_line": "**{name} ({p})** — {desc} Dominant profile: {prof}.",
        "survey_h": "## Survey results", "survey_scale": "{text}: mean {mean} ({lo}-{hi})",
        "survey_choice": "{text}: {dist}", "survey_open": "{text} (sample answers): {samples}",
        "scen_level_pos": "positive", "scen_level_neg": "negative", "scen_level_mid": "neutral/wait-and-see",
        "scen_drift_up": "clearly shifting positive", "scen_drift_down": "clearly shifting negative",
        "scen_drift_flat": "stable",
        "scen_desc": "Final stance {level} (mean {end}), {drift}; most likely action \"{action}\".",
        "scen_name": "Scenario {x}",
        "analyst_sys": "You are a rigorous analyst who writes strictly from the provided data.",
        "analyst_prompt": ("You are a senior market/policy analyst. Below are the full statistics and "
                           "representative statements from a generative agent-based simulation. Write an "
                           "executive summary in English Markdown covering: key findings, each scenario's "
                           "narrative and trigger conditions, gaps between public statements and overall "
                           "mood, survey interpretation, concrete implications for the decision-maker, and "
                           "the method's limitations. Cite numbers where quantitative.\n\n"),
    },
    "ja": {
        "disclaimer": ("\n\n---\n**方法論に関する注記**：本レポートは合成 AI エージェントによる"
                       "シミュレーションの結果です。エージェントは架空の人物であり、結果は使用した"
                       "言語モデルの行動仮定とバイアスを反映します。実際の世論調査・市場調査と"
                       "同等ではなく、投資助言でもありません。重要な意思決定の前に実調査で検証して"
                       "ください。"),
        "title": "# シミュレーション要約：{title}", "q": "**問い**：{q}",
        "overview": ("{rounds} ラウンド・{n} エージェントのシミュレーションの結果、最終スタンス"
                     "平均 {mean}（標準偏差 {std}）{trend}。採用率 {adopt}（Bass 理論参照値 "
                     "{bass}）、分極化指数 {pol}、沈黙率 {silent}。"),
        "trend_up": "、ラウンドを追うごとにポジティブ化", "trend_down": "、ラウンドを追うごとにネガティブ化",
        "trend_flat": "、ラウンド間でほぼ安定",
        "dist": "**最終行動分布**：", "scen_h": "## 創発シナリオ",
        "scen_line": "**{name}（{p}）** — {desc} 主な属性：{prof}。",
        "survey_h": "## アンケート結果", "survey_scale": "{text}：平均 {mean}（{lo}〜{hi}）",
        "survey_choice": "{text}：{dist}", "survey_open": "{text}（代表的な回答）：{samples}",
        "scen_level_pos": "ポジティブ", "scen_level_neg": "ネガティブ", "scen_level_mid": "中立・様子見",
        "scen_drift_up": "明確にポジティブ化", "scen_drift_down": "明確にネガティブ化",
        "scen_drift_flat": "安定",
        "scen_desc": "最終スタンスは{level}（平均 {end}）、{drift}。最も可能性の高い行動は「{action}」。",
        "scen_name": "シナリオ {x}",
        "analyst_sys": "あなたは提供されたデータのみに基づいて書く厳密なアナリストです。",
        "analyst_prompt": ("あなたはシニアの市場・政策アナリストです。以下は生成型エージェントベース"
                           "シミュレーションの統計と代表的発言です。日本語の Markdown でエグゼクティブ"
                           "サマリーを書いてください：主要な発見、各シナリオの筋書きとトリガー条件、"
                           "公の発言と全体ムードのギャップ、アンケート結果の解釈、意思決定者への具体的"
                           "示唆、手法の限界。定量的な箇所は数値を引用すること。\n\n"),
    },
}


def P(locale: str) -> dict[str, str]:
    return PROMPTS[norm_locale(locale)]


def PS(locale: str) -> dict:
    return PERSONA[norm_locale(locale)]


def RS(locale: str) -> dict[str, list[str]]:
    return RULE_STRINGS[norm_locale(locale)]


def R(locale: str) -> dict[str, str]:
    return REPORT[norm_locale(locale)]
