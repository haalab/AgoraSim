"""Simple experiment facade for SDK, REST and CLI users.

Researchers can provide a compact study brief while AgoraSim resolves the
scenario, model plan, persona population and simulation config underneath.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import mimetypes
from pathlib import Path
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

from .composer import ComposeError, compose_scenario
from .engine import Simulator, estimate_cost
from .model_registry import (merge_models, plan_mix_for_budget,
                             plan_models_for_fixed_mix, seed_models)
from .providers import get_runtime_key
from .schemas import (ABMBaselineSpec, ABMParams, ComparisonPlan, EventInput,
                      InteractionSettings, MediaAsset, MediaType, ModelMix,
                      ModelSlot, PopulationSpec, PromptSettings, ProviderName,
                      SimulationConfig, SimulationResult, SurveyQuestion)


ModelPolicy = Literal["latest_within_budget", "offline_baseline", "fixed_mix"]


class ExperimentModelSlot(BaseModel):
    provider: ProviderName
    weight_pct: float = Field(gt=0, le=100)
    model: Optional[str] = None


class ExperimentSpec(BaseModel):
    """Compact input for one simulation experiment."""
    brief: str
    target_population: str = ""
    question: str = ""
    title: str = ""
    description: str = ""
    context: str = ""
    verbatim_content: Optional[str] = None
    content_type: str = "other"
    language: str = "zh-TW"
    budget_usd: float = Field(default=0.5, ge=0)
    n_agents: int = Field(default=60, ge=2, le=2000)
    rounds: int = Field(default=3, ge=1, le=10)
    seed: Optional[int] = 42
    action_space: list[str] = Field(default_factory=list)
    adopt_action_indices: list[int] = Field(default_factory=lambda: [0])
    survey_questions: list[SurveyQuestion] = Field(default_factory=list)
    demographics: dict[str, dict[str, float]] = Field(default_factory=dict)
    trait_means: dict[str, float] = Field(default_factory=dict)
    persona_notes: str = ""
    contrarian_ratio: float = Field(default=0.1, ge=0, le=0.5)
    initial_stance_mean: float = Field(default=0.0, ge=-1, le=1)
    initial_stance_spread: float = Field(default=0.5, ge=0, le=1)
    model_policy: ModelPolicy = "latest_within_budget"
    model_mix: list[ExperimentModelSlot] = Field(default_factory=list)
    media: list[str | MediaAsset] = Field(default_factory=list)
    prompts: PromptSettings = Field(default_factory=PromptSettings)
    abm: ABMParams = Field(default_factory=ABMParams)
    interaction: InteractionSettings = Field(default_factory=InteractionSettings)
    comparison: ComparisonPlan = Field(default_factory=ComparisonPlan)
    auto_compose: bool = True
    composer_provider: Optional[str] = None
    analyst_provider: ProviderName = ProviderName.claude
    analyst_model: Optional[str] = None
    max_concurrency: int = Field(default=8, ge=1, le=64)


class ExperimentPlan(BaseModel):
    model_policy: ModelPolicy
    model_plan: dict[str, Any] = Field(default_factory=dict)
    composed_scenario: dict[str, Any] = Field(default_factory=dict)
    estimated_cost_usd: float = 0.0
    warnings: list[str] = Field(default_factory=list)


class ExperimentRun(BaseModel):
    id: str
    spec: ExperimentSpec
    config: SimulationConfig
    plan: ExperimentPlan
    result: SimulationResult

    def to_json(self, path: str | Path) -> None:
        Path(path).write_text(
            self.model_dump_json(indent=2), encoding="utf-8")


def _coerce_spec(spec: ExperimentSpec | dict[str, Any] | None = None,
                 **kwargs: Any) -> ExperimentSpec:
    if spec is None:
        data = {}
    elif isinstance(spec, ExperimentSpec):
        data = spec.model_dump()
    else:
        data = dict(spec)
    data.update(kwargs)
    return ExperimentSpec(**data)


def _default_actions(locale: str) -> list[str]:
    if locale == "ja":
        return ["支持/採用", "様子を見る", "反対/拒否"]
    if locale == "zh-TW" or locale.lower().startswith("zh"):
        return ["支持/採納", "觀望", "反對/拒絕"]
    return ["Support/adopt", "Wait", "Reject"]


def _default_surveys(locale: str) -> list[SurveyQuestion]:
    if locale == "ja":
        return [
            SurveyQuestion(id="support", text="支持・期待度", type="scale",
                           scale_min=1, scale_max=5),
            SurveyQuestion(id="share_likelihood",
                           text="この話題を人に話す可能性", type="scale",
                           scale_min=1, scale_max=5),
        ]
    if locale == "zh-TW" or locale.lower().startswith("zh"):
        return [
            SurveyQuestion(id="support", text="支持或看好程度", type="scale",
                           scale_min=1, scale_max=5),
            SurveyQuestion(id="share_likelihood",
                           text="主動跟別人談論的可能性", type="scale",
                           scale_min=1, scale_max=5),
        ]
    return [
        SurveyQuestion(id="support", text="Support / optimism", type="scale",
                       scale_min=1, scale_max=5),
        SurveyQuestion(id="share_likelihood",
                       text="Likelihood of discussing this with others",
                       type="scale", scale_min=1, scale_max=5),
    ]


def _media_from_path(path: str | Path) -> MediaAsset:
    p = Path(path).expanduser()
    if not p.exists() or not p.is_file():
        raise FileNotFoundError(f"media file not found: {p}")
    mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
    name = p.name
    if mime.startswith("image/"):
        return MediaAsset(media_type=MediaType.image, filename=name,
                          mime_type=mime,
                          base64_data=base64.b64encode(p.read_bytes()).decode())
    if mime.startswith("video/"):
        return MediaAsset(media_type=MediaType.video, filename=name,
                          mime_type=mime,
                          base64_data=base64.b64encode(p.read_bytes()).decode())
    if mime.startswith("text/") or p.suffix.lower() in {".txt", ".md", ".csv", ".json"}:
        return MediaAsset(media_type=MediaType.document, filename=name,
                          mime_type=mime, text=p.read_text(encoding="utf-8"))
    return MediaAsset(media_type=MediaType.document, filename=name,
                      mime_type=mime,
                      base64_data=base64.b64encode(p.read_bytes()).decode())


def _resolve_media(media: list[str | MediaAsset]) -> list[MediaAsset]:
    out: list[MediaAsset] = []
    for item in media:
        if isinstance(item, MediaAsset):
            out.append(item)
        else:
            out.append(_media_from_path(item))
    return out


def _model_supports_media(model: dict[str, Any], assets: list[MediaAsset]) -> bool:
    for asset in assets:
        if asset.media_type == MediaType.image and not model.get("supports_image"):
            return False
        if asset.media_type == MediaType.video and not model.get("supports_video"):
            return False
        if asset.media_type == MediaType.document and asset.base64_data \
                and not model.get("supports_document"):
            return False
    return True


def _models_for_available_keys(assets: list[MediaAsset]) -> list[dict[str, Any]]:
    models = merge_models(seed_models(), [])
    configured = {
        "openai": bool(get_runtime_key("openai")),
        "claude": bool(get_runtime_key("claude")),
        "gemini": bool(get_runtime_key("gemini")),
        "custom": bool(get_runtime_key("custom")),
    }
    usable: list[dict[str, Any]] = []
    for model in models:
        provider = str(model.get("provider", ""))
        if provider in {"random", "classic"}:
            usable.append(model)
        elif configured.get(provider) and _model_supports_media(model, assets):
            usable.append(model)
    return usable


def _model_mix_from_plan(plan: dict[str, Any]) -> ModelMix:
    slots = []
    for slot in plan.get("slots", []):
        provider = ProviderName(str(slot["provider"]))
        slots.append(ModelSlot(
            provider=provider,
            weight=float(slot.get("weight_pct", 0)),
            model=slot.get("model")))
    if not slots:
        slots = [ModelSlot(provider=ProviderName.classic, weight=100,
                           model="classic-family-v2")]
    return ModelMix(slots=slots)


def _fixed_model_mix(spec: ExperimentSpec) -> tuple[ModelMix, dict[str, Any]]:
    slots = [
        ModelSlot(provider=s.provider, weight=s.weight_pct, model=s.model)
        for s in spec.model_mix
    ]
    if not slots:
        slots = [ModelSlot(provider=ProviderName.classic, weight=70),
                 ModelSlot(provider=ProviderName.random, weight=30)]
    plan = {"mode": "fixed_mix",
            "slots": [{"provider": s.provider.value, "model": s.model,
                       "weight_pct": s.weight_pct} for s in spec.model_mix]}
    return ModelMix(slots=slots), plan


def _offline_mix() -> tuple[ModelMix, dict[str, Any]]:
    slots = [
        ModelSlot(provider=ProviderName.classic, weight=70,
                  model="classic-family-v2"),
        ModelSlot(provider=ProviderName.random, weight=30,
                  model="random-walk"),
    ]
    return ModelMix(slots=slots), {
        "mode": "offline_baseline",
        "slots": [
            {"provider": "classic", "model": "classic-family-v2",
             "weight_pct": 70},
            {"provider": "random", "model": "random-walk", "weight_pct": 30},
        ],
    }


def _planned_mix(spec: ExperimentSpec,
                 assets: list[MediaAsset]) -> tuple[ModelMix, dict[str, Any], list[str]]:
    warnings: list[str] = []
    models = _models_for_available_keys(assets)
    llm_models = [m for m in models if m.get("provider") not in {"random", "classic"}]
    if not llm_models:
        mix, plan = _offline_mix()
        warnings.append(
            "No configured LLM API keys matched the requested media; using offline baseline.")
        return mix, plan, warnings
    if spec.model_mix:
        plan = plan_models_for_fixed_mix(
            models, spec.budget_usd, spec.n_agents, spec.rounds,
            [s.model_dump() for s in spec.model_mix])
    else:
        plan = plan_mix_for_budget(models, spec.budget_usd,
                                   spec.n_agents, spec.rounds)
    return _model_mix_from_plan(plan), plan, warnings


async def build_experiment_config(
    spec: ExperimentSpec | dict[str, Any] | None = None,
    **kwargs: Any,
) -> tuple[SimulationConfig, ExperimentPlan]:
    spec_obj = _coerce_spec(spec, **kwargs)
    warnings: list[str] = []
    composed: dict[str, Any] = {}
    if spec_obj.auto_compose and spec_obj.brief.strip():
        try:
            composed = await compose_scenario(
                spec_obj.brief, spec_obj.language, spec_obj.composer_provider)
        except (ComposeError, Exception) as exc:  # noqa: BLE001
            warnings.append(f"composer fallback: {type(exc).__name__}: {exc}")

    media = _resolve_media(spec_obj.media)
    if spec_obj.model_policy == "offline_baseline":
        model_mix, model_plan = _offline_mix()
    elif spec_obj.model_policy == "fixed_mix":
        model_mix, model_plan = _fixed_model_mix(spec_obj)
    else:
        model_mix, model_plan, model_warnings = _planned_mix(spec_obj, media)
        warnings.extend(model_warnings)

    prompt_data = composed.get("prompts", {}) if isinstance(composed.get("prompts"), dict) else {}
    prompts = spec_obj.prompts
    if not prompts.system_template and prompt_data.get("system_template"):
        prompts = prompts.model_copy(update={
            "system_template": str(prompt_data.get("system_template", ""))})
    if not prompts.task_template and prompt_data.get("task_template"):
        prompts = prompts.model_copy(update={
            "task_template": str(prompt_data.get("task_template", ""))})

    action_space = spec_obj.action_space or composed.get("action_space") \
        or composed.get("actions") or _default_actions(spec_obj.language)
    survey = spec_obj.survey_questions
    if not survey and composed.get("survey_questions"):
        survey = [SurveyQuestion(**q) for q in composed.get("survey_questions", [])]
    if not survey:
        survey = _default_surveys(spec_obj.language)

    interaction = spec_obj.interaction
    if composed.get("interaction_design"):
        idesign = composed["interaction_design"]
        params = idesign.get("params", {})
        if interaction == InteractionSettings():
            interaction = InteractionSettings(
                protocol=idesign.get("recommended_protocol", "social_diffusion"),
                memory_enabled=bool(params.get("memory", True)),
                allow_stance_change=bool(
                    params.get("allow_stance_change", True)),
                neighbor_sample=int(params.get("neighbor_sample", 4)),
                group_size=int(params.get("group_size", 6)),
                broadcast_top_k=int(params.get("broadcast_top_k", 5)),
                exposure_schedule=params.get("exposure_schedule", []),
                treatment_labels=params.get("treatment_labels", []),
            )

    comparison = spec_obj.comparison
    if composed.get("abm_design") and not comparison.abm_baselines:
        comparison = comparison.model_copy(deep=True)
        baselines = []
        for item in composed["abm_design"].get("recommended_baselines", []):
            try:
                baselines.append(ABMBaselineSpec(**item))
            except Exception:  # noqa: BLE001
                continue
        comparison.abm_baselines = baselines
        cplan = composed.get("comparison_plan", {})
        comparison.run_random_baseline = bool(
            cplan.get("run_random_baseline", comparison.run_random_baseline))
        comparison.primary_metrics = cplan.get(
            "primary_metrics", comparison.primary_metrics)

    population = PopulationSpec(
        n_agents=spec_obj.n_agents,
        demographics=spec_obj.demographics,
        trait_means=spec_obj.trait_means,
        contrarian_ratio=spec_obj.contrarian_ratio,
        initial_stance_mean=spec_obj.initial_stance_mean,
        initial_stance_spread=spec_obj.initial_stance_spread,
        custom_notes=spec_obj.persona_notes,
        seed=spec_obj.seed,
    )

    title = spec_obj.title or composed.get("event_title") \
        or composed.get("name") or spec_obj.brief[:120]
    description = spec_obj.description or composed.get("event_description") \
        or composed.get("description") or spec_obj.brief
    question = spec_obj.question or composed.get("question") \
        or f"How will {spec_obj.target_population or 'the target population'} react?"
    content_type = spec_obj.content_type
    if content_type == "other" and composed.get("content_type"):
        content_type = str(composed["content_type"])

    config = SimulationConfig(
        event=EventInput(
            title=title,
            description=description,
            context=spec_obj.context,
            verbatim_content=spec_obj.verbatim_content,
            content_type=content_type,
            media=media,
        ),
        goal={
            "question": question,
            "target_population": spec_obj.target_population,
            "action_space": [str(a) for a in action_space if str(a).strip()],
            "adopt_action_indices": spec_obj.adopt_action_indices,
            "survey_questions": survey,
            "horizon_rounds": spec_obj.rounds,
        },
        population=population,
        model_mix=model_mix,
        abm=spec_obj.abm,
        prompts=prompts,
        interaction=interaction,
        comparison=comparison,
        analyst_provider=spec_obj.analyst_provider,
        analyst_model=spec_obj.analyst_model,
        language=spec_obj.language,
        max_concurrency=spec_obj.max_concurrency,
        max_cost_usd=spec_obj.budget_usd,
    )
    estimate = estimate_cost(config)
    plan = ExperimentPlan(
        model_policy=spec_obj.model_policy,
        model_plan=model_plan,
        composed_scenario=composed,
        estimated_cost_usd=estimate.est_cost_usd,
        warnings=warnings,
    )
    return config, plan


async def run_experiment_async(
    spec: ExperimentSpec | dict[str, Any] | None = None,
    **kwargs: Any,
) -> ExperimentRun:
    spec_obj = _coerce_spec(spec, **kwargs)
    config, plan = await build_experiment_config(spec_obj)
    sim = Simulator(config)
    result = await sim.run()
    return ExperimentRun(id=result.id, spec=spec_obj, config=config,
                         plan=plan, result=result)


def run_experiment(
    spec: ExperimentSpec | dict[str, Any] | None = None,
    **kwargs: Any,
) -> ExperimentRun:
    return asyncio.run(run_experiment_async(spec, **kwargs))


async def run_batch_async(items: list[dict[str, Any] | ExperimentSpec],
                          shared: dict[str, Any] | None = None
                          ) -> list[ExperimentRun]:
    shared = shared or {}
    results = []
    for item in items:
        data = item.model_dump() if isinstance(item, ExperimentSpec) else dict(item)
        data = {**shared, **data}
        results.append(await run_experiment_async(data))
    return results


def run_batch(items: list[dict[str, Any] | ExperimentSpec],
              shared: dict[str, Any] | None = None) -> list[ExperimentRun]:
    return asyncio.run(run_batch_async(items, shared))


def _load_spec_file(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    if p.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError(
                "YAML input requires PyYAML. Install it or use JSON.") from exc
        data = yaml.safe_load(text)
    else:
        data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError("experiment file must contain one JSON/YAML object")
    return data


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run a simple AgoraSim experiment.")
    parser.add_argument("spec", help="JSON or YAML experiment file")
    parser.add_argument("--out", default="", help="Write full result JSON here")
    parser.add_argument("--brief", default="", help="Override brief")
    args = parser.parse_args(argv)
    data = _load_spec_file(args.spec)
    if args.brief:
        data["brief"] = args.brief
    run = run_experiment(data)
    if args.out:
        run.to_json(args.out)
    else:
        print(run.result.summary_markdown)
    return 0 if run.result.status.value == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
