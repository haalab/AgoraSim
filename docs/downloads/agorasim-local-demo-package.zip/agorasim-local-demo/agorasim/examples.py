"""Ready-to-run example configurations."""
from .schemas import (ABMParams, EventInput, ModelMix, ModelSlot,
                      PopulationSpec, ProviderName, SimulationConfig,
                      SimulationGoal, SurveyQuestion)

# Example 1: central bank policy shock — bank customers' reaction.
# Mix uses random+classic so it runs WITHOUT any API key (offline smoke test);
# swap weights toward claude/openai/gemini for a real run.
CENTRAL_BANK_EXAMPLE = SimulationConfig(
    event=EventInput(
        title="央行宣布升息兩碼並調降第二戶房貸成數上限",
        description=("央行今日臨時記者會宣布政策利率調升 0.5 個百分點，"
                     "並將第二戶購屋貸款成數上限自七成調降至五成，即日生效。"
                     "央行總裁表示此舉為抑制投機性房市需求、回應通膨壓力。"),
        context="過去一年房價指數上漲 11%，CPI 年增率 3.2%，市場原預期僅升息一碼。",
    ),
    goal=SimulationGoal(
        question="一般存款戶與潛在購屋族在未來一至兩週會如何反應？",
        target_population="台灣 25-55 歲、有存款或購屋計畫的一般民眾",
        action_space=["增加定存/申購理財商品", "維持現狀觀望",
                      "延後購屋計畫", "加速在限制生效前進場買房", "轉移資金至其他資產"],
        adopt_action_indices=[0],
        horizon_rounds=3,
    ),
    population=PopulationSpec(n_agents=40, contrarian_ratio=0.1, seed=42),
    model_mix=ModelMix(slots=[
        ModelSlot(provider=ProviderName.random, weight=0.3),
        ModelSlot(provider=ProviderName.classic, weight=0.7),
    ]),
    abm=ABMParams(social_influence=0.35, adoption_threshold=0.25,
                  innovation_p=0.05, imitation_q=0.45,
                  macro_variables={"政策利率(%)": 2.375, "CPI年增率(%)": 3.2}),
    analyst_provider=ProviderName.claude,
    language="zh-TW",
)

# Example 3: pre-testing a draft social post the user plans to publish.
# English locale; offline mix so it runs without keys.
SOCIAL_POST_EXAMPLE = SimulationConfig(
    event=EventInput(
        title="Startup CEO's layoff announcement post",
        description="A tech startup CEO plans to publish this post on LinkedIn "
                    "announcing a 15% layoff.",
        verbatim_content=(
            "Today is a hard day. We are saying goodbye to 15% of our team. "
            "This is on me: we grew too fast on assumptions that didn't hold. "
            "Everyone affected gets 4 months severance, extended healthcare, "
            "and our full support finding their next role. To those leaving: "
            "you built this company, and we won't forget it."),
        content_type="social_post",
    ),
    goal=SimulationGoal(
        question="How will professional audiences react to this post, and "
                 "does it protect or damage the company's reputation?",
        target_population="LinkedIn users in tech: employees, founders, "
                          "recruiters, and job seekers",
        action_space=["Share and publicly support", "Like but not share",
                      "Scroll past", "Leave a critical comment"],
        adopt_action_indices=[0, 1],
        survey_questions=[
            SurveyQuestion(id="sincerity", text="How sincere does this post feel",
                           type="scale", scale_min=1, scale_max=5),
            SurveyQuestion(id="employer_brand",
                           text="Effect on your willingness to work there",
                           type="choice",
                           choices=["More willing", "No change", "Less willing"]),
            SurveyQuestion(id="first_word", text="Your first thought after reading",
                           type="open"),
        ],
        horizon_rounds=3,
    ),
    population=PopulationSpec(n_agents=40, contrarian_ratio=0.15, seed=11),
    model_mix=ModelMix(slots=[
        ModelSlot(provider=ProviderName.random, weight=0.3),
        ModelSlot(provider=ProviderName.classic, weight=0.7),
    ]),
    abm=ABMParams(social_influence=0.4, adoption_threshold=0.1,
                  innovation_p=0.05, imitation_q=0.55),
    analyst_provider=ProviderName.claude,
    language="en",
)

# Example 2: ad campaign pre-test with visual material (VLM use case).
# Attach real media via event.media (base64/url) before running.
PRODUCT_LAUNCH_EXAMPLE = SimulationConfig(
    event=EventInput(
        title="連鎖手搖飲品牌推出「零糖零卡氣泡茶」新品與 30 秒形象廣告",
        description=("品牌下週上市主打健康的零糖零卡氣泡茶系列，售價 65 元，"
                     "略高於既有品項。廣告主打年輕族群的運動與職場場景，"
                     "結尾口號為「爽快，不必有負擔」。"),
        context="市場上已有兩個競品，價格帶 50-60 元；該品牌過去以高甜度飲品聞名。",
        media=[],  # append MediaAsset(base64_data=..., media_type="image"/"video")
    ),
    goal=SimulationGoal(
        question="目標客群看到這支廣告與新品訊息後的購買意願與口碑擴散？",
        target_population="台灣 18-40 歲、每週至少購買一次手搖飲的消費者",
        action_space=["上市當週就去買", "看到門市或朋友推薦再買",
                      "沒興趣、維持原本選擇", "反感、更不想買這品牌"],
        adopt_action_indices=[0, 1],
        horizon_rounds=3,
    ),
    population=PopulationSpec(n_agents=50, contrarian_ratio=0.12, seed=7),
    model_mix=ModelMix(slots=[
        ModelSlot(provider=ProviderName.claude, weight=0.5,
                  model="claude-sonnet-5", temperature=0.9),
        ModelSlot(provider=ProviderName.openai, weight=0.3,
                  model="gpt-4o", temperature=0.9),
        ModelSlot(provider=ProviderName.gemini, weight=0.2,
                  model="gemini-2.5-flash", temperature=0.9),
    ]),
    abm=ABMParams(social_influence=0.3, adoption_threshold=0.2,
                  innovation_p=0.04, imitation_q=0.5,
                  macro_variables={"新品定價(元)": 65}),
    analyst_provider=ProviderName.claude,
)
