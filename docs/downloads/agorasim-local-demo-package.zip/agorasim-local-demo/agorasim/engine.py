"""Round orchestrator: perception -> personas -> routing -> rounds -> report."""
from __future__ import annotations

import asyncio
import random
import time
from typing import Callable, Optional

from .abm import Environment
from .analysis import (compute_round_metrics, generate_summary,
                       mine_scenarios, stance_distribution)
from .i18n import P
from .network import build_network
from .personas import derive_population_spec, sample_personas
from .providers import (BaseProvider, DecisionContext, ProviderError,
                        RandomProvider, allocate_slots, make_provider)
from .providers.base import build_system_prompt, build_user_prompt
from .providers.llm import LLMProvider
from .schemas import (AgentDecision, AgentRecord, CostEstimate, ModelMix,
                      ModelSlot, Persona, ProviderName, SimulationConfig,
                      SimulationResult, SimulationStatus, MediaType)

DIVERSITY_STD_FLOOR = 0.12   # below this, inject anti-conformity pressure


class Simulator:
    def __init__(self, config: SimulationConfig):
        self.config = config
        self.result = SimulationResult(config=config,
                                       status=SimulationStatus.pending)

    # ------------------------------------------------------------ perception
    async def _perceive_media(self, providers: list[BaseProvider]) -> None:
        """One neutral caption per asset, cached on the asset (O(media), not O(N))."""
        assets = [m for m in self.config.event.media if not m.caption]
        if not assets:
            return
        for asset in assets:
            caption = None
            vlm = next((p for p in providers
                        if isinstance(p, LLMProvider) and p.api_key
                        and self._provider_can_use_media(p, [asset])), None)
            if vlm is not None:
                try:
                    caption = await vlm.describe_media(
                        asset, self.config.language)
                except Exception as e:  # noqa: BLE001
                    self.result.warnings.append(f"media perception failed: {e}")
            asset.caption = caption or "(no textual description available)"

    # ------------------------------------------------------------------ run
    async def run(self, on_progress: Optional[Callable[[SimulationResult], None]] = None
                  ) -> SimulationResult:
        cfg, res = self.config, self.result
        res.status = SimulationStatus.running
        try:
            await self._run_inner(on_progress)
            res.status = SimulationStatus.completed
            res.progress = 1.0
        except Exception as e:  # noqa: BLE001
            res.status = SimulationStatus.failed
            res.error = f"{type(e).__name__}: {e}"
        if on_progress:
            on_progress(res)
        return res

    async def _run_inner(self, on_progress) -> None:
        cfg, res = self.config, self.result
        seed = cfg.population.seed
        population = derive_population_spec(
            cfg.population, cfg.goal.target_population, cfg.language)
        cfg.population = population
        personas = sample_personas(population, seed, cfg.language)
        res.personas = personas
        res.initial_stance_dist = stance_distribution(
            [p.initial_stance for p in personas])
        n = len(personas)

        slot_of = allocate_slots(cfg.model_mix, n, seed)
        providers = [make_provider(s, seed) for s in cfg.model_mix.slots]
        fallback = RandomProvider(seed=seed)
        adjacency = build_network(n, cfg.network, seed)

        env = Environment(cfg.abm, cfg.goal, cfg.language)
        await self._perceive_media(providers)
        res.media_trace = self._media_trace(providers)
        res.prompt_trace = self._prompt_trace(
            personas, slot_of, providers, env.macro_text(1))
        memory: dict[str, str] = {}
        prev_decisions: dict[str, AgentDecision] = {}
        trajectories: dict[str, list[float]] = {p.agent_id: [] for p in personas}
        sem = asyncio.Semaphore(cfg.max_concurrency)
        diversity_pressure = False
        degraded_providers: set[str] = set()
        total_rounds = cfg.goal.horizon_rounds
        event_text = self._event_text()

        for rnd in range(1, total_rounds + 1):
            bass_ref = env.bass_step()
            macro_text = self._macro_text(env, rnd)

            async def one_agent(i: int, rnd=rnd, macro_text=macro_text):
                persona = personas[i]
                slot = cfg.model_mix.slots[slot_of[i]]
                provider = providers[slot_of[i]]

                heard, nb_stances, treatment = self._interaction_inputs(
                    i, rnd, personas, adjacency, prev_decisions, seed)

                prev = prev_decisions.get(persona.agent_id)
                allow_change = cfg.interaction.allow_stance_change
                prev_stance = (prev.stance if prev and allow_change
                               else persona.initial_stance)
                ctx = DecisionContext(
                    event_text=self._agent_event_text(event_text, treatment),
                    media=cfg.event.media,
                    use_raw_media=(slot.allow_vision and bool(cfg.event.media)
                                   and self._provider_can_use_media(
                                       provider, cfg.event.media)),
                    goal_question=cfg.goal.question,
                    action_space=cfg.goal.action_space,
                    verbatim=cfg.event.verbatim_content,
                    survey=cfg.goal.survey_questions,
                    round_no=rnd, total_rounds=total_rounds,
                    macro_text=macro_text,
                    neighbor_statements=heard,
                    memory_text=(memory.get(persona.agent_id, "")
                                 if cfg.interaction.memory_enabled else ""),
                    diversity_pressure=diversity_pressure,
                    language=cfg.language,
                    temperature=slot.temperature + (0.15 if diversity_pressure else 0),
                    prev_stance=prev_stance,
                    neighbor_stance_mean=(sum(nb_stances) / len(nb_stances)
                                          if nb_stances else None),
                    adoption_rate=env.adoption_rate,
                    abm=cfg.abm,
                    system_prompt_template=cfg.prompts.system_template,
                    task_prompt_template=cfg.prompts.task_template,
                )

                t0 = time.time()
                degraded = False
                budget_left = res.cost_usd < cfg.max_cost_usd
                use = provider if budget_left else fallback
                if not budget_left and provider.name not in degraded_providers:
                    degraded_providers.add(provider.name)
                    res.warnings.append(
                        f"已達成本上限 {cfg.max_cost_usd} USD，"
                        f"{provider.name} agent 降級為 random。")
                async with sem:
                    try:
                        decision, tin, tout = await use.decide(persona, ctx)
                    except ProviderError as e:
                        decision, tin, tout = (await fallback.decide(persona, ctx))[0], 0, 0
                        degraded = True
                        if provider.name not in degraded_providers:
                            degraded_providers.add(provider.name)
                            res.warnings.append(
                                f"provider {provider.name} 呼叫失敗，"
                                f"部分 agent 降級為 random：{e}")
                res.cost_usd += use.cost(tin, tout)
                return i, AgentRecord(
                    agent_id=persona.agent_id, round=rnd,
                    provider=use.name if not degraded else f"{provider.name}->random",
                    model=use.model, decision=decision, heard_statements=heard,
                    latency_ms=int((time.time() - t0) * 1000),
                    input_tokens=tin, output_tokens=tout, degraded=degraded)

            results = await asyncio.gather(*(one_agent(i) for i in range(n)))

            round_decisions: dict[str, AgentDecision] = {}
            for i, record in sorted(results):
                res.records.append(record)
                d = record.decision
                pid = personas[i].agent_id
                round_decisions[pid] = d
                trajectories[pid].append(d.stance)
                memory[pid] = P(cfg.language)["memory_line"].format(
                    r=rnd, stance=d.stance, action=d.action,
                    stmt=d.public_statement)

            decisions_list = list(round_decisions.values())
            env.update(decisions_list)
            metrics = compute_round_metrics(rnd, decisions_list, env, bass_ref,
                                            cfg.goal.survey_questions)
            res.rounds.append(metrics)
            diversity_pressure = metrics.stance_std < DIVERSITY_STD_FLOOR
            prev_decisions = round_decisions
            res.progress = rnd / (total_rounds + 1)
            if on_progress:
                on_progress(res)

        # ------------------------------------------------------------ report
        final = prev_decisions
        res.scenarios = mine_scenarios(personas, trajectories, final,
                                       locale=cfg.language)
        analyst = self._make_analyst()
        res.summary_markdown = await generate_summary(
            cfg, res.rounds, res.scenarios, analyst)
        counter: dict[str, int] = {}
        for r in res.records:
            counter[r.provider] = counter.get(r.provider, 0) + 1
        res.provider_share = counter

    def _event_text(self) -> str:
        cfg = self.config
        return (f"{cfg.event.title}\n{cfg.event.description}"
                + (f"\n背景：{cfg.event.context}" if cfg.event.context else ""))

    def _agent_event_text(self, event_text: str, treatment: str | None) -> str:
        if not treatment:
            return event_text
        return f"{event_text}\nTreatment / variant shown to this agent: {treatment}"

    def _macro_text(self, env: Environment, rnd: int) -> str:
        cfg = self.config
        text = env.macro_text(rnd)
        inter = cfg.interaction
        if inter.protocol == "sequential_exposure" and inter.exposure_schedule:
            idx = min(rnd - 1, len(inter.exposure_schedule) - 1)
            phase = inter.exposure_schedule[idx].strip()
            if phase:
                text += f"\nExposure phase {rnd}: {phase}"
        if inter.protocol == "focus_group" and inter.moderator_prompt.strip():
            text += f"\nModerator instruction: {inter.moderator_prompt.strip()}"
        return text

    @staticmethod
    def _sample(items: list[str], count: int, seed: int | None,
                salt: int) -> list[str]:
        if count <= 0 or not items:
            return []
        return random.Random((seed or 0) * 1000 + salt).sample(
            items, min(count, len(items)))

    def _interaction_inputs(
        self, i: int, rnd: int, personas: list[Persona],
        adjacency: dict[int, list[int]],
        prev_decisions: dict[str, AgentDecision], seed: int | None,
    ) -> tuple[list[str], list[float], str | None]:
        cfg = self.config
        inter = cfg.interaction
        treatment = None
        if inter.protocol == "ab_treatment" and inter.treatment_labels:
            treatment = inter.treatment_labels[i % len(inter.treatment_labels)]
        if rnd <= 1 or not prev_decisions:
            return [], [], treatment

        sample_n = inter.neighbor_sample if inter.neighbor_sample is not None \
            else cfg.neighbor_sample
        if inter.protocol == "independent_survey":
            return [], [], treatment

        candidates: list[int] = []
        if inter.protocol == "broadcast_comment_stream":
            ranked = sorted(prev_decisions.values(),
                            key=lambda d: (d.confidence, abs(d.stance)),
                            reverse=True)
            heard = [d.public_statement for d in ranked
                     if d.will_share and d.public_statement][
                         :inter.broadcast_top_k]
            stances = [d.stance for d in ranked[:inter.broadcast_top_k]]
            return heard, stances, treatment

        if inter.protocol == "focus_group":
            group = max(2, inter.group_size)
            start = (i // group) * group
            candidates = [j for j in range(start, min(start + group, len(personas)))
                          if j != i]
        else:
            candidates = adjacency.get(i, [])

        heard: list[str] = []
        nb_stances: list[float] = []
        for j in candidates:
            d = prev_decisions.get(personas[j].agent_id)
            if d is None:
                continue
            nb_stances.append(d.stance)
            if d.will_share and d.public_statement:
                heard.append(d.public_statement)
        heard = self._sample(heard, sample_n, seed, i * 7 + rnd)
        return heard, nb_stances, treatment

    def _media_trace(self, providers: list[BaseProvider]) -> list[dict]:
        traces: list[dict] = []
        for asset in self.config.event.media:
            direct = [
                f"{p.name}:{p.model}" for p in providers
                if isinstance(p, LLMProvider)
                and self._provider_can_use_media(p, [asset])
            ]
            traces.append({
                "filename": asset.filename,
                "media_type": asset.media_type.value,
                "mime_type": asset.mime_type,
                "caption": asset.caption or "",
                "direct_providers": direct,
                "caption_used_when_not_direct": bool(asset.caption),
            })
        return traces

    def _prompt_trace(self, personas: list[Persona], slot_of: list[int],
                      providers: list[BaseProvider],
                      macro_text: str) -> list[dict]:
        cfg = self.config
        traces: list[dict] = []
        seen: set[str] = set()
        for i, persona in enumerate(personas):
            slot = cfg.model_mix.slots[slot_of[i]]
            provider = providers[slot_of[i]]
            if not isinstance(provider, LLMProvider):
                continue
            key = f"{provider.name}:{provider.model}"
            if key in seen:
                continue
            seen.add(key)
            ctx = DecisionContext(
                event_text=self._event_text(),
                media=cfg.event.media,
                use_raw_media=(slot.allow_vision and bool(cfg.event.media)
                               and self._provider_can_use_media(
                                   provider, cfg.event.media)),
                goal_question=cfg.goal.question,
                action_space=cfg.goal.action_space,
                verbatim=cfg.event.verbatim_content,
                survey=cfg.goal.survey_questions,
                round_no=1, total_rounds=cfg.goal.horizon_rounds,
                macro_text=macro_text,
                neighbor_statements=[], memory_text="",
                diversity_pressure=False,
                language=cfg.language,
                prev_stance=persona.initial_stance,
                adoption_rate=0.0,
                abm=cfg.abm,
                system_prompt_template=cfg.prompts.system_template,
                task_prompt_template=cfg.prompts.task_template,
            )
            traces.append({
                "provider": provider.name,
                "model": provider.model,
                "agent_id": persona.agent_id,
                "uses_raw_media": ctx.use_raw_media,
                "system_prompt": build_system_prompt(
                    persona, cfg.language, cfg.prompts.system_template),
                "user_prompt": build_user_prompt(ctx),
            })
            if len(traces) >= 5:
                break
        return traces

    def _make_analyst(self) -> BaseProvider | None:
        cfg = self.config
        if cfg.analyst_provider in (ProviderName.random, ProviderName.classic):
            return None
        slot = ModelSlot(provider=cfg.analyst_provider, weight=1,
                         model=cfg.analyst_model)
        try:
            return make_provider(slot)
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _provider_can_use_media(provider: BaseProvider, media) -> bool:
        if not media:
            return False
        for asset in media:
            if asset.media_type == MediaType.image:
                if not getattr(provider, "supports_image", provider.supports_vision):
                    return False
            elif asset.media_type == MediaType.video:
                if not getattr(provider, "supports_video", False):
                    return False
            elif asset.media_type == MediaType.document:
                if not getattr(provider, "supports_document", False):
                    return False
        return True


# ------------------------------------------------------------- cost estimate

AVG_INPUT_TOKENS = 1500
AVG_OUTPUT_TOKENS = 300


def estimate_cost(config: SimulationConfig) -> CostEstimate:
    from .providers.llm import _lookup_price
    n, rounds = config.population.n_agents, config.goal.horizon_rounds
    breakdown: dict[str, float] = {}
    total = 0.0
    calls = 0
    for slot in config.model_mix.slots:
        share = round(slot.weight * n) * rounds
        if slot.provider in (ProviderName.random, ProviderName.classic):
            breakdown[slot.provider.value] = 0.0
            continue
        calls += share
        defaults = {"claude": "claude-sonnet-5", "openai": "gpt-4o",
                    "gemini": "gemini-2.5-flash"}
        pin, pout = _lookup_price(slot.model
                                  or defaults.get(slot.provider.value, ""))
        cost = share * (AVG_INPUT_TOKENS / 1e6 * pin
                        + AVG_OUTPUT_TOKENS / 1e6 * pout)
        breakdown[f"{slot.provider.value}:{slot.model or 'default'}"] = round(cost, 4)
        total += cost
    return CostEstimate(
        n_calls=calls,
        est_input_tokens=calls * AVG_INPUT_TOKENS,
        est_output_tokens=calls * AVG_OUTPUT_TOKENS,
        est_cost_usd=round(total, 4),
        breakdown=breakdown)
