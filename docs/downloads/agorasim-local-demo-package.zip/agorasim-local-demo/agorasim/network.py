"""Social network topologies (stdlib only, no networkx dependency)."""
from __future__ import annotations

import random
from .schemas import NetworkSpec


def build_network(n: int, spec: NetworkSpec, seed: int | None = None) -> dict[int, list[int]]:
    """Return adjacency dict {node: [neighbors]} for n nodes."""
    rng = random.Random(seed)
    if n <= 1:
        return {i: [] for i in range(n)}
    k = max(1, min(spec.avg_degree, n - 1))

    if spec.topology == "complete":
        return {i: [j for j in range(n) if j != i] for i in range(n)}

    if spec.topology == "random":  # Erdos-Renyi with expected degree k
        p = k / (n - 1)
        adj: dict[int, set[int]] = {i: set() for i in range(n)}
        for i in range(n):
            for j in range(i + 1, n):
                if rng.random() < p:
                    adj[i].add(j); adj[j].add(i)
        return _ensure_connected({i: sorted(s) for i, s in adj.items()}, rng)

    if spec.topology == "scale_free":  # Barabasi-Albert
        m = max(1, k // 2)
        adj = {i: set() for i in range(n)}
        targets = list(range(min(m, n)))
        repeated: list[int] = list(targets)
        for new in range(len(targets), n):
            chosen = set()
            while len(chosen) < min(m, new):
                pick = rng.choice(repeated) if repeated and rng.random() < 0.9 \
                    else rng.randrange(new)
                chosen.add(pick)
            for t in chosen:
                adj[new].add(t); adj[t].add(new)
                repeated.extend([new, t])
        return {i: sorted(s) for i, s in adj.items()}

    # default: small_world (Watts-Strogatz)
    kk = max(2, k - (k % 2))  # even
    adj = {i: set() for i in range(n)}
    for i in range(n):
        for d in range(1, kk // 2 + 1):
            j = (i + d) % n
            adj[i].add(j); adj[j].add(i)
    for i in range(n):
        for j in list(adj[i]):
            if j > i and rng.random() < spec.rewire_p:
                candidates = [c for c in range(n) if c != i and c not in adj[i]]
                if candidates:
                    new_j = rng.choice(candidates)
                    adj[i].discard(j); adj[j].discard(i)
                    adj[i].add(new_j); adj[new_j].add(i)
    return {i: sorted(s) for i, s in adj.items()}


def _ensure_connected(adj: dict[int, list[int]], rng: random.Random) -> dict[int, list[int]]:
    nodes = list(adj)
    for i in nodes:
        if not adj[i]:
            j = rng.choice([x for x in nodes if x != i])
            adj[i] = sorted(set(adj[i]) | {j})
            adj[j] = sorted(set(adj[j]) | {i})
    return adj
