"""AgoraSim core data models (Pydantic v2)."""
from __future__ import annotations

import time
import uuid
from enum import Enum
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------- input side

class MediaType(str, Enum):
    image = "image"
    video = "video"
    document = "document"


class MediaAsset(BaseModel):
    """A user-uploaded image, video, or document attached to the event."""
    media_type: MediaType = MediaType.image
    filename: str = ""
    url: Optional[str] = None
    base64_data: Optional[str] = None
    mime_type: str = "image/png"
    text: Optional[str] = None          # extracted client-side for text docs
    # Filled by the perception service; consumed by non-vision agents.
    caption: Optional[str] = None
    # For video: pre-extracted key frames (base64 jpeg/png).
    frames: list[str] = Field(default_factory=list)
    transcript: Optional[str] = None  # audio transcript for video


class EventInput(BaseModel):
    title: str
    description: str = ""
    context: str = ""          # background facts the user wants agents to know
    # The user's own draft content (a social post, ad copy, speech excerpt...).
    # Shown to agents verbatim, clearly marked as "the exact text you saw".
    verbatim_content: Optional[str] = None
    content_type: str = "news"  # news | social_post | ad | policy | product | other
    source: str = "user"
    media: list[MediaAsset] = Field(default_factory=list)


class SurveyQuestion(BaseModel):
    """A question every agent answers every round, beyond stance/action."""
    id: str                                # short key, e.g. "buy_intent"
    text: str
    type: Literal["scale", "choice", "open"] = "scale"
    scale_min: int = 1
    scale_max: int = 5
    choices: list[str] = Field(default_factory=list)   # for type == "choice"


class SimulationGoal(BaseModel):
    question: str                          # what we are trying to predict
    target_population: str = ""            # who the agents represent
    action_space: list[str]                # discrete actions agents must pick from
    # index (into action_space) of actions counted as "adoption" for macro coupling
    adopt_action_indices: list[int] = Field(default_factory=lambda: [0])
    survey_questions: list[SurveyQuestion] = Field(default_factory=list)
    horizon_rounds: int = 3
    success_metric: str = ""

    @field_validator("action_space")
    @classmethod
    def _non_empty(cls, v: list[str]) -> list[str]:
        if len(v) < 2:
            raise ValueError("action_space needs at least 2 actions")
        return v


# ------------------------------------------------------------- model routing

class ProviderName(str, Enum):
    claude = "claude"
    openai = "openai"
    gemini = "gemini"
    custom = "custom"     # any OpenAI-compatible endpoint (Ollama/vLLM/Groq/...)
    random = "random"
    classic = "classic"


class ModelSlot(BaseModel):
    provider: ProviderName
    weight: float = Field(gt=0)
    model: Optional[str] = None       # provider default used when None
    temperature: float = 0.9
    allow_vision: bool = True         # let this slot see raw media if capable
    # for provider == custom: OpenAI-compatible base URL, e.g.
    # http://localhost:11434/v1 (Ollama) or https://api.groq.com/openai/v1.
    # None -> runtime-configured base URL (UI key panel / CUSTOM_BASE_URL env).
    base_url: Optional[str] = None


class ModelMix(BaseModel):
    slots: list[ModelSlot]

    @model_validator(mode="after")
    def _normalize(self) -> "ModelMix":
        total = sum(s.weight for s in self.slots)
        if total <= 0:
            raise ValueError("weights must sum to a positive number")
        for s in self.slots:
            s.weight = s.weight / total
        return self


# ---------------------------------------------------------------- population

DEFAULT_TRAITS: list[str] = [
    "risk_tolerance", "tech_savvy", "media_trust", "conformity",
    "brand_loyalty", "price_sensitivity",
]


class PopulationSpec(BaseModel):
    n_agents: int = Field(default=30, ge=2, le=2000)
    # Empty dict -> locale-appropriate defaults are used (see i18n.PERSONA).
    demographics: dict[str, dict[str, float]] = Field(default_factory=dict)
    trait_names: list[str] = Field(default_factory=lambda: list(DEFAULT_TRAITS))
    # Optional per-trait target means. When present, persona sampling uses a
    # concentrated beta distribution around these means instead of the global
    # trait_beta.
    trait_means: dict[str, float] = Field(default_factory=dict)
    # Beta(a, b) per trait; default flat-ish for diversity
    trait_beta: tuple[float, float] = (1.2, 1.2)
    contrarian_ratio: float = Field(default=0.1, ge=0.0, le=0.5)
    initial_stance_mean: float = Field(default=0.0, ge=-1.0, le=1.0)
    initial_stance_spread: float = Field(default=0.5, ge=0.0, le=1.0)
    custom_notes: str = ""            # freeform, appended to every persona
    seed: Optional[int] = None


class Persona(BaseModel):
    agent_id: str
    name: str
    age_bracket: str
    gender: str
    income: str
    region: str
    education: str
    occupation: str
    traits: dict[str, float]
    initial_stance: float             # -1..1 prior toward the event/subject
    is_contrarian: bool = False
    custom_demographics: dict[str, str] = Field(default_factory=dict)
    backstory: str = ""


# --------------------------------------------------------------- classic ABM

ClassicModelName = Literal[
    "threshold", "deffuant", "sir", "herding",
    "degroot", "voter", "discrete_choice",
]


class ABMParams(BaseModel):
    """Parameters for the classic-agent rule family AND macro coupling.

    classic_model picks which canonical dynamics rule agents follow:
      threshold — Granovetter/Bass adoption (products, purchases, uptake)
      deffuant  — bounded-confidence opinion dynamics (elections, debates;
                  produces clustering/polarization). extra: confidence_bound
      sir       — contagion spread (viral posts, panic, crises).
                  extra: infect_rate, recover_rate
      herding   — Kirman-style herding (financial markets).
      degroot   — weighted social learning toward neighborhood mean.
      voter     — majority-rule / binary opinion switching.
      discrete_choice — utility-based choice with risk, price, trust and habit.
                  extra: herd_strength, idiosyncratic
    Scenario templates and the AI composer pick the model automatically;
    users only touch this to override.
    """
    classic_model: ClassicModelName = "threshold"
    social_influence: float = Field(default=0.3, ge=0, le=1)   # beta
    adoption_threshold: float = Field(default=0.3, ge=-1, le=1)
    innovation_p: float = 0.03        # Bass p
    imitation_q: float = 0.38         # Bass q
    noise: float = Field(default=0.08, ge=0, le=1)
    sentiment_smoothing: float = Field(default=0.5, ge=0, le=1)
    # model-specific extras; missing keys get defaults in providers/rule.py
    extra: dict[str, float] = Field(default_factory=dict)
    macro_variables: dict[str, float] = Field(default_factory=dict)


class NetworkSpec(BaseModel):
    topology: Literal["small_world", "scale_free", "complete", "random"] = "small_world"
    avg_degree: int = Field(default=6, ge=1)
    rewire_p: float = Field(default=0.1, ge=0, le=1)


class PromptSettings(BaseModel):
    system_template: str = ""
    task_template: str = ""


class InteractionSettings(BaseModel):
    """How LLM agents are exposed to information and to each other."""
    protocol: Literal[
        "independent_survey", "social_diffusion", "broadcast_comment_stream",
        "sequential_exposure", "focus_group", "ab_treatment",
    ] = "social_diffusion"
    memory_enabled: bool = True
    allow_stance_change: bool = True
    neighbor_sample: int = Field(default=4, ge=0, le=30)
    group_size: int = Field(default=6, ge=2, le=50)
    broadcast_top_k: int = Field(default=5, ge=1, le=50)
    moderator_prompt: str = ""
    exposure_schedule: list[str] = Field(default_factory=list)
    treatment_labels: list[str] = Field(default_factory=list)


class ABMBaselineSpec(BaseModel):
    id: str = ""
    label: str = ""
    model: ClassicModelName = "threshold"
    enabled: bool = True
    abm: ABMParams = Field(default_factory=ABMParams)
    rationale: str = ""

    @model_validator(mode="after")
    def _sync_model(self) -> "ABMBaselineSpec":
        self.abm.classic_model = self.model
        if not self.id:
            self.id = self.model
        if not self.label:
            self.label = self.model.replace("_", " ").title()
        return self


class ComparisonPlan(BaseModel):
    run_random_baseline: bool = False
    abm_baselines: list[ABMBaselineSpec] = Field(default_factory=list)
    primary_metrics: list[str] = Field(
        default_factory=lambda: [
            "adoption_rate", "polarization", "action_distribution"])


# ------------------------------------------------------------- configuration

class SimulationConfig(BaseModel):
    event: EventInput
    goal: SimulationGoal
    population: PopulationSpec = Field(default_factory=PopulationSpec)
    model_mix: ModelMix
    abm: ABMParams = Field(default_factory=ABMParams)
    network: NetworkSpec = Field(default_factory=NetworkSpec)
    prompts: PromptSettings = Field(default_factory=PromptSettings)
    interaction: InteractionSettings = Field(default_factory=InteractionSettings)
    comparison: ComparisonPlan = Field(default_factory=ComparisonPlan)
    analyst_provider: ProviderName = ProviderName.claude
    analyst_model: Optional[str] = None
    language: str = "zh-TW"
    max_concurrency: int = Field(default=8, ge=1, le=64)
    max_cost_usd: float = 20.0        # hard budget; simulation aborts beyond this
    neighbor_sample: int = 4          # how many neighbor statements an agent hears


# ------------------------------------------------------------------- outputs

class AgentDecision(BaseModel):
    stance: float = Field(ge=-1, le=1)
    sentiment: str = "-"
    action: str
    confidence: float = Field(default=0.5, ge=0, le=1)
    public_statement: str = ""
    private_reasoning: str = ""
    will_share: bool = True
    answers: dict[str, Any] = Field(default_factory=dict)  # survey answers by qid
    debug: dict[str, Any] = Field(default_factory=dict)


class AgentRecord(BaseModel):
    agent_id: str
    round: int
    provider: str
    model: str
    decision: AgentDecision
    heard_statements: list[str] = Field(default_factory=list)
    latency_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    degraded: bool = False            # provider failed -> random fallback


class RoundMetrics(BaseModel):
    round: int
    stance_mean: float
    stance_std: float
    polarization: float               # 0..1
    action_dist: dict[str, float]
    stance_dist: dict[str, float] = Field(default_factory=dict)
    sentiment_dist: dict[str, float]
    adoption_rate: float
    bass_reference: float             # theoretical Bass adoption for comparison
    macro: dict[str, float]
    top_statements: list[str]
    silence_rate: float               # share of will_share == False
    # survey aggregation by question id:
    #   scale  -> {"mean": float, "dist": {value: share}}
    #   choice -> {"dist": {choice: share}}
    #   open   -> {"samples": [str, ...]}
    survey: dict[str, dict] = Field(default_factory=dict)


class Scenario(BaseModel):
    name: str
    probability: float
    description: str
    representative_quotes: list[str]
    dominant_profile: str


class SimulationStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"


class SimulationResult(BaseModel):
    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    status: SimulationStatus = SimulationStatus.pending
    created_at: float = Field(default_factory=time.time)
    config: Optional[SimulationConfig] = None
    progress: float = 0.0             # 0..1
    rounds: list[RoundMetrics] = Field(default_factory=list)
    records: list[AgentRecord] = Field(default_factory=list)
    personas: list[Persona] = Field(default_factory=list)
    initial_stance_dist: dict[str, float] = Field(default_factory=dict)
    media_trace: list[dict[str, Any]] = Field(default_factory=list)
    prompt_trace: list[dict[str, Any]] = Field(default_factory=list)
    scenarios: list[Scenario] = Field(default_factory=list)
    summary_markdown: str = ""
    cost_usd: float = 0.0
    warnings: list[str] = Field(default_factory=list)
    error: Optional[str] = None
    provider_share: dict[str, int] = Field(default_factory=dict)


class CostEstimate(BaseModel):
    n_calls: int
    est_input_tokens: int
    est_output_tokens: int
    est_cost_usd: float
    breakdown: dict[str, float]
