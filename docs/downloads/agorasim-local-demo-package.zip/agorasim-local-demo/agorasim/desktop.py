"""Desktop launcher for local AgoraSim distributions.

The packaged app starts a FastAPI server bound to 127.0.0.1, opens the
user's browser, and keeps a small control window alive so closing the window
also stops the local service.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import uvicorn


DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8000
APP_NAME = "AgoraSim"


@dataclass
class DesktopSettings:
    host: str = DEFAULT_HOST
    port: int = DEFAULT_PORT
    open_browser: bool = True
    strict_port: bool = False
    show_dialog: bool = True
    show_status_window: bool = True


def config_dir() -> Path:
    override = os.environ.get("AGORASIM_CONFIG_DIR")
    if override:
        return Path(override).expanduser()
    system = platform.system().lower()
    if system == "darwin":
        return Path.home() / "Library" / "Application Support" / APP_NAME
    if system == "windows":
        root = os.environ.get("APPDATA")
        if root:
            return Path(root) / APP_NAME
    return Path.home() / ".agorasim"


def config_path() -> Path:
    return config_dir() / "config.json"


def load_config() -> dict[str, Any]:
    path = config_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def save_config(settings: DesktopSettings) -> None:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "host": settings.host,
        "port": settings.port,
        "open_browser": settings.open_browser,
        "strict_port": settings.strict_port,
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def port_available(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind((host, port))
        except OSError:
            return False
    return True


def find_available_port(host: str, preferred: int,
                        attempts: int = 50) -> int:
    for offset in range(attempts):
        port = preferred + offset
        if 1 <= port <= 65535 and port_available(host, port):
            return port
    raise RuntimeError(
        f"No available local port found from {preferred} to "
        f"{min(65535, preferred + attempts - 1)}.")


def wait_for_server(url: str, timeout: float = 20.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"{url}/health", timeout=1.0) as res:
                if res.status == 200:
                    return True
        except (OSError, urllib.error.URLError):
            time.sleep(0.2)
    return False


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Start the local AgoraSim desktop server.")
    parser.add_argument("--host", default=os.environ.get("AGORASIM_HOST"))
    parser.add_argument("--port", type=int,
                        default=_env_int("AGORASIM_PORT"))
    parser.add_argument("--no-browser", action="store_true",
                        default=_env_bool("AGORASIM_NO_BROWSER"))
    parser.add_argument("--strict-port", action="store_true",
                        help="Fail instead of auto-selecting the next port.")
    parser.add_argument("--no-dialog", action="store_true",
                        help="Skip the startup settings window.")
    parser.add_argument("--no-status-window", action="store_true",
                        help="Run without the desktop control window.")
    parser.add_argument("--log-level", default="info")
    return parser.parse_args(argv)


def _env_int(name: str) -> int | None:
    raw = os.environ.get(name)
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


def _env_bool(name: str) -> bool:
    raw = os.environ.get(name)
    return str(raw or "").lower() in {"1", "true", "yes", "on"}


def settings_from_args(args: argparse.Namespace,
                       config: dict[str, Any] | None = None) -> DesktopSettings:
    cfg = config or {}
    port = args.port if args.port is not None else int(
        cfg.get("port") or DEFAULT_PORT)
    host = args.host or str(cfg.get("host") or DEFAULT_HOST)
    open_browser = bool(cfg.get("open_browser", True)) and not args.no_browser
    strict_port = bool(cfg.get("strict_port", False)) or args.strict_port
    return DesktopSettings(
        host=host,
        port=max(1, min(65535, port)),
        open_browser=open_browser,
        strict_port=strict_port,
        show_dialog=not args.no_dialog,
        show_status_window=not args.no_status_window,
    )


def prompt_settings(settings: DesktopSettings) -> DesktopSettings | None:
    try:
        import tkinter as tk
        from tkinter import messagebox
    except Exception:
        return settings

    root = tk.Tk()
    root.title(APP_NAME)
    root.resizable(False, False)

    result: dict[str, DesktopSettings | None] = {"settings": None}
    port_var = tk.StringVar(value=str(settings.port))
    browser_var = tk.BooleanVar(value=settings.open_browser)
    strict_var = tk.BooleanVar(value=settings.strict_port)

    frame = tk.Frame(root, padx=18, pady=16)
    frame.grid(row=0, column=0, sticky="nsew")
    tk.Label(frame, text="AgoraSim local server",
             font=("Arial", 16, "bold")).grid(
                 row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
    tk.Label(frame, text="Port").grid(row=1, column=0, sticky="w")
    port_entry = tk.Entry(frame, textvariable=port_var, width=12)
    port_entry.grid(row=1, column=1, sticky="w")
    tk.Checkbutton(frame, text="Open browser after start",
                   variable=browser_var).grid(
                       row=2, column=0, columnspan=2, sticky="w", pady=(8, 0))
    tk.Checkbutton(frame, text="Use this port only",
                   variable=strict_var).grid(
                       row=3, column=0, columnspan=2, sticky="w")

    def start() -> None:
        try:
            port = int(port_var.get())
            if port < 1 or port > 65535:
                raise ValueError
        except ValueError:
            messagebox.showerror(APP_NAME, "Port must be between 1 and 65535.")
            return
        result["settings"] = DesktopSettings(
            host=settings.host,
            port=port,
            open_browser=bool(browser_var.get()),
            strict_port=bool(strict_var.get()),
            show_dialog=settings.show_dialog,
            show_status_window=settings.show_status_window,
        )
        root.destroy()

    def cancel() -> None:
        result["settings"] = None
        root.destroy()

    buttons = tk.Frame(frame)
    buttons.grid(row=4, column=0, columnspan=2, sticky="e", pady=(14, 0))
    tk.Button(buttons, text="Cancel", command=cancel).grid(
        row=0, column=0, padx=(0, 8))
    tk.Button(buttons, text="Start", command=start).grid(row=0, column=1)
    root.protocol("WM_DELETE_WINDOW", cancel)
    port_entry.focus_set()
    root.mainloop()
    return result["settings"]


def start_server(settings: DesktopSettings,
                 log_level: str = "info") -> tuple[uvicorn.Server, threading.Thread, str]:
    if settings.strict_port:
        if not port_available(settings.host, settings.port):
            raise RuntimeError(f"Port {settings.port} is already in use.")
        port = settings.port
    else:
        port = find_available_port(settings.host, settings.port)

    config = uvicorn.Config(
        "agorasim.api:app",
        host=settings.host,
        port=port,
        log_level=log_level,
        access_log=False,
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, name="agorasim-server",
                              daemon=True)
    thread.start()
    url = f"http://{settings.host}:{port}"
    if not wait_for_server(url):
        server.should_exit = True
        raise RuntimeError(f"AgoraSim did not start at {url}.")
    return server, thread, url


def show_status_window(server: uvicorn.Server, thread: threading.Thread,
                       url: str) -> None:
    try:
        import tkinter as tk
    except Exception:
        run_until_stopped(server, thread)
        return

    root = tk.Tk()
    root.title(APP_NAME)
    root.resizable(False, False)
    frame = tk.Frame(root, padx=18, pady=16)
    frame.grid(row=0, column=0, sticky="nsew")
    tk.Label(frame, text="AgoraSim is running",
             font=("Arial", 16, "bold")).grid(
                 row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
    tk.Label(frame, text=url).grid(row=1, column=0, columnspan=2, sticky="w")

    def open_browser() -> None:
        webbrowser.open(url)

    def stop() -> None:
        server.should_exit = True
        root.after(250, root.destroy)

    tk.Button(frame, text="Open Browser", command=open_browser).grid(
        row=2, column=0, sticky="w", pady=(14, 0), padx=(0, 8))
    tk.Button(frame, text="Stop AgoraSim", command=stop).grid(
        row=2, column=1, sticky="e", pady=(14, 0))
    root.protocol("WM_DELETE_WINDOW", stop)

    def poll() -> None:
        if not thread.is_alive():
            root.destroy()
            return
        root.after(500, poll)

    root.after(500, poll)
    root.mainloop()
    server.should_exit = True
    thread.join(timeout=5)


def run_until_stopped(server: uvicorn.Server, thread: threading.Thread) -> None:
    try:
        while thread.is_alive():
            thread.join(timeout=0.5)
    except KeyboardInterrupt:
        server.should_exit = True
        thread.join(timeout=5)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    settings = settings_from_args(args, load_config())
    if settings.show_dialog:
        prompted = prompt_settings(settings)
        if prompted is None:
            return 0
        settings = prompted
    save_config(settings)
    try:
        server, thread, url = start_server(settings, args.log_level)
    except Exception as exc:
        _show_error(str(exc))
        return 1
    if settings.open_browser:
        webbrowser.open(url)
    print(f"AgoraSim running at {url}")
    if settings.show_status_window:
        show_status_window(server, thread, url)
    else:
        run_until_stopped(server, thread)
    return 0


def _show_error(message: str) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox
    except Exception:
        print(message, file=sys.stderr)
        return
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror(APP_NAME, message)
    root.destroy()


if __name__ == "__main__":
    raise SystemExit(main())
