"""AI scenario composer: one-line brief -> full simulation scenario.

Instead of hand-editing scenarios.py, the user describes what they want to
simulate in one sentence ("union strike impact on commuter opinion",
"我要發的道歉聲明大家買不買單" ...). An LLM designs the scenario: question,
target population, ordered action space, survey questions, ABM presets.
Output is validated and range-clamped before it reaches the engine.
"""
from __future__ import annotations

import json
import re

from .i18n import norm_locale
from .providers import get_runtime_key
from .providers.llm import ClaudeProvider, GeminiProvider, LLMProvider, OpenAIProvider
from .schemas import ProviderName

_LANG_NAME = {"zh-TW": "繁體中文", "en": "English", "ja": "日本語"}

_SYSTEM = (
    "You are a survey-methodology and agent-based-modeling expert. You design "
    "simulation scenarios. Output exactly one JSON object, nothing else.")

_INSTRUCTION = """Design a social-simulation scenario for the user's brief below.

User brief: {brief}

Requirements:
- All human-readable text MUST be written in {lang}.
- action_space: 3 to 6 discrete reactions the simulated people can take.
  Tailor the actions to THIS issue and content type; do not reuse generic
  "support / wait / oppose" wording unless it truly fits. Ordered STRICTLY
  from most positive/supportive/adopting to most negative/opposing.
  Mutually exclusive, concrete, colloquial.
- adopt_action_indices: 0-based indices of actions that count as
  "positive uptake" (usually the first one or two).
- survey_questions: 2 or 3 questions that best measure what the user cares
  about. Mix types: "scale" (give scale_min/scale_max), "choice" (give 2-4
  choices), "open" (one open question max). id = short snake_case English.
- abm: social_influence 0.2-0.5 (higher for viral/social topics),
  adoption_threshold -0.2-0.4 (lower = easier uptake), innovation_p 0.02-0.06,
  imitation_q 0.3-0.6 (higher for word-of-mouth-driven topics).
- interaction_design: recommend how LLM agents should interact. Choose one
  protocol from independent_survey / social_diffusion / broadcast_comment_stream
  / sequential_exposure / focus_group / ab_treatment. Give parameters and a
  short rationale. independent_survey is for one-shot survey/creative tests;
  social_diffusion is for opinion spread; broadcast_comment_stream is for
  social posts/news comments; sequential_exposure is for staged campaigns or
  crisis response; focus_group is for qualitative insight; ab_treatment is for
  treatment/control material comparison.
- abm_design: recommend 2 to 4 traditional ABM baselines from threshold,
  deffuant, sir, herding, degroot, voter, discrete_choice. For each baseline,
  set enabled, label, params, extra params, and rationale.
- comparison_plan: do not include a random baseline. List which traditional
  ABM baselines should run and the primary metrics. Always include at least
  one ABM baseline.
- content_type: one of news / social_post / ad / policy / product / other.
- If the brief implies the user will paste their own draft content
  (a post, statement, ad copy), set needs_verbatim to true.
- prompts: write editable LLM-agent prompts customized for this brief.
  system_template MUST include {{persona_block}}. task_template MUST include
  {{question}}, {{actions}} and {{answers_field}}. Keep task_template focused on
  this scenario and require one JSON object only.

Output JSON schema:
{{
 "name": "<short scenario name>",
 "description": "<one sentence: what this scenario simulates>",
 "event_title": "<suggested event title from the brief>",
 "event_description": "<2-3 sentence event description drafted from the brief; empty if user should paste their own>",
 "question": "<the simulation question>",
 "target_population": "<who the agents represent>",
 "action_space": ["...", "..."],
 "adopt_action_indices": [0],
 "survey_questions": [
   {{"id": "...", "text": "...", "type": "scale", "scale_min": 1, "scale_max": 5}},
   {{"id": "...", "text": "...", "type": "choice", "choices": ["...", "..."]}}
 ],
 "abm": {{"social_influence": 0.35, "adoption_threshold": 0.2,
          "innovation_p": 0.04, "imitation_q": 0.5}},
 "interaction_design": {{
   "recommended_protocol": "social_diffusion",
   "alternatives": ["independent_survey"],
   "params": {{"rounds": 3, "neighbor_sample": 4, "memory": true,
              "allow_stance_change": true, "group_size": 6,
              "broadcast_top_k": 5,
              "exposure_schedule": [], "treatment_labels": []}},
   "rationale": "<why this protocol fits>"
 }},
 "abm_design": {{
   "recommended_baselines": [
     {{"model": "threshold", "label": "Threshold / Bass adoption",
       "enabled": true,
       "params": {{"social_influence": 0.35, "adoption_threshold": 0.2,
                  "innovation_p": 0.04, "imitation_q": 0.5, "noise": 0.08}},
       "extra": {{}},
       "rationale": "<why include it>"}}
   ]
 }},
 "comparison_plan": {{
   "run_random_baseline": false,
   "run_classic_baselines": ["threshold"],
   "primary_metrics": ["adoption_rate", "polarization", "action_distribution"]
 }},
 "content_type": "social_post",
 "needs_verbatim": false,
 "prompts": {{
   "system_template": "<role instructions containing {{persona_block}}>",
   "task_template": "<scenario-specific task using {{question}}, {{actions}}, {{answers_field}}>"
 }}
}}"""

_JSON_RE = re.compile(r"\{.*\}", re.DOTALL)
COMPOSER_MAX_TOKENS = 4096

_PROVIDER_CLASSES: dict[str, type[LLMProvider]] = {
    "claude": ClaudeProvider, "openai": OpenAIProvider, "gemini": GeminiProvider,
}


class ComposeError(RuntimeError):
    pass


def _pick_provider(preferred: str | None = None) -> LLMProvider:
    order = ([preferred] if preferred in _PROVIDER_CLASSES else []) + \
        [p for p in ("claude", "openai", "gemini") if p != preferred]
    for name in order:
        p = _PROVIDER_CLASSES[name](api_key=get_runtime_key(name) or None)
        if p.api_key:
            p.max_retries = 1
            return p
    raise ComposeError(
        "No LLM API key configured. Add a key for Claude, OpenAI or Gemini "
        "(UI key panel, or env ANTHROPIC_API_KEY / OPENAI_API_KEY / "
        "GEMINI_API_KEY).")


def _clamp(v, lo, hi, default):
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return default


def _validate(data: dict, locale: str) -> dict:
    raw_actions = data.get("action_space", data.get("actions", []))
    actions = [str(a).strip()[:60] for a in raw_actions
               if str(a).strip()]
    if len(actions) < 2:
        raise ComposeError("composer returned fewer than 2 actions")
    actions = actions[:6]

    adopt = [i for i in data.get("adopt_action_indices", [0])
             if isinstance(i, int) and 0 <= i < len(actions)] or [0]

    surveys = []
    seen_ids: set[str] = set()
    for q in data.get("survey_questions", [])[:4]:
        qid = re.sub(r"\W+", "_", str(q.get("id", "")))[:30] or f"q{len(surveys)+1}"
        if qid in seen_ids:
            qid = f"{qid}_{len(surveys)+1}"
        seen_ids.add(qid)
        qtype = q.get("type") if q.get("type") in ("scale", "choice", "open") else "scale"
        item = {"id": qid, "text": str(q.get("text", ""))[:150], "type": qtype}
        if not item["text"]:
            continue
        if qtype == "scale":
            lo = int(_clamp(q.get("scale_min", 1), -10, 100, 1))
            hi = int(_clamp(q.get("scale_max", 5), lo + 1, 100, 5))
            item.update(scale_min=lo, scale_max=hi)
        elif qtype == "choice":
            choices = [str(c)[:40] for c in q.get("choices", []) if str(c).strip()][:5]
            if len(choices) < 2:
                continue
            item["choices"] = choices
        surveys.append(item)

    abm_in = data.get("abm", {}) or {}
    abm = {"social_influence": round(_clamp(abm_in.get("social_influence"), 0.1, 0.6, 0.35), 2),
           "adoption_threshold": round(_clamp(abm_in.get("adoption_threshold"), -0.3, 0.5, 0.2), 2),
           "innovation_p": round(_clamp(abm_in.get("innovation_p"), 0.01, 0.1, 0.04), 3),
           "imitation_q": round(_clamp(abm_in.get("imitation_q"), 0.2, 0.7, 0.45), 2),
           "noise": round(_clamp(abm_in.get("noise"), 0, 0.5, 0.08), 3)}

    ct = data.get("content_type")
    if ct not in ("news", "social_post", "ad", "policy", "product", "other"):
        ct = "other"

    prompts_in = data.get("prompts", {}) or {}
    prompts = {}
    if isinstance(prompts_in, dict):
        system_template = str(prompts_in.get("system_template", "")).strip()
        task_template = str(prompts_in.get("task_template", "")).strip()
        if "{persona_block}" in system_template:
            prompts["system_template"] = system_template[:3000]
        if all(x in task_template for x in ("{question}", "{actions}", "{answers_field}")):
            prompts["task_template"] = task_template[:3000]

    return {
        "id": "composed", "icon": "sparkles",
        "name": str(data.get("name", ""))[:60] or "Composed scenario",
        "description": str(data.get("description", ""))[:200],
        "event_title": str(data.get("event_title", ""))[:120],
        "event_description": str(data.get("event_description", ""))[:600],
        "question": str(data.get("question", ""))[:300],
        "target_population": str(data.get("target_population", ""))[:200],
        "content_placeholder": "",
        "action_space": actions,
        "adopt_action_indices": adopt,
        "survey_questions": surveys,
        "abm": abm,
        "interaction_design": _validate_interaction(data, abm),
        "abm_design": _validate_abm_design(data, abm),
        "comparison_plan": _validate_comparison(data),
        "content_type": ct,
        "needs_verbatim": bool(data.get("needs_verbatim", False)),
        "prompts": prompts,
    }


_PROTOCOLS = {
    "independent_survey", "social_diffusion", "broadcast_comment_stream",
    "sequential_exposure", "focus_group", "ab_treatment",
}
_ABM_MODELS = {
    "threshold", "deffuant", "sir", "herding",
    "degroot", "voter", "discrete_choice",
}


def _validate_interaction(data: dict, abm: dict) -> dict:
    raw = data.get("interaction_design", {}) or {}
    params = raw.get("params", {}) if isinstance(raw.get("params"), dict) else {}
    protocol = raw.get("recommended_protocol") or raw.get("protocol")
    if protocol not in _PROTOCOLS:
        protocol = "social_diffusion"
    rounds = int(_clamp(params.get("rounds"), 1, 10, 3))
    return {
        "recommended_protocol": protocol,
        "alternatives": [p for p in raw.get("alternatives", [])
                         if p in _PROTOCOLS and p != protocol][:3],
        "params": {
            "rounds": rounds,
            "neighbor_sample": int(_clamp(
                params.get("neighbor_sample"), 0, 20, 4)),
            "memory": bool(params.get("memory", True)),
            "allow_stance_change": bool(
                params.get("allow_stance_change", True)),
            "group_size": int(_clamp(params.get("group_size"), 2, 30, 6)),
            "broadcast_top_k": int(_clamp(
                params.get("broadcast_top_k"), 1, 30, 5)),
            "exposure_schedule": [
                str(x)[:220] for x in params.get("exposure_schedule", [])
                if str(x).strip()][:10],
            "treatment_labels": [
                str(x)[:120] for x in params.get("treatment_labels", [])
                if str(x).strip()][:8],
        },
        "rationale": str(raw.get("rationale", ""))[:500],
    }


def _baseline_from_raw(raw: dict, fallback_abm: dict) -> dict | None:
    model = raw.get("model")
    if model == "threshold_bass":
        model = "threshold"
    if model not in _ABM_MODELS:
        return None
    params = raw.get("params", {}) if isinstance(raw.get("params"), dict) else {}
    extra = raw.get("extra", {}) if isinstance(raw.get("extra"), dict) else {}
    abm = {
        "classic_model": model,
        "social_influence": round(_clamp(
            params.get("social_influence"), 0, 1, fallback_abm["social_influence"]), 2),
        "adoption_threshold": round(_clamp(
            params.get("adoption_threshold"), -1, 1,
            fallback_abm["adoption_threshold"]), 2),
        "innovation_p": round(_clamp(
            params.get("innovation_p"), 0, 0.2, fallback_abm["innovation_p"]), 3),
        "imitation_q": round(_clamp(
            params.get("imitation_q"), 0, 1, fallback_abm["imitation_q"]), 2),
        "noise": round(_clamp(params.get("noise"), 0, 0.5,
                              fallback_abm.get("noise", 0.08)), 3),
        "extra": {str(k)[:40]: _clamp(v, -10, 10, 0)
                  for k, v in extra.items()},
    }
    return {
        "id": model,
        "label": str(raw.get("label", model.replace("_", " ").title()))[:80],
        "model": model,
        "enabled": bool(raw.get("enabled", True)),
        "abm": abm,
        "rationale": str(raw.get("rationale", ""))[:500],
    }


def _validate_abm_design(data: dict, fallback_abm: dict) -> dict:
    raw = data.get("abm_design", {}) or {}
    items = raw.get("recommended_baselines", [])
    baselines = []
    if isinstance(items, list):
        for item in items[:5]:
            if isinstance(item, dict):
                b = _baseline_from_raw(item, fallback_abm)
                if b:
                    baselines.append(b)
    if not baselines:
        baselines = [
            _baseline_from_raw({
                "model": "threshold", "label": "Threshold / Bass adoption",
                "enabled": True, "params": fallback_abm,
                "rationale": "Default adoption baseline."}, fallback_abm)
        ]
    return {"recommended_baselines": [b for b in baselines if b]}


def _validate_comparison(data: dict) -> dict:
    raw = data.get("comparison_plan", {}) or {}
    chosen = []
    for m in raw.get("run_classic_baselines", []):
        if m == "threshold_bass":
            m = "threshold"
        if m in _ABM_MODELS and m not in chosen:
            chosen.append(m)
    return {
        "run_random_baseline": False,
        "run_classic_baselines": chosen or ["threshold"],
        "primary_metrics": [
            str(x)[:40] for x in raw.get("primary_metrics", [
                "adoption_rate", "polarization", "action_distribution"])
            if str(x).strip()][:6],
    }


def _loads_first_json_object(text: str) -> dict:
    raw = text.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-zA-Z]*\n?|```$", "", raw,
                     flags=re.MULTILINE).strip()
    decoder = json.JSONDecoder()
    for i, ch in enumerate(raw):
        if ch != "{":
            continue
        try:
            data, _ = decoder.raw_decode(raw[i:])
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            return data
    m = _JSON_RE.search(raw)
    if m:
        return json.loads(m.group(0))
    if raw.startswith("{") or "\n{" in raw:
        raise ComposeError(
            "composer returned incomplete JSON; provider output was likely "
            "truncated. Try again or use a model with a larger output limit. "
            f"Preview: {text[:240]}")
    raise ComposeError(f"composer returned no JSON: {text[:240]}")


async def compose_scenario(brief: str, locale: str = "en",
                           preferred_provider: str | None = None) -> dict:
    brief = (brief or "").strip()
    if not brief:
        raise ComposeError("empty brief")
    loc = norm_locale(locale)
    provider = _pick_provider(preferred_provider)
    prompt = _INSTRUCTION.format(brief=brief[:2000], lang=_LANG_NAME[loc])
    text, _, _ = await provider._call(_SYSTEM, prompt, [], 0.6,
                                      max_tokens=COMPOSER_MAX_TOKENS)
    return _validate(_loads_first_json_object(text), loc)
