"""Model catalog and live provider-model discovery.

The UI should not hard-code model ids. This module provides a conservative
seed catalog for offline use, then overlays live model-list results when API
keys are available. Live results are treated as the authority for availability.
"""
from __future__ import annotations

import os
import itertools
from typing import Any, Optional

import httpx

from .providers.llm import _lookup_price


TEXT_PROVIDERS = {"claude", "openai", "gemini", "custom"}
AVG_INPUT_TOKENS = 1500
AVG_OUTPUT_TOKENS = 300


SEED_MODELS: list[dict[str, Any]] = [
    # OpenAI seed options. Availability is verified at runtime via /v1/models.
    {"provider": "openai", "id": "gpt-5.5", "label": "GPT-5.5",
     "family": "GPT-5", "tier": "frontier", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "openai", "id": "gpt-5.4", "label": "GPT-5.4",
     "family": "GPT-5", "tier": "frontier", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "openai", "id": "gpt-5.4-mini", "label": "GPT-5.4 mini",
     "family": "GPT-5", "tier": "balanced", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "openai", "id": "gpt-5", "label": "GPT-5",
     "family": "GPT-5", "tier": "frontier", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "openai", "id": "gpt-4.1", "label": "GPT-4.1",
     "family": "GPT-4", "tier": "balanced", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "openai", "id": "gpt-4o", "label": "GPT-4o",
     "family": "GPT-4", "tier": "balanced", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "openai", "id": "gpt-4o-mini", "label": "GPT-4o mini",
     "family": "GPT-4", "tier": "cheap", "supports_vision": True,
     "supports_json": True, "preview": False},

    # Anthropic seed options. Availability is verified at runtime via /v1/models.
    {"provider": "claude", "id": "claude-fable-5", "label": "Claude Fable 5",
     "family": "Claude 5", "tier": "frontier", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "claude", "id": "claude-sonnet-5", "label": "Claude Sonnet 5",
     "family": "Claude 5", "tier": "balanced", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "claude", "id": "claude-opus-4-8", "label": "Claude Opus 4.8",
     "family": "Claude 4", "tier": "frontier", "supports_vision": True,
     "supports_json": True, "preview": False},
    {"provider": "claude", "id": "claude-haiku-4-5", "label": "Claude Haiku 4.5",
     "family": "Claude 4", "tier": "cheap", "supports_vision": True,
     "supports_json": True, "preview": False},

    # Gemini seed options. Availability is verified at runtime via models.list.
    {"provider": "gemini", "id": "gemini-3.1-pro-preview",
     "label": "Gemini 3.1 Pro preview", "family": "Gemini 3",
     "tier": "frontier", "supports_vision": True, "supports_json": True,
     "preview": True},
    {"provider": "gemini", "id": "gemini-3.0-pro",
     "label": "Gemini 3.0 Pro", "family": "Gemini 3",
     "tier": "frontier", "supports_vision": True, "supports_json": True,
     "preview": False},
    {"provider": "gemini", "id": "gemini-3.5-flash",
     "label": "Gemini 3.5 Flash", "family": "Gemini 3",
     "tier": "balanced", "supports_vision": True, "supports_json": True,
     "preview": False},
    {"provider": "gemini", "id": "gemini-2.5-pro",
     "label": "Gemini 2.5 Pro", "family": "Gemini 2",
     "tier": "frontier", "supports_vision": True, "supports_json": True,
     "preview": False},
    {"provider": "gemini", "id": "gemini-2.5-flash",
     "label": "Gemini 2.5 Flash", "family": "Gemini 2",
     "tier": "cheap", "supports_vision": True, "supports_json": True,
     "preview": False},

    {"provider": "random", "id": "random-walk", "label": "Random walk baseline",
     "family": "offline", "tier": "free", "supports_vision": False,
     "supports_json": True, "preview": False, "available": True},
    {"provider": "classic", "id": "classic-family-v2",
     "label": "Classic ABM family v2", "family": "offline", "tier": "free",
     "supports_vision": False, "supports_json": True, "preview": False,
     "available": True},
]


def seed_models(provider: Optional[str] = None) -> list[dict[str, Any]]:
    models = [_with_pricing(dict(m, source="seed",
                                 available=m.get("available", False)))
              for m in SEED_MODELS]
    if provider:
        models = [m for m in models if m["provider"] == provider]
    return models


def _model_score(provider: str, model_id: str, tier: str = "") -> int:
    mid = model_id.lower()
    if "5.5" in mid:
        base = 100
    elif "5.4" in mid:
        base = 96
    elif "fable-5" in mid:
        base = 95
    elif "sonnet-5" in mid:
        base = 92
    elif "3.1" in mid:
        base = 91
    elif "3.5" in mid:
        base = 88
    elif "opus-4" in mid:
        base = 86
    elif "haiku-4" in mid:
        base = 82
    elif "gpt-5" in mid:
        base = 80
    elif "2.5" in mid:
        base = 75
    elif "4.1" in mid:
        base = 70
    elif "4o" in mid:
        base = 65
    else:
        base = 50 if provider in TEXT_PROVIDERS else 10
    if tier == "cheap" or "mini" in mid or "flash" in mid or "haiku" in mid:
        base -= 6
    return base


def _with_pricing(model: dict[str, Any]) -> dict[str, Any]:
    provider = model.get("provider", "")
    mid = model.get("id", "")
    if provider in TEXT_PROVIDERS:
        pin, pout = _lookup_price(mid)
    else:
        pin, pout = (0.0, 0.0)
    model["price_input_per_mtok"] = pin
    model["price_output_per_mtok"] = pout
    model["score"] = _model_score(provider, mid, str(model.get("tier", "")))
    model["pricing_note"] = "approximate"
    if "supports_image" not in model:
        model["supports_image"] = bool(model.get("supports_vision", False))
    if "supports_video" not in model:
        model["supports_video"] = provider == "gemini"
    if "supports_document" not in model:
        model["supports_document"] = provider == "gemini"
    return model


def estimate_model_cost_usd(model: dict[str, Any], n_agents: int,
                            rounds: int,
                            input_tokens: int = AVG_INPUT_TOKENS,
                            output_tokens: int = AVG_OUTPUT_TOKENS) -> float:
    calls = n_agents * rounds
    return round(calls * (
        input_tokens / 1e6 * float(model.get("price_input_per_mtok", 0.0)) +
        output_tokens / 1e6 * float(model.get("price_output_per_mtok", 0.0))
    ), 4)


def _openai_model_allowed(model_id: str) -> bool:
    deny = ("embed", "embedding", "whisper", "tts", "audio", "image", "dall",
            "moderation", "realtime", "transcribe", "speech")
    if any(part in model_id for part in deny):
        return False
    return model_id.startswith(("gpt-", "o", "chatgpt"))


def _model_label(model_id: str) -> str:
    return model_id.replace("-", " ").replace("_", " ").title()


async def fetch_provider_models(provider: str, api_key: str = "",
                                base_url: Optional[str] = None,
                                timeout: float = 15.0) -> list[dict[str, Any]]:
    """Fetch live model ids from a provider.

    Raises httpx/JSON errors to the caller; API endpoints convert them into
    non-fatal warnings so the seed catalog remains usable offline.
    """
    provider = provider.lower()
    if provider == "openai":
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get("https://api.openai.com/v1/models",
                                 headers={"Authorization": f"Bearer {api_key}"})
        r.raise_for_status()
        data = r.json().get("data", [])
        return [_with_pricing({
            "provider": "openai", "id": item["id"],
            "label": _model_label(item["id"]), "family": "OpenAI",
            "tier": "live", "supports_vision": True, "supports_json": True,
            "preview": "preview" in item["id"], "source": "api",
            "available": True,
        }) for item in data if _openai_model_allowed(item.get("id", ""))]

    if provider == "claude":
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(
                "https://api.anthropic.com/v1/models",
                headers={"x-api-key": api_key,
                         "anthropic-version": "2023-06-01"})
        r.raise_for_status()
        data = r.json().get("data", [])
        out = []
        for item in data:
            mid = item.get("id") or item.get("name")
            if not mid:
                continue
            out.append(_with_pricing({
                "provider": "claude", "id": mid,
                "label": item.get("display_name") or _model_label(mid),
                "family": "Claude", "tier": "live",
                "supports_vision": True, "supports_json": True,
                "preview": "preview" in mid, "source": "api",
                "available": True,
                "context_window": item.get("context_window")
                                  or item.get("max_input_tokens"),
            }))
        return out

    if provider == "gemini":
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(
                "https://generativelanguage.googleapis.com/v1beta/models",
                params={"key": api_key, "pageSize": 1000})
        r.raise_for_status()
        out = []
        for item in r.json().get("models", []):
            methods = item.get("supportedGenerationMethods") \
                or item.get("supported_actions") or []
            if methods and "generateContent" not in methods:
                continue
            name = item.get("name", "")
            mid = name.removeprefix("models/")
            if not mid:
                continue
            out.append(_with_pricing({
                "provider": "gemini", "id": mid,
                "label": item.get("displayName") or _model_label(mid),
                "family": item.get("baseModelId", "Gemini"),
                "tier": "live", "supports_vision": True,
                "supports_json": True, "preview": "preview" in mid,
                "source": "api", "available": True,
                "context_window": item.get("inputTokenLimit"),
                "max_output_tokens": item.get("outputTokenLimit"),
            }))
        return out

    if provider == "custom":
        root = (base_url or os.environ.get("CUSTOM_BASE_URL", "")).rstrip("/")
        if not root:
            return []
        headers = ({"Authorization": f"Bearer {api_key}"}
                   if api_key else {})
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(f"{root}/models", headers=headers)
        r.raise_for_status()
        data = r.json().get("data", [])
        return [_with_pricing({
            "provider": "custom", "id": item.get("id", ""),
            "label": item.get("id", ""), "family": "OpenAI-compatible",
            "tier": "custom", "supports_vision": False,
            "supports_json": True, "preview": False,
            "source": "api", "available": True,
        }) for item in data if item.get("id")]

    return []


def merge_models(seed: list[dict[str, Any]],
                 live: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_key = {(m["provider"], m["id"]): dict(m) for m in seed}
    for item in live:
        key = (item["provider"], item["id"])
        merged = by_key.get(key, {})
        merged.update(item)
        by_key[key] = _with_pricing(merged)
    return sorted(by_key.values(), key=lambda m: (
        m["provider"], not m.get("available", False), -int(m.get("score", 0)),
        str(m.get("family", "")), str(m.get("label", m["id"]))))


def plan_mix_for_budget(models: list[dict[str, Any]], budget_usd: float,
                        n_agents: int, rounds: int,
                        step_pct: int = 5) -> dict[str, Any]:
    """Greedy budget planner, prioritizing newer/higher-score models.

    It allocates in step_pct chunks. Each chunk goes to the highest-score model
    whose incremental cost still fits. Any remaining share is assigned to
    classic (free) so weights always sum to 100%.
    """
    budget = max(0.0, float(budget_usd))
    step = max(1, min(50, int(step_pct)))
    all_candidates = [
        m for m in models
        if m.get("provider") in TEXT_PROVIDERS
        and float(m.get("price_input_per_mtok", 0.0)) > 0
    ]
    all_candidates.sort(key=lambda m: (
        -int(m.get("score", 0)),
        estimate_model_cost_usd(m, n_agents, rounds),
        str(m.get("provider", "")), str(m.get("id", ""))))
    candidates = []
    seen_providers: set[str] = set()
    for model in all_candidates:
        provider = str(model.get("provider", ""))
        if provider in seen_providers:
            continue
        seen_providers.add(provider)
        candidates.append(model)

    weights: dict[tuple[str, str], int] = {}
    remaining_budget = budget
    used_pct = 0
    for _ in range(100 // step):
        picked = None
        for m in candidates:
            full_cost = estimate_model_cost_usd(m, n_agents, rounds)
            inc = full_cost * step / 100
            if inc <= remaining_budget + 1e-9:
                picked = (m, inc)
                break
        if picked is None:
            break
        model, inc_cost = picked
        key = (model["provider"], model["id"])
        weights[key] = weights.get(key, 0) + step
        remaining_budget -= inc_cost
        used_pct += step

    if used_pct < 100:
        weights[("classic", "classic-family-v2")] = \
            weights.get(("classic", "classic-family-v2"), 0) + (100 - used_pct)

    slots = []
    by_key = {(m["provider"], m["id"]): m for m in models}
    estimated = 0.0
    for (provider, model_id), pct in sorted(
            weights.items(), key=lambda kv: (-kv[1], kv[0][0], kv[0][1])):
        model = by_key.get((provider, model_id), {
            "provider": provider, "id": model_id, "label": model_id})
        full = estimate_model_cost_usd(_with_pricing(dict(model)), n_agents, rounds)
        estimated += full * pct / 100
        slots.append({
            "provider": provider, "model": model_id, "weight_pct": pct,
            "label": model.get("label", model_id),
            "full_sim_cost_usd": full,
            "allocated_cost_usd": round(full * pct / 100, 4),
            "score": model.get("score", 0),
        })

    return {
        "budget_usd": round(budget, 4),
        "estimated_cost_usd": round(estimated, 4),
        "remaining_budget_usd": round(max(0.0, budget - estimated), 4),
        "slots": slots,
        "pricing_note": "approximate; update provider prices before production billing",
    }


def plan_models_for_fixed_mix(models: list[dict[str, Any]], budget_usd: float,
                              n_agents: int, rounds: int,
                              provider_weights: list[dict[str, Any]]
                              ) -> dict[str, Any]:
    """Choose model versions under budget while preserving provider weights."""
    budget = max(0.0, float(budget_usd))
    selected_rows = [
        row for row in provider_weights
        if float(row.get("weight_pct", row.get("weight", 0)) or 0) > 0
    ]
    by_provider: dict[str, list[dict[str, Any]]] = {}
    for model in models:
        provider = str(model.get("provider", ""))
        by_provider.setdefault(provider, []).append(model)
    for candidates in by_provider.values():
        candidates.sort(key=lambda m: (
            -int(m.get("score", 0)),
            estimate_model_cost_usd(m, n_agents, rounds),
            str(m.get("id", ""))))

    fixed_slots: list[dict[str, Any]] = []
    choice_groups: list[tuple[dict[str, Any], list[dict[str, Any]]]] = []
    warnings: list[str] = []
    for row in selected_rows:
        provider = str(row.get("provider", ""))
        weight = float(row.get("weight_pct", row.get("weight", 0)) or 0)
        current_model = str(row.get("model") or "")
        candidates = [m for m in by_provider.get(provider, [])
                      if provider in TEXT_PROVIDERS
                      and float(m.get("price_input_per_mtok", 0.0)) > 0]
        if candidates:
            choice_groups.append(({"provider": provider, "weight_pct": weight,
                                   "current_model": current_model}, candidates))
            continue
        fixed_model = next((m for m in by_provider.get(provider, [])
                            if m.get("id") == current_model),
                           {"provider": provider, "id": current_model,
                            "label": current_model or provider})
        fixed_slots.append({
            "provider": provider, "model": fixed_model.get("id", current_model),
            "label": fixed_model.get("label", fixed_model.get("id", provider)),
            "weight_pct": weight, "full_sim_cost_usd": 0.0,
            "allocated_cost_usd": 0.0,
            "score": fixed_model.get("score", 0),
            "changed": False,
        })

    best: tuple[float, float, list[dict[str, Any]]] | None = None
    cheapest: tuple[float, float, list[dict[str, Any]]] | None = None
    groups = [g[1] for g in choice_groups]
    if groups:
        for combo in itertools.product(*groups):
            slots = []
            total_cost = 0.0
            score = 0.0
            for (row, _), model in zip(choice_groups, combo):
                weight = float(row["weight_pct"])
                full = estimate_model_cost_usd(model, n_agents, rounds)
                allocated = full * weight / 100
                total_cost += allocated
                score += float(model.get("score", 0)) * weight
                slots.append({
                    "provider": row["provider"], "model": model["id"],
                    "label": model.get("label", model["id"]),
                    "weight_pct": weight, "full_sim_cost_usd": full,
                    "allocated_cost_usd": round(allocated, 4),
                    "score": model.get("score", 0),
                    "changed": bool(row.get("current_model")
                                    and row["current_model"] != model["id"]),
                })
            candidate = (score, total_cost, slots)
            if total_cost <= budget + 1e-9:
                if best is None or (score, -total_cost) > (best[0], -best[1]):
                    best = candidate
            if cheapest is None or (total_cost, -score) < (cheapest[1], -cheapest[0]):
                cheapest = candidate

    chosen = best or cheapest or (0.0, 0.0, [])
    score, cost, variable_slots = chosen
    fits = cost <= budget + 1e-9
    if not fits:
        warnings.append("Budget is below the cheapest fixed-ratio model combination.")
    slots = fixed_slots + variable_slots
    slots.sort(key=lambda s: str(s["provider"]))
    return {
        "budget_usd": round(budget, 4),
        "estimated_cost_usd": round(cost, 4),
        "remaining_budget_usd": round(max(0.0, budget - cost), 4),
        "fits_budget": fits,
        "mode": "fixed_provider_weights",
        "slots": slots,
        "warnings": warnings,
        "score": round(score, 2),
        "pricing_note": "approximate; provider weights are preserved; only model versions change",
    }
