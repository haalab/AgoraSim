"""Persona sampling with stratification, diversity guarantees and locales.

Design goals (see DESIGN.md §5):
- stratified sampling over demographic marginals so tail groups always appear
- concrete narrative backstories, not attribute bags
- pre-sampled initial stance so agents do not all start from the model's median view
- contrarian quota with a plausible narrative reason
- locale-aware (zh-TW / en / ja): personas live in the simulation's language
"""
from __future__ import annotations

import random

from .i18n import PS, norm_locale
from .schemas import DEFAULT_TRAITS, Persona, PopulationSpec


def _stratified_assign(rng: random.Random, dist: dict[str, float], n: int) -> list[str]:
    """Largest-remainder allocation of n samples to categories, then shuffle."""
    total = sum(dist.values()) or 1.0
    quotas = {k: v / total * n for k, v in dist.items()}
    counts = {k: int(q) for k, q in quotas.items()}
    remainder = n - sum(counts.values())
    by_frac = sorted(quotas, key=lambda k: quotas[k] - counts[k], reverse=True)
    for k in by_frac[:remainder]:
        counts[k] += 1
    out: list[str] = []
    for k, c in counts.items():
        out.extend([k] * c)
    rng.shuffle(out)
    return out


def _sample_trait(rng: random.Random, spec: PopulationSpec,
                  trait: str) -> float:
    if trait in spec.trait_means:
        mean = max(0.01, min(0.99, float(spec.trait_means[trait])))
        concentration = 8.0
        a = max(0.2, mean * concentration)
        b = max(0.2, (1.0 - mean) * concentration)
        return round(rng.betavariate(a, b), 2)
    a, b = spec.trait_beta
    return round(rng.betavariate(a, b), 2)


def _target_demographic_hints(target: str, pack: dict) -> dict[str, dict[str, float]]:
    """Small deterministic parser for common target-population phrases.

    It is intentionally conservative: explicit UI demographic weights always
    win; this only gives natural-language target text a useful first effect.
    """
    t = (target or "").lower()
    hints: dict[str, dict[str, float]] = {}

    if any(k in t for k in ("18-24", "學生", "大學生", "young", "student")):
        hints["age"] = {"18-24": 0.7, "25-34": 0.3}
    elif any(k in t for k in ("年輕", "青年", "25-35", "25-34", "young adult")):
        hints["age"] = {"25-34": 0.7, "35-44": 0.3}
    elif any(k in t for k in ("家庭", "父母", "育兒", "雙薪", "小孩", "parents")):
        hints["age"] = {"25-34": 0.35, "35-44": 0.45, "45-54": 0.2}
    elif any(k in t for k in ("銀髮", "長者", "退休", "elder", "senior")):
        hints["age"] = {"55-64": 0.35, "65+": 0.65}

    if any(k in t for k in ("台北", "新北", "北部", "都會", "metro", "urban")):
        if "北部都會" in pack["demographics"].get("region", {}):
            hints["region"] = {"北部都會": 0.9, "中部": 0.05, "南部": 0.05}
        elif "major metro" in pack["demographics"].get("region", {}):
            hints["region"] = {"major metro": 0.85, "suburb": 0.15}
    elif any(k in t for k in ("南部", "高雄", "台南")):
        hints["region"] = {"南部": 0.85, "中部": 0.15}

    if any(k in t for k in ("高收入", "高資產", "主管", "high income")):
        keys = pack["demographics"].get("income", {})
        if "高收入" in keys:
            hints["income"] = {"中高收入": 0.45, "高收入": 0.55}
        elif "high" in keys:
            hints["income"] = {"upper-middle": 0.45, "high": 0.55}
    elif any(k in t for k in ("低收入", "弱勢", "low income")):
        keys = pack["demographics"].get("income", {})
        if "低收入" in keys:
            hints["income"] = {"低收入": 0.65, "中低收入": 0.35}
        elif "low" in keys:
            hints["income"] = {"low": 0.7, "lower-middle": 0.3}
    elif any(k in t for k in ("上班族", "白領", "office", "worker")):
        keys = pack["demographics"].get("income", {})
        if "中等收入" in keys:
            hints["income"] = {"中等收入": 0.5, "中高收入": 0.35, "中低收入": 0.15}
        elif "middle" in keys:
            hints["income"] = {"middle": 0.55, "upper-middle": 0.3, "lower-middle": 0.15}

    return hints


def derive_population_spec(spec: PopulationSpec, target_population: str,
                           locale: str = "zh-TW") -> PopulationSpec:
    loc = norm_locale(locale)
    pack = PS(loc)
    data = spec.model_dump()
    explicit_demographics = bool(spec.demographics)
    demographics = (
        {k: dict(v) for k, v in spec.demographics.items()}
        if explicit_demographics
        else {k: dict(v) for k, v in pack["demographics"].items()}
    )
    hints = _target_demographic_hints(target_population, pack)
    for dim, dist in hints.items():
        if not explicit_demographics or dim not in demographics:
            demographics[dim] = dist
    data["demographics"] = demographics
    notes = " ".join(x for x in [spec.custom_notes, target_population] if x).strip()
    data["custom_notes"] = notes
    if not data.get("trait_names"):
        data["trait_names"] = list(DEFAULT_TRAITS)
    return PopulationSpec(**data)


def _pressure_for_income(pack: dict, income: str,
                         rng: random.Random) -> str:
    pressures = list(pack["pressures"])
    low_keys = {"低收入", "中低收入", "low", "lower-middle"}
    high_keys = {"中高收入", "高收入", "upper-middle", "high"}
    if income in low_keys:
        filtered = [
            p for p in pressures
            if not any(k in p for k in ("穩定有閒錢", "stable income with savings"))
        ]
        return rng.choice(filtered or pressures)
    if income in high_keys:
        filtered = [
            p for p in pressures
            if not any(k in p for k in ("現金流吃緊", "cash flow is tight"))
        ]
        return rng.choice(filtered or pressures)
    return rng.choice(pressures)


def _custom_demographic_text(values: dict[str, str], locale: str) -> str:
    if not values:
        return ""
    body = "、".join(f"{k}={v}" for k, v in values.items())
    if locale == "zh-TW":
        return f" 自訂人口特徵：{body}。"
    if locale == "ja":
        return f" カスタム属性：{body}。"
    return f" Custom demographic attributes: {body}."


def sample_personas(spec: PopulationSpec, seed: int | None = None,
                    locale: str = "zh-TW") -> list[Persona]:
    loc = norm_locale(locale)
    pack = PS(loc)
    rng = random.Random(spec.seed if spec.seed is not None else seed)
    n = spec.n_agents

    demographics = spec.demographics or pack["demographics"]
    columns = {dim: _stratified_assign(rng, dist, n)
               for dim, dist in demographics.items()}

    def col(dim: str, default: str) -> list[str]:
        return columns.get(dim, [default] * n)

    n_contrarian = round(n * spec.contrarian_ratio)
    contrarian_ids = set(rng.sample(range(n), n_contrarian)) if n_contrarian else set()

    income_keys: dict[str, str] = pack["income_keys"]
    personas: list[Persona] = []
    standard_dims = {"age", "gender", "income", "region", "education"}
    for i in range(n):
        income = col("income", list(income_keys)[2])[i]
        custom_demographics = {
            dim: values[i] for dim, values in columns.items()
            if dim not in standard_dims
        }
        traits = {t: _sample_trait(rng, spec, t) for t in spec.trait_names}
        is_contrarian = i in contrarian_ids

        stance_center = spec.initial_stance_mean + (-0.4 if is_contrarian else 0.0)
        stance = rng.gauss(stance_center,
                           spec.initial_stance_spread)
        stance = max(-1.0, min(1.0, stance))

        occ_level = income_keys.get(income, "mid")
        occupation = rng.choice(pack["occupations"][occ_level])
        pressure = _pressure_for_income(pack, income, rng)
        extra = (pack["extra_sep"] + rng.choice(pack["contrarian"])) \
            if is_contrarian else ""
        name = rng.choice(pack["names"])

        backstory = pack["backstory"].format(
            name=name, age=col("age", "35-44")[i], gender=col("gender", "-")[i],
            region=col("region", "-")[i], education=col("education", "-")[i],
            occupation=occupation, income=income, pressure=pressure, extra=extra)
        backstory += _custom_demographic_text(custom_demographics, loc)
        if spec.custom_notes:
            backstory += f" [{spec.custom_notes}]"

        personas.append(Persona(
            agent_id=f"agent_{i:04d}", name=name,
            age_bracket=col("age", "35-44")[i], gender=col("gender", "-")[i],
            income=income, region=col("region", "-")[i],
            education=col("education", "-")[i], occupation=occupation,
            traits=traits, initial_stance=round(stance, 2),
            is_contrarian=is_contrarian,
            custom_demographics=custom_demographics,
            backstory=backstory,
        ))
    return personas


def persona_prompt_block(p: Persona, locale: str = "zh-TW") -> str:
    pack = PS(locale)
    trait_txt = ", ".join(f"{k}={v}" for k, v in p.traits.items())
    stance_txt = (pack["stance_pos"] if p.initial_stance > 0.2 else
                  pack["stance_neg"] if p.initial_stance < -0.2 else
                  pack["stance_mid"])
    return (f"{p.backstory}\n{pack['traits_label']}: {trait_txt}\n"
            f"{stance_txt}{pack['stance_suffix'].format(v=p.initial_stance)}")
