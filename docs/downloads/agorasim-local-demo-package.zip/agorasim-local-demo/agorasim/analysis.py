"""Metrics, survey aggregation, scenario mining and the analyst summary."""
from __future__ import annotations

import collections
import random
from statistics import mean, pstdev

from .abm import Environment
from .i18n import R
from .providers.base import BaseProvider
from .schemas import (AgentDecision, Persona, RoundMetrics, Scenario,
                      SimulationConfig, SurveyQuestion)


# ----------------------------------------------------------------- metrics

def stance_distribution(stances: list[float]) -> dict[str, float]:
    """Stable stance buckets for before/after comparisons."""
    n = max(1, len(stances))
    return {
        "positive": round(sum(s > 0.2 for s in stances) / n, 3),
        "neutral": round(sum(-0.2 <= s <= 0.2 for s in stances) / n, 3),
        "negative": round(sum(s < -0.2 for s in stances) / n, 3),
    }

def aggregate_survey(decisions: list[AgentDecision],
                     questions: list[SurveyQuestion]) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for q in questions:
        vals = [d.answers.get(q.id) for d in decisions
                if d.answers.get(q.id) is not None]
        if not vals:
            continue
        if q.type == "scale":
            nums = [v for v in vals if isinstance(v, (int, float))]
            if not nums:
                continue
            dist = collections.Counter(int(v) for v in nums)
            out[q.id] = {"type": "scale", "text": q.text,
                         "mean": round(mean(nums), 2),
                         "min": q.scale_min, "max": q.scale_max,
                         "dist": {str(k): round(v / len(nums), 3)
                                  for k, v in sorted(dist.items())}}
        elif q.type == "choice":
            dist = collections.Counter(str(v) for v in vals)
            out[q.id] = {"type": "choice", "text": q.text,
                         "dist": {k: round(v / len(vals), 3)
                                  for k, v in dist.most_common()}}
        else:
            rng = random.Random(len(vals))
            samples = rng.sample(vals, min(5, len(vals)))
            out[q.id] = {"type": "open", "text": q.text,
                         "samples": [str(s)[:120] for s in samples]}
    return out


def compute_round_metrics(round_no: int, decisions: list[AgentDecision],
                          env: Environment, bass_ref: float,
                          questions: list[SurveyQuestion] | None = None
                          ) -> RoundMetrics:
    stances = [d.stance for d in decisions] or [0.0]
    pos = sum(s > 0.5 for s in stances) / len(stances)
    neg = sum(s < -0.5 for s in stances) / len(stances)
    action_counter = collections.Counter(d.action for d in decisions)
    senti_counter = collections.Counter(d.sentiment for d in decisions)
    n = max(1, len(decisions))
    shared = [d for d in decisions if d.will_share and d.public_statement]
    rng = random.Random(round_no)
    top = [d.public_statement for d in
           rng.sample(shared, min(5, len(shared)))] if shared else []
    return RoundMetrics(
        round=round_no,
        stance_mean=round(mean(stances), 3),
        stance_std=round(pstdev(stances), 3) if len(stances) > 1 else 0.0,
        polarization=round(2 * min(pos, neg), 3),
        action_dist={k: round(v / n, 3) for k, v in action_counter.most_common()},
        stance_dist=stance_distribution(stances),
        sentiment_dist={k: round(v / n, 3)
                        for k, v in senti_counter.most_common(8)},
        adoption_rate=round(env.adoption_rate, 3),
        bass_reference=round(bass_ref, 3),
        macro={"sentiment_index": round(env.sentiment_index, 3), **env.macro},
        top_statements=top,
        silence_rate=round(sum(not d.will_share for d in decisions) / n, 3),
        survey=aggregate_survey(decisions, questions or []),
    )


# ----------------------------------------------------- scenario mining (k-means)

def _kmeans(rows: list[list[float]], k: int, iters: int = 50,
            seed: int = 7) -> list[int]:
    rng = random.Random(seed)
    centers = [list(r) for r in rng.sample(rows, k)]
    labels = [0] * len(rows)
    for _ in range(iters):
        changed = False
        for i, r in enumerate(rows):
            best = min(range(k), key=lambda c: sum(
                (a - b) ** 2 for a, b in zip(r, centers[c])))
            if best != labels[i]:
                labels[i] = best
                changed = True
        for c in range(k):
            members = [rows[i] for i in range(len(rows)) if labels[i] == c]
            if members:
                centers[c] = [sum(col) / len(members) for col in zip(*members)]
        if not changed:
            break
    return labels


def mine_scenarios(personas: list[Persona],
                   trajectories: dict[str, list[float]],
                   final_decisions: dict[str, AgentDecision],
                   max_k: int = 4, locale: str = "en") -> list[Scenario]:
    rp = R(locale)
    ids = [p.agent_id for p in personas if p.agent_id in trajectories]
    if len(ids) < 4:
        return []
    rows = [trajectories[i] for i in ids]
    k = max(2, min(max_k, len(ids) // 8 + 2, len(ids)))
    labels = _kmeans(rows, k)
    by_id = {p.agent_id: p for p in personas}

    scenarios: list[Scenario] = []
    for c in range(k):
        members = [ids[i] for i in range(len(ids)) if labels[i] == c]
        if not members:
            continue
        prob = len(members) / len(ids)
        trajs = [trajectories[m] for m in members]
        start = mean(t[0] for t in trajs)
        end = mean(t[-1] for t in trajs)
        drift = (rp["scen_drift_up"] if end - start > 0.25 else
                 rp["scen_drift_down"] if end - start < -0.25 else
                 rp["scen_drift_flat"])
        level = (rp["scen_level_pos"] if end > 0.25 else
                 rp["scen_level_neg"] if end < -0.25 else rp["scen_level_mid"])
        actions = collections.Counter(
            final_decisions[m].action for m in members if m in final_decisions)
        top_action = actions.most_common(1)[0][0] if actions else "-"
        demo = collections.Counter(
            f"{by_id[m].age_bracket}/{by_id[m].income}" for m in members)
        dominant = demo.most_common(1)[0][0]
        quotes = [final_decisions[m].public_statement for m in members
                  if m in final_decisions and final_decisions[m].public_statement][:3]
        scenarios.append(Scenario(
            name=rp["scen_name"].format(x=chr(65 + len(scenarios))),
            probability=round(prob, 3),
            description=rp["scen_desc"].format(
                level=level, end=f"{end:.2f}", drift=drift, action=top_action),
            representative_quotes=quotes,
            dominant_profile=dominant,
        ))
    scenarios.sort(key=lambda s: -s.probability)
    return scenarios


# ------------------------------------------------------------ analyst summary

def _survey_lines(survey: dict[str, dict], rp: dict[str, str]) -> list[str]:
    lines = []
    for qid, agg in survey.items():
        if agg["type"] == "scale":
            lines.append(rp["survey_scale"].format(
                text=agg["text"], mean=agg["mean"],
                lo=agg["min"], hi=agg["max"]))
        elif agg["type"] == "choice":
            dist = ", ".join(f"{k} {v:.0%}" for k, v in agg["dist"].items())
            lines.append(rp["survey_choice"].format(text=agg["text"], dist=dist))
        else:
            lines.append(rp["survey_open"].format(
                text=agg["text"], samples=" / ".join(agg["samples"][:3])))
    return lines


def _stats_digest(config: SimulationConfig, rounds, scenarios) -> str:
    rp = R(config.language)
    ev = config.event
    lines = [f"EVENT: {ev.title}\n{ev.description}"]
    if ev.verbatim_content:
        lines.append(f"VERBATIM CONTENT:\n{ev.verbatim_content}")
    lines += [f"QUESTION: {config.goal.question}",
              f"TARGET POPULATION: {config.goal.target_population}",
              f"AGENTS: {config.population.n_agents}, ROUNDS: {len(rounds)}"]
    for r in rounds:
        lines.append(
            f"round {r.round}: stance {r.stance_mean} (sd {r.stance_std}), "
            f"polarization {r.polarization}, adoption {r.adoption_rate} "
            f"(bass {r.bass_reference}), silence {r.silence_rate}, "
            f"actions {r.action_dist}, sentiment {r.sentiment_dist}")
        if r.top_statements:
            lines.append("  quotes: " + " | ".join(r.top_statements))
        if r.survey:
            lines.extend("  survey " + s for s in _survey_lines(r.survey, rp))
    for s in scenarios:
        lines.append(f"{s.name} (p={s.probability:.0%}): {s.description} "
                     f"profile {s.dominant_profile}; "
                     f"quotes: {' / '.join(s.representative_quotes)}")
    return "\n".join(lines)


async def generate_summary(config: SimulationConfig, rounds, scenarios,
                           analyst: BaseProvider | None) -> str:
    rp = R(config.language)
    digest = _stats_digest(config, rounds, scenarios)
    if analyst is not None and getattr(analyst, "api_key", ""):
        try:
            text, _, _ = await analyst._call(  # type: ignore[attr-defined]
                rp["analyst_sys"], rp["analyst_prompt"] + digest, [], 0.4,
                max_tokens=3072)
            return text.strip() + rp["disclaimer"]
        except Exception:  # noqa: BLE001 — fall through to template
            pass

    # offline fallback: template summary
    last = rounds[-1] if rounds else None
    lines = [rp["title"].format(title=config.event.title), "",
             rp["q"].format(q=config.goal.question), ""]
    if last:
        trend = rp["trend_flat"]
        if len(rounds) > 1:
            d = last.stance_mean - rounds[0].stance_mean
            trend = (rp["trend_up"] if d > 0.1 else
                     rp["trend_down"] if d < -0.1 else rp["trend_flat"])
        lines.append(rp["overview"].format(
            rounds=len(rounds), n=config.population.n_agents,
            mean=last.stance_mean, std=last.stance_std, trend=trend,
            adopt=f"{last.adoption_rate:.0%}", bass=f"{last.bass_reference:.0%}",
            pol=last.polarization, silent=f"{last.silence_rate:.0%}"))
        lines.append("")
        lines.append(rp["dist"] + ", ".join(
            f"{k} {v:.0%}" for k, v in last.action_dist.items()))
        if last.survey:
            lines.append("")
            lines.append(rp["survey_h"])
            lines.append("")
            for s in _survey_lines(last.survey, rp):
                lines.append(s + "  ")
    if scenarios:
        lines.append("")
        lines.append(rp["scen_h"])
        for s in scenarios:
            lines.append("")
            lines.append(rp["scen_line"].format(
                name=s.name, p=f"{s.probability:.0%}", desc=s.description,
                prof=s.dominant_profile))
            if s.representative_quotes:
                lines.append("> " + " / ".join(s.representative_quotes))
    return "\n".join(lines) + rp["disclaimer"]
