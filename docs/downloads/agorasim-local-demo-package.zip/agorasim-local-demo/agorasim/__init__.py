"""AgoraSim — generative agent-based modeling platform (LLM/VLM + classic ABM)."""
from .engine import Simulator, estimate_cost
from .experiments import (ExperimentRun, ExperimentSpec,
                          build_experiment_config, run_batch,
                          run_batch_async, run_experiment,
                          run_experiment_async)
from .providers import register_provider
from .schemas import (ABMParams, AgentDecision, EventInput, MediaAsset,
                      ModelMix, ModelSlot, NetworkSpec, Persona,
                      PopulationSpec, ProviderName, SimulationConfig,
                      SimulationGoal, SimulationResult)

__version__ = "1.0.0"
__all__ = [
    "Simulator", "estimate_cost", "register_provider",
    "ExperimentSpec", "ExperimentRun", "build_experiment_config",
    "run_experiment", "run_experiment_async", "run_batch",
    "run_batch_async",
    "SimulationConfig", "EventInput", "SimulationGoal", "PopulationSpec",
    "ModelMix", "ModelSlot", "ABMParams", "NetworkSpec", "MediaAsset",
    "ProviderName", "Persona", "AgentDecision", "SimulationResult",
]
