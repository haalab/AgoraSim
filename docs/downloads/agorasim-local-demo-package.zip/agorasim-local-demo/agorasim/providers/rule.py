"""Non-LLM agent backends: random noise baseline and classic ABM rules.

Both are locale-aware (statements/sentiments come from i18n.RULE_STRINGS)
and answer survey questions by mapping stance onto scales/choices.
"""
from __future__ import annotations

import random

from ..i18n import RS
from ..schemas import AgentDecision, Persona, SurveyQuestion
from .base import BaseProvider, DecisionContext


def _stance_to_action(stance: float, actions: list[str]) -> str:
    """Map stance in [-1,1] to an action bucket (action_space assumed ordered
    from most positive/adopting to most negative/rejecting)."""
    n = len(actions)
    idx = int(round((1 - (stance + 1) / 2) * (n - 1)))
    return actions[max(0, min(n - 1, idx))]


def _statement(stance: float, rng: random.Random, locale: str) -> str:
    s = RS(locale)
    if stance > 0.4:
        return rng.choice(s["pos"])
    if stance < -0.4:
        return rng.choice(s["neg"])
    return rng.choice(s["mid"])


def _sentiment(stance: float, rng: random.Random, locale: str) -> str:
    s = RS(locale)
    if stance > 0.3:
        return rng.choice(s["senti_pos"])
    if stance < -0.3:
        return rng.choice(s["senti_neg"])
    return rng.choice(s["senti_mid"])


def _survey_answers(stance: float, survey: list[SurveyQuestion],
                    rng: random.Random, locale: str) -> dict:
    """Stance-consistent survey answers for rule agents."""
    out: dict = {}
    for q in survey:
        if q.type == "scale":
            frac = (stance + 1) / 2 + rng.gauss(0, 0.12)
            frac = max(0.0, min(1.0, frac))
            out[q.id] = int(round(q.scale_min + frac * (q.scale_max - q.scale_min)))
        elif q.type == "choice" and q.choices:
            frac = 1 - (stance + 1) / 2 + rng.gauss(0, 0.15)
            idx = int(round(max(0.0, min(1.0, frac)) * (len(q.choices) - 1)))
            out[q.id] = q.choices[idx]
        else:
            out[q.id] = _statement(stance, rng, locale)
    return out


class RandomProvider(BaseProvider):
    """Bounded random walk + pressure-weighted action; zero cost baseline."""
    name = "random"
    default_model = "random-walk"

    def __init__(self, model: str | None = None, seed: int | None = None):
        super().__init__(model)
        self._rng = random.Random(seed)

    async def decide(self, persona: Persona, ctx: DecisionContext
                     ) -> tuple[AgentDecision, int, int]:
        rng, loc = self._rng, ctx.language
        before = ctx.prev_stance if ctx.round_no > 1 else persona.initial_stance
        noise = rng.gauss(0, 0.35)
        stance = max(-1.0, min(1.0, before + noise))
        action_noise = rng.gauss(0, 0.2)
        return AgentDecision(
            stance=round(stance, 2),
            sentiment=_sentiment(stance, rng, loc),
            action=_stance_to_action(stance + action_noise, ctx.action_space),
            confidence=round(rng.uniform(0.2, 0.8), 2),
            public_statement="",
            private_reasoning="(random baseline)",
            will_share=False,
            answers=_survey_answers(stance, ctx.survey, rng, loc),
            debug={
                "type": "random_baseline",
                "stance_before": round(before, 3),
                "noise": round(noise, 3),
                "action_noise": round(action_noise, 3),
                "stance_after": round(stance, 3),
            },
        ), 0, 0


class ClassicProvider(BaseProvider):
    """A family of canonical ABM dynamics, selected by ABMParams.classic_model.

    threshold — Granovetter/Bass adoption with social influence (default)
    deffuant  — bounded-confidence opinion dynamics (polarization/clustering)
    sir       — contagion: susceptible -> infected(spreading) -> recovered.
                Exposure = shared statements heard from neighbors, so the same
                will_share channel drives contagion for LLM and rule agents.
    herding   — Kirman-style herding with idiosyncratic re-evaluation

    All are driven entirely by ABMParams (+ per-model extras) — the bridge
    to traditional ABM.
    """
    name = "classic"
    default_model = "classic-family-v2"

    def __init__(self, model: str | None = None, seed: int | None = None):
        super().__init__(model)
        self._rng = random.Random(seed)
        self._sir_state: dict[str, str] = {}   # agent_id -> S | I | R

    # ------------------------------------------------------------- dynamics

    def _threshold(self, stance: float, persona: Persona,
                   ctx: DecisionContext, rng: random.Random) -> float:
        p = ctx.abm
        if ctx.neighbor_stance_mean is not None:
            stance += p.social_influence * (ctx.neighbor_stance_mean - stance)
        conformity = persona.traits.get("conformity", 0.5)
        stance += 0.15 * conformity * (2 * ctx.adoption_rate - 1) * p.imitation_q
        risk = persona.traits.get("risk_tolerance", 0.5)
        stance += p.innovation_p * (risk - 0.3)
        return stance + rng.gauss(0, p.noise)

    def _deffuant(self, stance: float, persona: Persona,
                  ctx: DecisionContext, rng: random.Random) -> float:
        p = ctx.abm
        eps = p.extra.get("confidence_bound", 0.4)
        nb = ctx.neighbor_stance_mean
        # only neighbors within the confidence bound can persuade
        if nb is not None and abs(nb - stance) < eps:
            stance += p.social_influence * (nb - stance)
        return stance + rng.gauss(0, p.noise)

    def _sir(self, stance: float, persona: Persona,
             ctx: DecisionContext, rng: random.Random) -> tuple[float, str]:
        p = ctx.abm
        infect = p.extra.get("infect_rate", 0.35)
        recover = p.extra.get("recover_rate", 0.3)
        aid = persona.agent_id
        state = self._sir_state.get(aid)
        if state is None:  # seeding: innovators with positive prior start infected
            seed_p = p.innovation_p + 0.1 * max(0.0, persona.initial_stance) \
                * persona.traits.get("tech_savvy", 0.5)
            state = "I" if rng.random() < seed_p else "S"
        exposures = len(ctx.neighbor_statements)   # shared statements heard
        if state == "S" and exposures:
            if rng.random() < 1 - (1 - infect) ** exposures:
                state = "I"
        elif state == "I" and rng.random() < recover:
            state = "R"
        self._sir_state[aid] = state
        lean = 1.0 if persona.initial_stance >= 0 else -1.0
        if state == "I":       # actively engaged: amplified toward own leaning
            stance = 0.5 * stance + 0.6 * lean
        elif state == "R":     # fatigued: decays toward indifference
            stance *= 0.5
        else:                  # susceptible: mild drift toward crowd
            if ctx.neighbor_stance_mean is not None:
                stance += 0.1 * (ctx.neighbor_stance_mean - stance)
        return stance + rng.gauss(0, p.noise), state

    def _herding(self, stance: float, persona: Persona,
                 ctx: DecisionContext, rng: random.Random) -> float:
        p = ctx.abm
        herd = p.extra.get("herd_strength", 0.5)
        idio = p.extra.get("idiosyncratic", 0.1)
        if rng.random() < idio:      # independent re-evaluation (news, analysis)
            return rng.uniform(-1, 1)
        if ctx.neighbor_stance_mean is not None:
            stance += herd * (ctx.neighbor_stance_mean - stance)
        # global market-mood term
        stance += 0.2 * herd * (2 * ctx.adoption_rate - 1)
        return stance + rng.gauss(0, p.noise)

    def _degroot(self, stance: float, persona: Persona,
                 ctx: DecisionContext, rng: random.Random) -> float:
        p = ctx.abm
        learning = p.extra.get("learning_rate", p.social_influence)
        stubborn = p.extra.get("stubbornness",
                               1 - persona.traits.get("media_trust", 0.5))
        if ctx.neighbor_stance_mean is not None:
            stance += learning * (1 - stubborn) * (
                ctx.neighbor_stance_mean - stance)
        stance += 0.08 * (1 - stubborn) * (persona.initial_stance - stance)
        return stance + rng.gauss(0, p.noise)

    def _voter(self, stance: float, persona: Persona,
               ctx: DecisionContext, rng: random.Random) -> float:
        p = ctx.abm
        majority_weight = p.extra.get("majority_weight", 0.65)
        flip_p = p.extra.get("flip_probability", 0.1)
        if ctx.neighbor_stance_mean is None:
            return stance + rng.gauss(0, p.noise)
        majority = 1.0 if ctx.neighbor_stance_mean >= 0 else -1.0
        if rng.random() < flip_p + majority_weight * abs(ctx.neighbor_stance_mean):
            stance = (1 - majority_weight) * stance + majority_weight * majority
        return stance + rng.gauss(0, p.noise)

    def _discrete_choice(self, stance: float, persona: Persona,
                         ctx: DecisionContext, rng: random.Random) -> float:
        p = ctx.abm
        price_w = p.extra.get("price_sensitivity_weight", 0.35)
        risk_w = p.extra.get("risk_penalty", 0.35)
        trust_w = p.extra.get("trust_bonus", 0.25)
        habit_w = p.extra.get("habit_inertia", 0.25)
        social_w = p.extra.get("social_proof_weight", p.social_influence)
        risk = persona.traits.get("risk_tolerance", 0.5)
        price = persona.traits.get("price_sensitivity", 0.5)
        trust = persona.traits.get("media_trust", 0.5)
        loyalty = persona.traits.get("brand_loyalty", 0.5)
        utility = stance
        utility += trust_w * (trust - 0.5)
        utility += risk_w * (risk - 0.5)
        utility -= price_w * (price - 0.5)
        utility += habit_w * (loyalty - 0.5)
        if ctx.neighbor_stance_mean is not None:
            utility += social_w * (ctx.neighbor_stance_mean - stance)
        utility += p.innovation_p - p.adoption_threshold * 0.2
        return utility + rng.gauss(0, p.noise)

    # --------------------------------------------------------------- decide

    async def decide(self, persona: Persona, ctx: DecisionContext
                     ) -> tuple[AgentDecision, int, int]:
        rng, p, loc = self._rng, ctx.abm, ctx.language
        before = ctx.prev_stance if ctx.round_no > 1 else persona.initial_stance
        stance = before
        sir_state = None
        debug = {"type": "classic_abm", "model": p.classic_model,
                 "stance_before": round(before, 3)}

        if p.classic_model == "deffuant":
            nb = ctx.neighbor_stance_mean
            stance = self._deffuant(stance, persona, ctx, rng)
            debug.update({
                "neighbor_stance_mean": None if nb is None else round(nb, 3),
                "confidence_bound": p.extra.get("confidence_bound", 0.4),
                "social_influence_beta": p.social_influence,
            })
        elif p.classic_model == "sir":
            stance, sir_state = self._sir(stance, persona, ctx, rng)
            debug.update({
                "sir_state": sir_state,
                "exposures": len(ctx.neighbor_statements),
                "infect_rate": p.extra.get("infect_rate", 0.35),
                "recover_rate": p.extra.get("recover_rate", 0.3),
            })
        elif p.classic_model == "herding":
            stance = self._herding(stance, persona, ctx, rng)
            debug.update({
                "neighbor_stance_mean": (
                    None if ctx.neighbor_stance_mean is None
                    else round(ctx.neighbor_stance_mean, 3)),
                "herd_strength": p.extra.get("herd_strength", 0.5),
                "idiosyncratic": p.extra.get("idiosyncratic", 0.1),
                "adoption_rate": round(ctx.adoption_rate, 3),
            })
        elif p.classic_model == "degroot":
            stance = self._degroot(stance, persona, ctx, rng)
            debug.update({
                "neighbor_stance_mean": (
                    None if ctx.neighbor_stance_mean is None
                    else round(ctx.neighbor_stance_mean, 3)),
                "learning_rate": p.extra.get("learning_rate", p.social_influence),
                "stubbornness": p.extra.get(
                    "stubbornness",
                    round(1 - persona.traits.get("media_trust", 0.5), 3)),
            })
        elif p.classic_model == "voter":
            stance = self._voter(stance, persona, ctx, rng)
            debug.update({
                "neighbor_stance_mean": (
                    None if ctx.neighbor_stance_mean is None
                    else round(ctx.neighbor_stance_mean, 3)),
                "majority_weight": p.extra.get("majority_weight", 0.65),
                "flip_probability": p.extra.get("flip_probability", 0.1),
            })
        elif p.classic_model == "discrete_choice":
            stance = self._discrete_choice(stance, persona, ctx, rng)
            debug.update({
                "price_sensitivity": round(
                    persona.traits.get("price_sensitivity", 0.5), 3),
                "risk_tolerance": round(
                    persona.traits.get("risk_tolerance", 0.5), 3),
                "media_trust": round(
                    persona.traits.get("media_trust", 0.5), 3),
                "price_sensitivity_weight": p.extra.get(
                    "price_sensitivity_weight", 0.35),
                "risk_penalty": p.extra.get("risk_penalty", 0.35),
                "trust_bonus": p.extra.get("trust_bonus", 0.25),
                "habit_inertia": p.extra.get("habit_inertia", 0.25),
            })
        else:
            neighbor_delta = 0.0
            if ctx.neighbor_stance_mean is not None:
                neighbor_delta = p.social_influence * (
                    ctx.neighbor_stance_mean - stance)
                stance += neighbor_delta
            conformity = persona.traits.get("conformity", 0.5)
            imitation_delta = (
                0.15 * conformity * (2 * ctx.adoption_rate - 1)
                * p.imitation_q)
            stance += imitation_delta
            risk = persona.traits.get("risk_tolerance", 0.5)
            innovation_delta = p.innovation_p * (risk - 0.3)
            stance += innovation_delta
            noise = rng.gauss(0, p.noise)
            stance += noise
            debug.update({
                "neighbor_stance_mean": (
                    None if ctx.neighbor_stance_mean is None
                    else round(ctx.neighbor_stance_mean, 3)),
                "neighbor_delta": round(neighbor_delta, 3),
                "imitation_delta": round(imitation_delta, 3),
                "innovation_delta": round(innovation_delta, 3),
                "noise": round(noise, 3),
                "social_influence_beta": p.social_influence,
                "adoption_rate": round(ctx.adoption_rate, 3),
                "adoption_threshold": p.adoption_threshold,
                "bass_p": p.innovation_p,
                "bass_q": p.imitation_q,
            })
        stance = max(-1.0, min(1.0, stance))
        debug["stance_after"] = round(stance, 3)

        eff = stance if stance >= p.adoption_threshold else min(stance, 0.0)
        debug["effective_stance_for_action"] = round(eff, 3)
        return AgentDecision(
            stance=round(stance, 2),
            sentiment=_sentiment(stance, rng, loc),
            action=_stance_to_action(eff, ctx.action_space),
            confidence=round(abs(stance) * 0.7 + 0.2, 2),
            public_statement="",
            private_reasoning=f"(classic:{p.classic_model})",
            will_share=False,
            answers=_survey_answers(stance, ctx.survey, rng, loc),
            debug=debug,
        ), 0, 0
