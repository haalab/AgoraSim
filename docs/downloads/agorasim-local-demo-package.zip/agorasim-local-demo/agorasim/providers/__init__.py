"""Provider registry, runtime key store and mix-ratio router."""
from __future__ import annotations

import os
import random

from ..schemas import ModelMix, ModelSlot, ProviderName
from .base import BaseProvider, DecisionContext, ProviderError
from .llm import ClaudeProvider, CustomOpenAIProvider, GeminiProvider, OpenAIProvider
from .rule import ClassicProvider, RandomProvider

_REGISTRY: dict[str, type[BaseProvider]] = {
    ProviderName.claude: ClaudeProvider,
    ProviderName.openai: OpenAIProvider,
    ProviderName.gemini: GeminiProvider,
    ProviderName.custom: CustomOpenAIProvider,
    ProviderName.random: RandomProvider,
    ProviderName.classic: ClassicProvider,
}

# ---------------------------------------------------------- runtime API keys
# BYOK via UI: keys live in process memory only — never persisted, never
# included in simulation results. Env vars remain the fallback.

_RUNTIME_KEYS: dict[str, str] = {}
_RUNTIME_BASE_URLS: dict[str, str] = {}
_ENV_KEYS: dict[str, list[str]] = {
    "claude": ["ANTHROPIC_API_KEY"],
    "openai": ["OPENAI_API_KEY"],
    "gemini": ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
    "custom": ["CUSTOM_API_KEY"],
}


def set_runtime_key(provider: str, key: str | None) -> None:
    if key and key.strip():
        _RUNTIME_KEYS[provider] = key.strip()
    else:
        _RUNTIME_KEYS.pop(provider, None)


def get_runtime_key(provider: str) -> str:
    if provider in _RUNTIME_KEYS:
        return _RUNTIME_KEYS[provider]
    for env in _ENV_KEYS.get(provider, []):
        if os.environ.get(env):
            return os.environ[env]
    return ""


def set_runtime_base_url(provider: str, base_url: str | None) -> None:
    if base_url and base_url.strip():
        _RUNTIME_BASE_URLS[provider] = base_url.strip().rstrip("/")
    else:
        _RUNTIME_BASE_URLS.pop(provider, None)


def get_runtime_base_url(provider: str) -> str:
    if provider in _RUNTIME_BASE_URLS:
        return _RUNTIME_BASE_URLS[provider]
    if provider == "custom":
        return os.environ.get("CUSTOM_BASE_URL", "").rstrip("/")
    return ""


def key_status() -> dict[str, bool]:
    """Which LLM providers currently have a usable key (never the key itself)."""
    status = {p: bool(get_runtime_key(p)) for p in _ENV_KEYS}
    status["custom_base_url"] = bool(get_runtime_base_url("custom"))
    return status


def register_provider(name: str, cls: type[BaseProvider]) -> None:
    """Plugin point: add custom backends (local models, other rule engines)."""
    _REGISTRY[name] = cls


def make_provider(slot: ModelSlot, seed: int | None = None) -> BaseProvider:
    cls = _REGISTRY[slot.provider]
    if slot.provider in (ProviderName.random, ProviderName.classic):
        return cls(slot.model, seed=seed)  # type: ignore[call-arg]
    if slot.provider == ProviderName.custom:
        return cls(slot.model,  # type: ignore[call-arg]
                   api_key=get_runtime_key(slot.provider.value) or None,
                   base_url=slot.base_url or get_runtime_base_url("custom"))
    return cls(slot.model,  # type: ignore[call-arg]
               api_key=get_runtime_key(slot.provider.value) or None)


def allocate_slots(mix: ModelMix, n: int, seed: int | None = None) -> list[int]:
    """Largest-remainder allocation of n agents to mix slots, shuffled.

    Guarantees ratio error <= 1 agent per slot and reproducibility via seed.
    Returns a list of slot indices, one per agent.
    """
    quotas = [s.weight * n for s in mix.slots]
    counts = [int(q) for q in quotas]
    remainder = n - sum(counts)
    order = sorted(range(len(quotas)), key=lambda i: quotas[i] - counts[i],
                   reverse=True)
    for i in order[:remainder]:
        counts[i] += 1
    assignment: list[int] = []
    for idx, c in enumerate(counts):
        assignment.extend([idx] * c)
    random.Random(seed).shuffle(assignment)
    return assignment


__all__ = [
    "BaseProvider", "DecisionContext", "ProviderError",
    "ClaudeProvider", "OpenAIProvider", "GeminiProvider", "CustomOpenAIProvider",
    "RandomProvider", "ClassicProvider",
    "register_provider", "make_provider", "allocate_slots",
    "set_runtime_key", "get_runtime_key", "set_runtime_base_url",
    "get_runtime_base_url", "key_status",
]
