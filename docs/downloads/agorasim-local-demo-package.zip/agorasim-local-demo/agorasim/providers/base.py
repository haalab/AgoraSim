"""Provider abstraction, locale-aware prompt construction, robust JSON parsing."""
from __future__ import annotations

import abc
import json
import re
from dataclasses import dataclass, field

from ..i18n import P
from ..personas import persona_prompt_block
from ..schemas import (ABMParams, AgentDecision, MediaAsset, Persona,
                       SurveyQuestion)


@dataclass
class DecisionContext:
    """Everything an agent perceives in one round."""
    event_text: str
    media: list[MediaAsset]
    use_raw_media: bool
    goal_question: str
    action_space: list[str]
    round_no: int
    total_rounds: int
    macro_text: str
    neighbor_statements: list[str]
    memory_text: str
    diversity_pressure: bool
    verbatim: str | None = None          # user's draft content, quoted verbatim
    survey: list[SurveyQuestion] = field(default_factory=list)
    language: str = "en"
    temperature: float = 0.9
    # numeric channel for rule-based providers
    prev_stance: float = 0.0
    neighbor_stance_mean: float | None = None
    adoption_rate: float = 0.0
    abm: ABMParams = field(default_factory=ABMParams)
    system_prompt_template: str = ""
    task_prompt_template: str = ""


# ---------------------------------------------------------------- prompting

def _fmt_template(template: str, **values: str) -> str:
    out = template
    for key, value in values.items():
        out = out.replace("{" + key + "}", value)
    return out.replace("{{", "{").replace("}}", "}")


def build_system_prompt(persona: Persona, locale: str = "en",
                        template: str = "") -> str:
    persona_block = persona_prompt_block(persona, locale)
    if template.strip():
        return _fmt_template(template, persona_block=persona_block)
    return P(locale)["system"].format(
        persona_block=persona_block)


def _survey_specs(survey: list[SurveyQuestion], pk: dict[str, str]) -> str:
    specs = []
    for q in survey:
        if q.type == "scale":
            specs.append(pk["scale_spec"].format(
                qid=q.id, lo=q.scale_min, hi=q.scale_max, text=q.text))
        elif q.type == "choice":
            specs.append(pk["choice_spec"].format(
                qid=q.id, choices=", ".join(q.choices), text=q.text))
        else:
            specs.append(pk["open_spec"].format(qid=q.id, text=q.text))
    return ", ".join(specs)


def build_user_prompt(ctx: DecisionContext) -> str:
    pk = P(ctx.language)
    parts = [f"{pk['h_event']}\n{ctx.event_text}"]
    if ctx.verbatim:
        parts.append(f"{pk['h_verbatim']}\n---\n{ctx.verbatim}\n---")
    if ctx.media and not ctx.use_raw_media:
        caps = []
        for m in ctx.media:
            label = f"{m.media_type.value}"
            if m.filename:
                label += f" {m.filename}"
            if m.text:
                caps.append(f"- {label}: {m.text[:4000]}")
            else:
                caps.append(f"- {label}: {m.caption or '-'}")
        parts.append(pk["h_media_desc"] + "\n" + "\n".join(caps))
    elif ctx.media and ctx.use_raw_media:
        parts.append(pk["h_media_raw"])

    parts.append(pk["h_situation"].format(r=ctx.round_no, t=ctx.total_rounds)
                 + ctx.macro_text)

    if ctx.neighbor_statements:
        quotes = "\n".join(f"- \"{s}\"" for s in ctx.neighbor_statements)
        parts.append(f"{pk['h_heard']}\n{quotes}")
    if ctx.memory_text:
        parts.append(f"{pk['h_memory']}\n{ctx.memory_text}")
    if ctx.diversity_pressure:
        parts.append(pk["diversity"])
    if ctx.survey:
        parts.append(pk["h_survey"])

    answers_field = ""
    if ctx.survey:
        answers_field = pk["answers_field"].format(
            answer_specs=_survey_specs(ctx.survey, pk))
    task_template = ctx.task_prompt_template.strip() or pk["task"]
    parts.append(_fmt_template(
        task_template,
        question=ctx.goal_question,
        actions=" / ".join(ctx.action_space),
        answers_field=answers_field))
    return "\n\n".join(parts)


# ------------------------------------------------------------------ parsing

_JSON_RE = re.compile(r"\{.*\}", re.DOTALL)


def _loads_first_json_object(text: str) -> dict:
    raw = text.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-zA-Z]*\s*|```$", "", raw,
                     flags=re.MULTILINE).strip()
    decoder = json.JSONDecoder()
    saw_open = False
    for i, ch in enumerate(raw):
        if ch != "{":
            continue
        saw_open = True
        try:
            data, _ = decoder.raw_decode(raw[i:])
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict):
            return data
    m = _JSON_RE.search(raw)
    if m:
        return json.loads(m.group(0))
    preview = text[:200]
    if saw_open or raw.startswith("{"):
        raise ValueError(f"incomplete JSON object in reply: {preview}")
    raise ValueError(f"no JSON object in reply: {preview}")


def _clean_answers(raw: dict, survey: list[SurveyQuestion]) -> dict:
    out: dict = {}
    for q in survey:
        v = raw.get(q.id)
        if v is None:
            continue
        if q.type == "scale":
            try:
                out[q.id] = max(q.scale_min, min(q.scale_max, int(round(float(v)))))
            except (TypeError, ValueError):
                pass
        elif q.type == "choice":
            s = str(v).strip()
            if s in q.choices:
                out[q.id] = s
            else:
                m = [c for c in q.choices if c in s or s in c]
                if m:
                    out[q.id] = m[0]
        else:
            out[q.id] = str(v)[:200]
    return out


def parse_decision(text: str, action_space: list[str],
                   survey: list[SurveyQuestion] | None = None) -> AgentDecision:
    """Multi-layer tolerant parse of a model reply into AgentDecision."""
    data = _loads_first_json_object(text)

    def num(key: str, default: float, lo: float, hi: float) -> float:
        try:
            return max(lo, min(hi, float(data.get(key, default))))
        except (TypeError, ValueError):
            return default

    action = str(data.get("action", "")).strip()
    if action not in action_space:
        matches = [a for a in action_space if a in action or action in a]
        action = matches[0] if matches else action_space[len(action_space) // 2]

    answers = data.get("answers", {})
    if not isinstance(answers, dict):
        answers = {}

    return AgentDecision(
        stance=num("stance", 0.0, -1, 1),
        sentiment=str(data.get("sentiment", "-"))[:24] or "-",
        action=action,
        confidence=num("confidence", 0.5, 0, 1),
        public_statement=str(data.get("public_statement", ""))[:300],
        private_reasoning=str(data.get("private_reasoning", ""))[:300],
        will_share=bool(data.get("will_share", True)),
        answers=_clean_answers(answers, survey or []),
    )


# ----------------------------------------------------------------- provider

class ProviderError(RuntimeError):
    pass


class BaseProvider(abc.ABC):
    """One agent backend. LLM providers call APIs; rule providers compute."""
    name: str = "base"
    supports_vision: bool = False
    supports_image: bool = False
    supports_video: bool = False
    supports_document: bool = False
    default_model: str = "-"
    # USD per 1M tokens (input, output); approximate, override per model
    price_in: float = 0.0
    price_out: float = 0.0

    def __init__(self, model: str | None = None):
        self.model = model or self.default_model

    @abc.abstractmethod
    async def decide(self, persona: Persona, ctx: DecisionContext
                     ) -> tuple[AgentDecision, int, int]:
        """Return (decision, input_tokens, output_tokens)."""

    async def describe_media(self, asset: MediaAsset,
                             locale: str = "en") -> str | None:
        """Neutral caption for one media asset. Vision providers override."""
        return None

    def cost(self, in_tok: int, out_tok: int) -> float:
        return in_tok / 1e6 * self.price_in + out_tok / 1e6 * self.price_out
