"""LLM/VLM providers: Claude, OpenAI, Gemini — via REST (httpx), with retries.

BYOK: keys come from env vars ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY
(GOOGLE_API_KEY also accepted) or can be passed to the constructor.
"""
from __future__ import annotations

import asyncio
import base64
import os
import random as _random
import re

import httpx

from ..i18n import P
from ..schemas import AgentDecision, MediaAsset, Persona, MediaType
from .base import (BaseProvider, DecisionContext, ProviderError,
                   build_system_prompt, build_user_prompt, parse_decision)

DECISION_BASE_MAX_TOKENS = 2048
DECISION_MAX_TOKENS_CAP = 8192

# approximate USD per 1M tokens (input, output); update as pricing changes
_PRICES: dict[str, tuple[float, float]] = {
    "claude-fable-5": (15, 75), "claude-opus": (15, 75),
    "claude-sonnet": (3, 15), "claude-haiku": (1, 5),
    "gpt-5.5": (10, 40), "gpt-5.4-mini": (1, 4),
    "gpt-5.4": (8, 32), "gpt-5": (5, 15),
    "gpt-4o-mini": (0.15, 0.6), "gpt-4o": (2.5, 10), "gpt-4.1": (2, 8),
    "gemini-3.1-pro": (2, 12), "gemini-3.0-pro": (1.5, 10),
    "gemini-3.5-flash": (0.3, 2.5),
    "gemini-2.5-pro": (1.25, 10), "gemini-2.5-flash": (0.3, 2.5),
    "gemini": (0.3, 2.5),
}


def _lookup_price(model: str) -> tuple[float, float]:
    for prefix, p in _PRICES.items():
        if model.startswith(prefix):
            return p
    return (3, 15)


def _media_payloads(media: list[MediaAsset]) -> list[dict]:
    """Flatten assets into provider-facing payload descriptors."""
    out: list[dict] = []
    for m in media:
        if m.media_type == MediaType.video:
            if m.base64_data:
                out.append({"kind": "video", "mime": m.mime_type,
                            "b64": m.base64_data, "url": m.url,
                            "filename": m.filename, "text": m.text})
            out.extend({"kind": "image", "mime": "image/jpeg", "b64": f,
                        "url": None, "filename": m.filename, "text": None}
                       for f in m.frames[:8])
        elif m.media_type == MediaType.document:
            out.append({"kind": "document", "mime": m.mime_type,
                        "b64": m.base64_data, "url": m.url,
                        "filename": m.filename, "text": m.text})
        elif m.media_type == MediaType.image:
            out.append({"kind": "image", "mime": m.mime_type,
                        "b64": m.base64_data, "url": m.url,
                        "filename": m.filename, "text": m.text})
        else:
            out.append({"kind": "text", "mime": m.mime_type,
                        "b64": None, "url": None,
                        "filename": m.filename, "text": m.text})
    return [p for p in out if p.get("b64") or p.get("url") or p.get("text")][:10]


def _image_payloads(media: list[MediaAsset]) -> list[dict]:
    return [p for p in _media_payloads(media) if p.get("kind") == "image"]


def _anthropic_accepts_temperature(model: str) -> bool:
    """Whether to send temperature to Anthropic Messages.

    Newer Claude families reject the parameter, while older model ids may still
    accept it. A retry guard below handles any provider-side changes.
    """
    m = model.lower()
    if re.match(r"claude-(fable|sonnet|opus|haiku)-[45](?:[.-]|$)", m):
        return False
    if re.match(r"claude-[45](?:[.-]|$)", m):
        return False
    return True


def _temperature_deprecated_response(r: httpx.Response) -> bool:
    text = r.text.lower()
    return r.status_code == 400 and "temperature" in text and "deprecated" in text


def _unsupported_param_response(r: httpx.Response, param: str) -> bool:
    text = r.text.lower()
    return r.status_code == 400 and param.lower() in text and (
        "unsupported" in text or "not supported" in text or "invalid" in text)


def _openai_prefers_max_completion_tokens(model: str) -> bool:
    m = model.lower()
    return m.startswith(("gpt-5", "o1", "o3", "o4", "o5"))


def _decision_max_tokens(ctx: DecisionContext) -> int:
    return min(DECISION_MAX_TOKENS_CAP,
               DECISION_BASE_MAX_TOKENS + 256 * len(ctx.survey))


def _decision_schema(ctx: DecisionContext) -> dict:
    answer_props: dict[str, dict] = {}
    required_answers: list[str] = []
    for q in ctx.survey:
        required_answers.append(q.id)
        if q.type == "scale":
            answer_props[q.id] = {
                "type": "NUMBER",
                "minimum": q.scale_min,
                "maximum": q.scale_max,
            }
        elif q.type == "choice" and q.choices:
            answer_props[q.id] = {"type": "STRING", "enum": q.choices}
        else:
            answer_props[q.id] = {"type": "STRING"}
    answers_schema = {
        "type": "OBJECT",
        "properties": answer_props,
        "propertyOrdering": [q.id for q in ctx.survey],
    }
    if required_answers:
        answers_schema["required"] = required_answers
    return {
        "type": "OBJECT",
        "properties": {
            "stance": {"type": "NUMBER", "minimum": -1, "maximum": 1},
            "sentiment": {"type": "STRING"},
            "action": {"type": "STRING", "enum": ctx.action_space},
            "confidence": {"type": "NUMBER", "minimum": 0, "maximum": 1},
            "public_statement": {"type": "STRING"},
            "private_reasoning": {"type": "STRING"},
            "will_share": {"type": "BOOLEAN"},
            "answers": answers_schema,
        },
        "required": [
            "stance", "sentiment", "action", "confidence",
            "public_statement", "private_reasoning", "will_share", "answers",
        ],
        "propertyOrdering": [
            "stance", "sentiment", "action", "confidence",
            "public_statement", "private_reasoning", "will_share", "answers",
        ],
    }


class LLMProvider(BaseProvider):
    supports_vision = True
    supports_image = True
    supports_document = False
    max_retries = 3
    timeout = 60.0

    def __init__(self, model: str | None = None, api_key: str | None = None):
        super().__init__(model)
        self.api_key = api_key or os.environ.get(self.env_key, "")
        self.price_in, self.price_out = _lookup_price(self.model)

    env_key: str = ""

    async def _call(self, system: str, user: str, media: list[dict],
                    temperature: float, max_tokens: int = 1024,
                    response_schema: dict | None = None) -> tuple[str, int, int]:
        raise NotImplementedError

    async def decide(self, persona: Persona, ctx: DecisionContext
                     ) -> tuple[AgentDecision, int, int]:
        if not self.api_key:
            raise ProviderError(f"{self.name}: missing API key ({self.env_key})")
        system = build_system_prompt(
            persona, ctx.language, ctx.system_prompt_template)
        base_user = build_user_prompt(ctx)
        media = _media_payloads(ctx.media) if ctx.use_raw_media else []
        response_schema = _decision_schema(ctx)
        max_tokens = _decision_max_tokens(ctx)
        last: Exception | None = None
        for attempt in range(self.max_retries):
            user = base_user
            if last is not None and "JSON" in str(last):
                user += ("\n\nYour previous response was invalid or incomplete. "
                         "Return one complete JSON object only. Do not omit any "
                         "required fields. Keep public_statement and "
                         "private_reasoning concise.")
            try:
                text, tin, tout = await self._call(system, user, media,
                                                   ctx.temperature,
                                                   max_tokens=max_tokens,
                                                   response_schema=response_schema)
                return parse_decision(text, ctx.action_space, ctx.survey), tin, tout
            except (ValueError, TypeError) as e:
                last = e
                max_tokens = min(DECISION_MAX_TOKENS_CAP, max_tokens * 2)
                continue
            except Exception as e:  # noqa: BLE001 — retry any transient failure
                last = e
                await asyncio.sleep((2 ** attempt) + _random.random())
        raise ProviderError(f"{self.name} failed after retries: {last}")

    async def describe_media(self, asset: MediaAsset,
                             locale: str = "en") -> str | None:
        media = _media_payloads([asset])
        if not media or not self.api_key:
            return None
        text, _, _ = await self._call(
            "You are an objective describer of visual content.",
            P(locale)["caption"], media, 0.2, max_tokens=512)
        return text.strip()


class ClaudeProvider(LLMProvider):
    name = "claude"
    default_model = "claude-sonnet-5"
    env_key = "ANTHROPIC_API_KEY"

    async def _call(self, system, user, media, temperature, max_tokens=1024,
                    response_schema=None):
        content: list[dict] = []
        for img in [m for m in media if m.get("kind") == "image"]:
            src = ({"type": "base64", "media_type": img["mime"], "data": img["b64"]}
                   if img["b64"] else {"type": "url", "url": img["url"]})
            content.append({"type": "image", "source": src})
        content.append({"type": "text", "text": user})
        payload = {"model": self.model, "max_tokens": max_tokens,
                   "system": system,
                   "messages": [{"role": "user", "content": content}]}
        if _anthropic_accepts_temperature(self.model):
            payload["temperature"] = min(temperature, 1.0)
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": self.api_key,
                         "anthropic-version": "2023-06-01"},
                json=payload)
            if _temperature_deprecated_response(r) and "temperature" in payload:
                payload.pop("temperature", None)
                r = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={"x-api-key": self.api_key,
                             "anthropic-version": "2023-06-01"},
                    json=payload)
        if r.status_code != 200:
            raise ProviderError(f"anthropic {r.status_code}: {r.text[:200]}")
        d = r.json()
        text = "".join(b.get("text", "") for b in d.get("content", []))
        u = d.get("usage", {})
        return text, u.get("input_tokens", 0), u.get("output_tokens", 0)


class OpenAIProvider(LLMProvider):
    name = "openai"
    default_model = "gpt-4o"
    env_key = "OPENAI_API_KEY"

    async def _call(self, system, user, media, temperature, max_tokens=1024,
                    response_schema=None):
        content: list[dict] = [{"type": "text", "text": user}]
        for img in [m for m in media if m.get("kind") == "image"]:
            url = img["url"] or f"data:{img['mime']};base64,{img['b64']}"
            content.append({"type": "image_url", "image_url": {"url": url}})
        payload = {"model": self.model, "temperature": temperature,
                   "messages": [{"role": "system", "content": system},
                                {"role": "user", "content": content}]}
        if _openai_prefers_max_completion_tokens(self.model):
            payload["max_completion_tokens"] = max_tokens
        else:
            payload["max_tokens"] = max_tokens
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json=payload)
            if _unsupported_param_response(r, "max_tokens"):
                payload.pop("max_tokens", None)
                payload["max_completion_tokens"] = max_tokens
                r = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    json=payload)
            if _unsupported_param_response(r, "max_completion_tokens"):
                payload.pop("max_completion_tokens", None)
                payload["max_tokens"] = max_tokens
                r = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    json=payload)
            if _unsupported_param_response(r, "temperature") and "temperature" in payload:
                payload.pop("temperature", None)
                r = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    json=payload)
        if r.status_code != 200:
            raise ProviderError(f"openai {r.status_code}: {r.text[:200]}")
        d = r.json()
        u = d.get("usage", {})
        return (d["choices"][0]["message"]["content"],
                u.get("prompt_tokens", 0), u.get("completion_tokens", 0))


class CustomOpenAIProvider(OpenAIProvider):
    """OpenAI-compatible chat/completions endpoint.

    Use for local Ollama/vLLM or hosted providers that expose /v1/models and
    /v1/chat/completions. CUSTOM_BASE_URL may be something like
    http://localhost:11434/v1. CUSTOM_API_KEY is optional for local servers.
    """
    name = "custom"
    default_model = "local-model"
    env_key = "CUSTOM_API_KEY"
    supports_vision = False

    def __init__(self, model: str | None = None, api_key: str | None = None,
                 base_url: str | None = None):
        LLMProvider.__init__(self, model, api_key or os.environ.get(self.env_key, ""))
        self.base_url = (base_url or os.environ.get("CUSTOM_BASE_URL", "")).rstrip("/")
        # Local OpenAI-compatible servers often do not require a key. Keep the
        # parent decide() guard satisfied while omitting Authorization below.
        if self.base_url and not self.api_key:
            self.api_key = "local"

    async def _call(self, system, user, media, temperature, max_tokens=1024,
                    response_schema=None):
        if not self.base_url:
            raise ProviderError("custom: missing base_url (or CUSTOM_BASE_URL)")
        if media:
            raise ProviderError("custom provider does not advertise vision support")
        headers = ({"Authorization": f"Bearer {self.api_key}"}
                   if self.api_key and self.api_key != "local" else {})
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json={"model": self.model, "temperature": temperature,
                      "max_tokens": max_tokens,
                      "messages": [{"role": "system", "content": system},
                                   {"role": "user", "content": user}]})
        if r.status_code != 200:
            raise ProviderError(f"custom {r.status_code}: {r.text[:200]}")
        d = r.json()
        u = d.get("usage", {})
        return (d["choices"][0]["message"]["content"],
                u.get("prompt_tokens", 0), u.get("completion_tokens", 0))


class GeminiProvider(LLMProvider):
    name = "gemini"
    default_model = "gemini-2.5-flash"
    supports_document = True
    supports_video = True

    @property
    def env_key(self) -> str:  # type: ignore[override]
        return "GEMINI_API_KEY"

    def __init__(self, model: str | None = None, api_key: str | None = None):
        BaseProvider.__init__(self, model)
        self.api_key = (api_key or os.environ.get("GEMINI_API_KEY", "")
                        or os.environ.get("GOOGLE_API_KEY", ""))
        self.price_in, self.price_out = _lookup_price(self.model)

    async def _gemini_file_part(self, client: httpx.AsyncClient,
                                item: dict) -> dict | None:
        if not item.get("b64"):
            return None
        data = base64.b64decode(item["b64"])
        mime = item.get("mime") or "application/octet-stream"
        display_name = item.get("filename") or item.get("kind") or "upload"
        cache_key = f"{mime}:{len(data)}:{item['b64'][:32]}"
        cache = getattr(self, "_file_cache", {})
        if cache_key in cache:
            file_info = cache[cache_key]
        else:
            start = await client.post(
                f"https://generativelanguage.googleapis.com/upload/v1beta/files?key={self.api_key}",
                headers={
                    "X-Goog-Upload-Protocol": "resumable",
                    "X-Goog-Upload-Command": "start",
                    "X-Goog-Upload-Header-Content-Length": str(len(data)),
                    "X-Goog-Upload-Header-Content-Type": mime,
                    "Content-Type": "application/json",
                },
                json={"file": {"display_name": display_name}})
            if start.status_code not in (200, 201):
                raise ProviderError(f"gemini upload start {start.status_code}: {start.text[:200]}")
            upload_url = start.headers.get("x-goog-upload-url")
            if not upload_url:
                raise ProviderError("gemini upload missing x-goog-upload-url")
            uploaded = await client.post(
                upload_url,
                headers={
                    "Content-Length": str(len(data)),
                    "X-Goog-Upload-Offset": "0",
                    "X-Goog-Upload-Command": "upload, finalize",
                },
                content=data)
            if uploaded.status_code not in (200, 201):
                raise ProviderError(f"gemini upload {uploaded.status_code}: {uploaded.text[:200]}")
            file_info = uploaded.json().get("file", uploaded.json())
            name = file_info.get("name")
            for _ in range(12):
                state = str(file_info.get("state", "")).upper()
                if not name or state in ("", "ACTIVE"):
                    break
                await asyncio.sleep(2)
                polled = await client.get(
                    f"https://generativelanguage.googleapis.com/v1beta/{name}",
                    params={"key": self.api_key})
                if polled.status_code != 200:
                    break
                file_info = polled.json().get("file", polled.json())
            cache[cache_key] = file_info
            self._file_cache = cache
        uri = file_info.get("uri")
        if not uri:
            return None
        return {"file_data": {"mime_type": mime, "file_uri": uri}}

    async def _parts_for_media(self, client: httpx.AsyncClient,
                               media: list[dict]) -> list[dict]:
        parts: list[dict] = []
        for item in media:
            kind = item.get("kind")
            if kind == "image" and item.get("b64"):
                parts.append({"inline_data": {"mime_type": item["mime"],
                                              "data": item["b64"]}})
            elif kind in ("video", "document") and item.get("text"):
                name = item.get("filename") or kind
                parts.append({"text": f"Uploaded {kind} {name}:\n{item['text'][:6000]}"})
            elif kind in ("video", "document") and item.get("b64"):
                part = await self._gemini_file_part(client, item)
                if part:
                    parts.append(part)
        return parts

    @staticmethod
    def _extract_text(data: dict) -> str:
        chunks: list[str] = []
        reasons: list[str] = []
        for cand in data.get("candidates", []) or []:
            reasons.append(str(cand.get("finishReason", "")))
            for part in cand.get("content", {}).get("parts", []) or []:
                if part.get("text"):
                    chunks.append(part["text"])
        text = "\n".join(chunks).strip()
        if text:
            return text
        feedback = data.get("promptFeedback", {})
        reason = feedback.get("blockReason") or ", ".join(r for r in reasons if r)
        raise ProviderError(f"gemini returned no text candidate: {reason or 'empty response'}")

    async def _call(self, system, user, media, temperature, max_tokens=1024,
                    response_schema=None):
        url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
               f"{self.model}:generateContent?key={self.api_key}")
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            parts: list[dict] = [{"text": user}]
            parts.extend(await self._parts_for_media(client, media))
            generation_config = {"temperature": temperature,
                                 "maxOutputTokens": max_tokens,
                                 "responseMimeType": "application/json"}
            if response_schema:
                generation_config["responseSchema"] = response_schema
            def payload() -> dict:
                return {
                    "systemInstruction": {"parts": [{"text": system}]},
                    "contents": [{"role": "user", "parts": parts}],
                    "generationConfig": dict(generation_config),
                }
            r = await client.post(url, json=payload())
            if _unsupported_param_response(r, "responseMimeType"):
                generation_config.pop("responseMimeType", None)
                generation_config.pop("responseSchema", None)
                r = await client.post(url, json=payload())
            if (_unsupported_param_response(r, "responseSchema")
                    or _unsupported_param_response(r, "response_schema")):
                generation_config.pop("responseSchema", None)
                r = await client.post(url, json=payload())
            if _unsupported_param_response(r, "temperature"):
                generation_config.pop("temperature", None)
                r = await client.post(url, json=payload())
            if _unsupported_param_response(r, "maxOutputTokens"):
                generation_config.pop("maxOutputTokens", None)
                r = await client.post(url, json=payload())
        if r.status_code != 200:
            raise ProviderError(f"gemini {r.status_code}: {r.text[:200]}")
        d = r.json()
        u = d.get("usageMetadata", {})
        return self._extract_text(d), u.get("promptTokenCount", 0), u.get("candidatesTokenCount", 0)
