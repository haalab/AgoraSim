"""Scenario template library.

Templates are data, not code: each defines localized defaults (question,
action space, survey questions, population hints) plus ABM parameter presets
for a domain. The UI lists them; users pick one, everything is prefilled and
editable. Add your own domain by appending to TEMPLATES — no code changes
elsewhere are needed.

Action spaces are ordered MOST POSITIVE -> MOST NEGATIVE (classic/random
agents map stance onto this ordering; LLM agents choose freely).
"""
from __future__ import annotations

from .i18n import norm_locale

TEMPLATES: dict[str, dict] = {
    "social_post": {
        "icon": "message-circle",
        "content_type": "social_post",
        "adopt": [0, 1],
        "abm": {"social_influence": 0.4, "adoption_threshold": 0.1,
                "innovation_p": 0.05, "imitation_q": 0.55, "noise": 0.08},
        "locales": {
            "zh-TW": {
                "name": "貼文 / 文案前測",
                "description": "把你打算發布的貼文、文案或聲明原文貼進來，模擬受眾看到後的反應與擴散。",
                "question": "目標受眾看到這則內容後的反應與擴散意願如何？",
                "target": "你的追蹤者與潛在觸及的一般社群使用者",
                "content_placeholder": "把貼文原文完整貼在這裡（會一字不改地呈現給每個 agent）",
                "actions": ["分享並公開支持", "按讚但不分享", "滑過不理", "留下批評或負面留言"],
                "surveys": [
                    {"id": "share_intent", "text": "你把這則內容分享出去的意願", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "credibility", "text": "這則內容給你的可信度感受", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "first_word", "text": "看完的第一個念頭是什麼", "type": "open"}]},
            "en": {
                "name": "Post / copy pre-test",
                "description": "Paste the exact post, copy or statement you plan to publish; simulate audience reaction and spread.",
                "question": "How will the target audience react to this content, and will they spread it?",
                "target": "Your followers and general social media users you may reach",
                "content_placeholder": "Paste the full post text here (shown to every agent verbatim)",
                "actions": ["Share and publicly support", "Like but not share", "Scroll past", "Leave a critical comment"],
                "surveys": [
                    {"id": "share_intent", "text": "Your willingness to share this content", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "credibility", "text": "How credible this content feels to you", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "first_word", "text": "Your first thought after reading it", "type": "open"}]},
            "ja": {
                "name": "投稿 / コピーの事前テスト",
                "description": "公開予定の投稿・コピー・声明の原文を貼り付け、オーディエンスの反応と拡散をシミュレート。",
                "question": "ターゲット層はこのコンテンツにどう反応し、拡散するか？",
                "target": "あなたのフォロワーと、リーチしうる一般の SNS ユーザー",
                "content_placeholder": "投稿の原文をここに貼り付け（各エージェントに無編集で提示されます）",
                "actions": ["シェアして公に支持", "いいねのみ", "スルー", "批判的なコメントを残す"],
                "surveys": [
                    {"id": "share_intent", "text": "このコンテンツをシェアしたい度合い", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "credibility", "text": "このコンテンツの信頼度の印象", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "first_word", "text": "読んだ直後の最初の感想", "type": "open"}]},
        },
    },
    "finance_market": {
        "icon": "chart-line",
        "content_type": "news",
        "adopt": [0],
        "abm": {"social_influence": 0.35, "adoption_threshold": 0.3,
                "innovation_p": 0.03, "imitation_q": 0.4, "noise": 0.1},
        "locales": {
            "zh-TW": {
                "name": "金融市場事件",
                "description": "央行決策、財報、併購、暴雷……模擬投資人與存戶的行為反應。",
                "question": "投資人與相關民眾在事件後一至兩週會如何反應？",
                "target": "有投資或存款的一般民眾與散戶投資人",
                "content_placeholder": "描述事件內容（政策全文、公告、新聞稿皆可貼上）",
                "actions": ["加碼買進", "持有觀望", "部分減碼", "全面出清避險"],
                "surveys": [
                    {"id": "risk_view", "text": "你認為此事件帶來的風險程度", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "market_dir", "text": "你預期市場短期方向", "type": "choice", "choices": ["看漲", "持平", "看跌"]}]},
            "en": {
                "name": "Financial market event",
                "description": "Central bank moves, earnings, M&A, blow-ups — simulate investor and depositor behavior.",
                "question": "How will investors and the affected public react in the next 1-2 weeks?",
                "target": "Retail investors and the general public with savings",
                "content_placeholder": "Describe the event (paste the full policy text, filing or press release)",
                "actions": ["Buy more", "Hold and watch", "Trim positions", "Sell out / hedge fully"],
                "surveys": [
                    {"id": "risk_view", "text": "How much risk you think this event creates", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "market_dir", "text": "Your short-term market expectation", "type": "choice", "choices": ["Bullish", "Flat", "Bearish"]}]},
            "ja": {
                "name": "金融市場イベント",
                "description": "中央銀行の決定、決算、M&A、破綻……投資家と預金者の行動をシミュレート。",
                "question": "投資家と関係する人々は今後1〜2週間でどう反応するか？",
                "target": "投資や預金を持つ一般の人々・個人投資家",
                "content_placeholder": "イベントの内容を記述（政策全文・開示・プレスリリースの貼り付け可）",
                "actions": ["買い増す", "保有して様子見", "一部売却", "全売却・ヘッジ"],
                "surveys": [
                    {"id": "risk_view", "text": "このイベントがもたらすリスクの大きさ", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "market_dir", "text": "短期的な市場の方向感", "type": "choice", "choices": ["強気", "横ばい", "弱気"]}]},
        },
    },
    "election_policy": {
        "icon": "building-bank",
        "content_type": "policy",
        "adopt": [0, 1],
        "abm": {"social_influence": 0.45, "adoption_threshold": 0.2,
                "innovation_p": 0.02, "imitation_q": 0.5, "noise": 0.12},
        "locales": {
            "zh-TW": {
                "name": "選舉 / 公共政策",
                "description": "候選人發言、政見、醜聞或新政策，模擬選民與民意的變化。",
                "question": "此事件如何影響選民對該候選人/政策的支持度？",
                "target": "具投票權的一般選民",
                "content_placeholder": "描述事件：發言全文、政見內容、新聞事件……",
                "actions": ["更支持並會向親友拉票", "傾向支持", "沒有改變", "更不支持", "轉向支持其他陣營"],
                "surveys": [
                    {"id": "vote_intent", "text": "你投給該候選人/支持該政策的可能性", "type": "scale", "scale_min": 0, "scale_max": 10},
                    {"id": "topic_weight", "text": "這件事對你投票決定的影響程度", "type": "scale", "scale_min": 1, "scale_max": 5}]},
            "en": {
                "name": "Election / public policy",
                "description": "A candidate's statement, platform, scandal or new policy — simulate voter opinion shifts.",
                "question": "How does this event shift voter support for the candidate/policy?",
                "target": "Eligible voters in the relevant electorate",
                "content_placeholder": "Describe the event: full statement, platform text, news item...",
                "actions": ["More supportive, will canvass friends", "Lean supportive", "No change", "Less supportive", "Switch to another side"],
                "surveys": [
                    {"id": "vote_intent", "text": "Likelihood you vote for the candidate / support the policy", "type": "scale", "scale_min": 0, "scale_max": 10},
                    {"id": "topic_weight", "text": "How much this event weighs on your vote", "type": "scale", "scale_min": 1, "scale_max": 5}]},
            "ja": {
                "name": "選挙 / 公共政策",
                "description": "候補者の発言、公約、スキャンダル、新政策——有権者の意識変化をシミュレート。",
                "question": "この出来事は候補者/政策への支持をどう変えるか？",
                "target": "投票権を持つ一般有権者",
                "content_placeholder": "出来事を記述：発言全文、公約、ニュース……",
                "actions": ["より支持し周囲にも勧める", "やや支持", "変化なし", "支持を下げる", "他陣営へ乗り換え"],
                "surveys": [
                    {"id": "vote_intent", "text": "その候補者に投票する/政策を支持する可能性", "type": "scale", "scale_min": 0, "scale_max": 10},
                    {"id": "topic_weight", "text": "この出来事が投票判断に与える影響度", "type": "scale", "scale_min": 1, "scale_max": 5}]},
        },
    },
    "product_launch": {
        "icon": "rocket",
        "content_type": "product",
        "adopt": [0, 1],
        "abm": {"social_influence": 0.3, "adoption_threshold": 0.2,
                "innovation_p": 0.04, "imitation_q": 0.5, "noise": 0.08},
        "locales": {
            "zh-TW": {
                "name": "產品上市 / 廣告前測",
                "description": "新產品、定價、廣告素材（可附圖片/影片），模擬潛在客戶的購買意願。",
                "question": "目標客群看到此產品/廣告後的購買意願與口碑？",
                "target": "該品類的既有與潛在消費者",
                "content_placeholder": "描述產品與訊息，或貼上文案；廣告圖/影片用媒體欄位附上",
                "actions": ["上市就買", "看到優惠或口碑再買", "沒興趣、維持原本選擇", "反感、更不想買這品牌"],
                "surveys": [
                    {"id": "buy_intent", "text": "你購買此產品的意願", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "price_fair", "text": "你覺得定價的合理程度", "type": "scale", "scale_min": 1, "scale_max": 5}]},
            "en": {
                "name": "Product launch / ad pre-test",
                "description": "A new product, pricing, or ad creative (image/video supported) — simulate purchase intent.",
                "question": "After seeing this product/ad, what is the target segment's purchase intent and word of mouth?",
                "target": "Existing and potential consumers in the category",
                "content_placeholder": "Describe the product and message, or paste the copy; attach ad image/video as media",
                "actions": ["Buy at launch", "Buy after deals or word of mouth", "Not interested, keep current choice", "Put off — even less likely to buy this brand"],
                "surveys": [
                    {"id": "buy_intent", "text": "Your intent to buy this product", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "price_fair", "text": "How fair the pricing feels", "type": "scale", "scale_min": 1, "scale_max": 5}]},
            "ja": {
                "name": "新商品 / 広告の事前テスト",
                "description": "新商品・価格・広告クリエイティブ（画像/動画対応）——購入意向をシミュレート。",
                "question": "この商品/広告を見たターゲット層の購入意向と口コミは？",
                "target": "当該カテゴリの既存・潜在消費者",
                "content_placeholder": "商品とメッセージを記述、またはコピーを貼り付け。広告画像/動画はメディア欄で添付",
                "actions": ["発売と同時に買う", "セールや口コミを見てから買う", "興味なし・現状維持", "反感・このブランドを避ける"],
                "surveys": [
                    {"id": "buy_intent", "text": "この商品を購入したい度合い", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "price_fair", "text": "価格の妥当性の印象", "type": "scale", "scale_min": 1, "scale_max": 5}]},
        },
    },
    "brand_crisis": {
        "icon": "alert-triangle",
        "content_type": "news",
        "adopt": [0],
        "abm": {"social_influence": 0.5, "adoption_threshold": 0.15,
                "innovation_p": 0.03, "imitation_q": 0.6, "noise": 0.1},
        "locales": {
            "zh-TW": {
                "name": "品牌危機 / 公關聲明",
                "description": "危機事件與你擬發布的道歉/澄清聲明，模擬輿論走向與修復效果。",
                "question": "公眾看到此事件與聲明後，對品牌的信任與行為如何變化？",
                "target": "品牌既有顧客與關注此事的一般大眾",
                "content_placeholder": "描述危機事件，並把擬發布的聲明原文貼在「原文內容」欄",
                "actions": ["接受說法、繼續支持", "觀望後續處理", "減少購買", "公開抵制並向他人擴散"],
                "surveys": [
                    {"id": "trust_change", "text": "你對該品牌的信任變化（1大幅下降~5不受影響）", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "statement_ok", "text": "你認為聲明的誠意", "type": "scale", "scale_min": 1, "scale_max": 5}]},
            "en": {
                "name": "Brand crisis / PR statement",
                "description": "A crisis plus the apology/clarification you plan to publish — simulate opinion and recovery.",
                "question": "After seeing the incident and the statement, how do trust and behavior toward the brand change?",
                "target": "Existing customers and the attentive public",
                "content_placeholder": "Describe the crisis; paste your draft statement into the verbatim content field",
                "actions": ["Accept it, keep supporting", "Wait and see how it's handled", "Buy less", "Boycott publicly and spread the word"],
                "surveys": [
                    {"id": "trust_change", "text": "Change in your trust in the brand (1 big drop - 5 unaffected)", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "statement_ok", "text": "How sincere the statement feels", "type": "scale", "scale_min": 1, "scale_max": 5}]},
            "ja": {
                "name": "ブランド危機 / 広報声明",
                "description": "危機事案と公開予定の謝罪/釈明文——世論の推移と回復効果をシミュレート。",
                "question": "事案と声明を見た人々のブランドへの信頼と行動はどう変わるか？",
                "target": "既存顧客とこの件に関心を持つ一般の人々",
                "content_placeholder": "危機事案を記述し、声明の原文は「原文コンテンツ」欄に貼り付け",
                "actions": ["説明を受け入れ支持を続ける", "対応を見て判断", "購入を減らす", "公にボイコットし周囲にも広める"],
                "surveys": [
                    {"id": "trust_change", "text": "ブランドへの信頼の変化（1大きく低下〜5影響なし）", "type": "scale", "scale_min": 1, "scale_max": 5},
                    {"id": "statement_ok", "text": "声明の誠実さの印象", "type": "scale", "scale_min": 1, "scale_max": 5}]},
        },
    },
    "custom": {
        "icon": "adjustments",
        "content_type": "other",
        "adopt": [0],
        "abm": {"social_influence": 0.3, "adoption_threshold": 0.25,
                "innovation_p": 0.03, "imitation_q": 0.4, "noise": 0.08},
        "locales": {
            "zh-TW": {
                "name": "自訂情境",
                "description": "從空白開始，自行定義事件、目標、行動空間與調查問題。",
                "question": "", "target": "", "content_placeholder": "描述你的事件或內容",
                "actions": ["積極支持/採納", "觀望", "反對/拒絕"], "surveys": []},
            "en": {
                "name": "Custom scenario",
                "description": "Start blank: define your own event, goal, action space and survey questions.",
                "question": "", "target": "", "content_placeholder": "Describe your event or content",
                "actions": ["Actively support/adopt", "Wait and see", "Oppose/reject"], "surveys": []},
            "ja": {
                "name": "カスタムシナリオ",
                "description": "空白から開始：イベント、目標、行動選択肢、アンケートを自由に定義。",
                "question": "", "target": "", "content_placeholder": "イベントやコンテンツを記述",
                "actions": ["積極的に支持/採用", "様子見", "反対/拒否"], "surveys": []},
        },
    },
}


def get_templates(locale: str = "en") -> list[dict]:
    """Flattened, localized template list for the UI / API."""
    loc = norm_locale(locale)
    out = []
    for tid, t in TEMPLATES.items():
        l = t["locales"].get(loc, t["locales"]["en"])
        out.append({
            "id": tid, "icon": t["icon"], "content_type": t["content_type"],
            "adopt_action_indices": t["adopt"], "abm": t["abm"],
            "name": l["name"], "description": l["description"],
            "question": l["question"], "target_population": l["target"],
            "content_placeholder": l["content_placeholder"],
            "action_space": l["actions"], "survey_questions": l["surveys"],
        })
    return out
