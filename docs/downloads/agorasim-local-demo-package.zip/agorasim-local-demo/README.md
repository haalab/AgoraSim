# AgoraSim Local Demo Package

AgoraSim runs entirely on your own computer. The launcher starts a FastAPI
server on `127.0.0.1`, opens the web UI, and keeps model API keys only in the
running process memory.

## Requirements

- Python 3.10 or newer
- Internet access for the first launch, so Python can install dependencies
- Optional API keys for Anthropic, OpenAI and Google Gemini

No API keys are bundled in this package.

## macOS

Double-click:

```text
run_macos.command
```

If macOS blocks it, right-click the file and choose Open. You can also run:

```bash
chmod +x run_macos.command
./run_macos.command
```

## Windows

Double-click:

```text
run_windows.bat
```

If you prefer PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_windows.ps1
```

## Linux / Advanced

```bash
chmod +x run_linux.sh
./run_linux.sh
```

## Using the demo

1. The launcher creates a local `.venv` folder.
2. It installs AgoraSim and its dependencies into that local environment.
3. It opens `http://127.0.0.1:8000/` or the next available local port.
4. Paste API keys in the API key panel only if you want live LLM agents.

Without API keys, you can still run classic ABM and offline baseline flows.

## Change the port

Set an environment variable before launching:

```bash
AGORASIM_PORT=8080 ./run_macos.command
```

PowerShell:

```powershell
$env:AGORASIM_PORT = "8080"
.\run_windows.ps1
```

## Privacy and cost

- The app binds to `127.0.0.1`, not the public network.
- API keys are not written to disk by AgoraSim.
- Live LLM calls may cost money depending on your provider account.
- Keep the browser tab or launcher window open while running simulations.

